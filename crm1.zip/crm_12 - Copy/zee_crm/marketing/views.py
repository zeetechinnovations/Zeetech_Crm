from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
from django.core.mail import send_mass_mail
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.db import IntegrityError
from .models import Lead, ActionHistory
import json
import csv
from django.utils import timezone

def marketing_management(request):
    leads = Lead.objects.all()
    return render(request, 'marketing/marketing_management.html', {
        'leads': leads,
        'total_leads': leads.count(),
        'hot_leads': leads.filter(status='hot').count(),
        'converted_leads': leads.filter(status='converted').count(),
        'conversion_rate': round((leads.filter(status='converted').count() / leads.count() * 100), 1) if leads.count() > 0 else 0
    })

def marketing_sales(request):
    leads = Lead.objects.all()
    return render(request, 'marketing/marketing_sales.html', {
        'leads': leads,
        'total_leads': leads.count(),
        'hot_leads': leads.filter(status='hot').count(),
        'converted_leads': leads.filter(status='converted').count(),
        'conversion_rate': round((leads.filter(status='converted').count() / leads.count() * 100), 1) if leads.count() > 0 else 0
    })

@csrf_exempt
@require_POST
def add_lead(request):
    try:
        data = json.loads(request.body)
        lead = Lead(
            name=data.get('name'),
            email=data.get('email'),
            phone=data.get('phone'),
            course=data.get('course', 'N/A'),
            status=data.get('status', 'enquiry'),
            source=data.get('source', 'N/A'),
            notes=data.get('notes', '')
        )
        lead.save()
        return JsonResponse({'success': True, 'lead': {
            'id': lead.id,
            'name': lead.name,
            'email': lead.email,
            'phone': lead.phone,
            'course': lead.course,
            'status': lead.status,
            'source': lead.source,
            'notes': lead.notes
        }})
    except json.JSONDecodeError:
        return JsonResponse({'success': False, 'error': 'Invalid JSON data'}, status=400)
    except IntegrityError as e:
        return JsonResponse({'success': False, 'error': 'Email already exists'}, status=400)
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=500)

def get_leads(request):
    leads = Lead.objects.all().values('id', 'name', 'email', 'phone', 'course', 'status', 'source', 'notes')
    return JsonResponse({'leads': list(leads)})

def export_leads(request):
    leads = Lead.objects.all()
    count = leads.count()
    status = 'Success' if count > 0 else 'Failed'
    
    # Log the action
    ActionHistory.objects.create(
        action_type='export',
        count=count,
        status=status
    )

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="leads_export_{timezone.now().strftime("%Y%m%d_%H%M%S")}.csv"'
    writer = csv.writer(response)
    writer.writerow(['Lead ID', 'Name', 'Email', 'Phone', 'Course Interest', 'Status', 'Source', 'Notes'])
    for lead in leads:
        writer.writerow([lead.id, lead.name, lead.email, lead.phone, lead.course, lead.status, lead.source, lead.notes])
    return response

@csrf_exempt
@require_POST
def send_bulk_email(request):
    leads = Lead.objects.all()
    count = leads.count()
    if count == 0:
        ActionHistory.objects.create(
            action_type='email',
            count=0,
            status='Failed'
        )
        return JsonResponse({'success': False, 'error': 'No leads to email.'})

    emails = [(f'CRM Update - {lead.name}', 'Thank you for your interest in Zee-Tech Academy!', 'from@example.com', [lead.email]) for lead in leads]
    try:
        send_mass_mail(emails, fail_silently=False)
        ActionHistory.objects.create(
            action_type='email',
            count=count,
            status='Success'
        )
        return JsonResponse({'success': True})
    except Exception as e:
        ActionHistory.objects.create(
            action_type='email',
            count=count,
            status='Failed'
        )
        return JsonResponse({'success': False, 'error': str(e)})

def get_action_history(request):
    history = ActionHistory.objects.all().order_by('-timestamp')
    history_data = [{
        'action_type': item.action_type,
        'timestamp': item.timestamp.astimezone(timezone.get_current_timezone()).strftime('%m/%d/%Y, %I:%M:%S %p'),
        'count': item.count,
        'status': item.status
    } for item in history]
    return JsonResponse({'history': history_data})

import pandas as pd
from django.http import JsonResponse

@csrf_exempt
@require_POST
def upload_data(request):
    try:
        file = request.FILES['marketing_file']
        data_type = request.POST['data_type']
        
        # Read Excel or CSV file
        if file.name.endswith('.csv'):
            df = pd.read_csv(file)
        elif file.name.endswith(('.xlsx', '.xls')):
            df = pd.read_excel(file)
        else:
            return JsonResponse({'success': False, 'error': 'Unsupported file format'}, status=400)

        # Process leads
        for _, row in df.iterrows():
            Lead.objects.create(
                name=row.get('Name', ''),
                email=row.get('Email', ''),
                phone=row.get('Phone', ''),
                course=row.get('Course Interest', 'N/A'),
                status=row.get('Status', 'enquiry'),
                source=row.get('Source', 'N/A'),
                notes=row.get('Notes', '')
            )

        return JsonResponse({'success': True, 'message': 'Data uploaded successfully'})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=500)