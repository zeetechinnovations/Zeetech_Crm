# marketing/forms.py
from django import forms
from .models import MarketingData
class MarketingDataForm(forms.ModelForm):
    class Meta:
        model = MarketingData
        fields = ['name', 'email', 'phone', 'course_interest', 'status', 'source', 'notes']
        widgets = {
            'notes': forms.Textarea(attrs={'rows': 3}),
        }