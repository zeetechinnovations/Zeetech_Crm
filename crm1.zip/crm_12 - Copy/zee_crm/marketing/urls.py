from django.urls import path
from . import views

urlpatterns = [
    path('marketing-sales/', views.marketing_sales, name='marketing_sales'),  # New URL pattern
    path('add-lead/', views.add_lead, name='add_lead'),
    path('get-leads/', views.get_leads, name='get_leads'),
    path('export-leads/', views.export_leads, name='export_leads'),
    path('send-bulk-email/', views.send_bulk_email, name='send_bulk_email'),
    path('get-action-history/', views.get_action_history, name='get_action_history'),
]



