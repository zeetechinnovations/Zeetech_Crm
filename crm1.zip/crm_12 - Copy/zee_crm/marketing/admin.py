from django.contrib import admin
from .models import Lead, ActionHistory

@admin.register(Lead)
class LeadAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'phone', 'course', 'status', 'source', 'created_at')
    search_fields = ('name', 'email', 'phone', 'course', 'source')
    list_filter = ('status', 'source', 'created_at')

@admin.register(ActionHistory)
class ActionHistoryAdmin(admin.ModelAdmin):
    list_display = ('action_type', 'timestamp', 'count', 'status')
    list_filter = ('action_type', 'status', 'timestamp')

