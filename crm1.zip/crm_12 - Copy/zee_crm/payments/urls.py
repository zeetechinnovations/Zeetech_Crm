from django.shortcuts import redirect
from django.urls import path
from . import views

app_name = 'payments'

urlpatterns = [
    path('', views.payment_management, name='payment_management'),
    path('payments/', lambda request: redirect('payments:payment_management')),
    path('get-payments/', views.get_payments, name='get_payments'),
    path('add-payment/', views.add_payment, name='add_payment'),
    path('edit-payment/<int:payment_id>/', views.edit_payment, name='edit_payment'),
    path('delete-payment/<int:payment_id>/', views.delete_payment, name='delete_payment'),
]
