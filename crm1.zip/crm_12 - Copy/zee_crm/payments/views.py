from django.shortcuts import render, redirect
from django.http import JsonResponse, HttpResponseForbidden, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from accounts.decorators import role_required
from .models import Payment
from students.models import Student
from courses.models import Course
from django.db.models import Sum
import json
import logging
import csv
import os
from django.core.mail import EmailMessage
from django.conf import settings
from datetime import datetime, date
from decimal import Decimal, InvalidOperation
from smtplib import SMTPException
import base64
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
import io
import zipfile

logger = logging.getLogger(__name__) 

def generate_receipts(payment):
    """Generate both CSV and PDF receipts for a payment."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_filename = f"receipt_{payment.id}_{timestamp}.csv"
    pdf_filename = f"receipt_{payment.id}_{timestamp}.pdf"
    csv_file_path = os.path.join(settings.MEDIA_ROOT, csv_filename)
    pdf_file_path = os.path.join(settings.MEDIA_ROOT, pdf_filename)

    try:
        amount = float(payment.amount) if isinstance(payment.amount, (int, float, Decimal)) else float(payment.amount.replace(',', ''))
    except (ValueError, AttributeError) as e:
        logger.error(f"Invalid amount for payment {payment.id}: {e}")
        amount = 0.0

    try:
        date_str = payment.date.isoformat() if isinstance(payment.date, (date, datetime)) else payment.date
    except AttributeError as e:
        logger.error(f"Invalid date for payment {payment.id}: {e}")
        date_str = str(payment.date)

    total_paid = Payment.objects.filter(
        student=payment.student,
        course=payment.course
    ).aggregate(total=Sum('amount'))['total'] or Decimal('0.00')
    
    course_fee = payment.course.fee if payment.course and hasattr(payment.course, 'fee') else Decimal('0.00')
    pending_amount = course_fee - total_paid if payment.course else Decimal('0.00')

    with open(csv_file_path, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['Receipt for Payment'])
        writer.writerow(['Payment ID', payment.id])
        writer.writerow(['Student Name', payment.student.name])
        writer.writerow(['Student Email', payment.student.email])
        writer.writerow(['Course', payment.course.name if payment.course else 'N/A'])
        writer.writerow(['Course Fee', f"{course_fee:.2f}" if payment.course else '0.00'])
        writer.writerow(['Amount Paid (This Payment)', f"{amount:.2f}"])
        writer.writerow(['Total Paid (Course)', f"{total_paid:.2f}"])
        writer.writerow(['Pending Amount', f"{pending_amount:.2f}" if payment.course else '0.00'])
        writer.writerow(['Payment Method', payment.method])
        writer.writerow(['Date', date_str])
        writer.writerow(['Status', payment.status])
        writer.writerow(['Transaction ID', payment.transaction_id or 'N/A'])
        writer.writerow(['Notes', payment.notes or 'N/A'])
        writer.writerow(['Generated On', datetime.now().isoformat()])

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=72, leftMargin=72, topMargin=72, bottomMargin=18)
    elements = []
    styles = getSampleStyleSheet()
    title_style = styles['Heading1']
    normal_style = ParagraphStyle(name='Normal', fontSize=12, leading=14)

    elements.append(Paragraph("Payment Receipt", title_style))
    elements.append(Spacer(1, 0.2 * inch))

    data = [
        ['Payment ID:', str(payment.id)],
        ['Student Name:', payment.student.name],
        ['Student Email:', payment.student.email],
        ['Course:', payment.course.name if payment.course else 'N/A'],
        ['Course Fee:', f"{course_fee:.2f}" if payment.course else '0.00'],
        ['Amount Paid (This Payment):', f"{amount:.2f}"],
        ['Total Paid (Course):', f"{total_paid:.2f}"],
        ['Pending Amount:', f"{pending_amount:.2f}" if payment.course else '0.00'],
        ['Payment Method:', payment.method],
        ['Date:', date_str],
        ['Status:', payment.status],
        ['Transaction ID:', payment.transaction_id or 'N/A'],
        ['Notes:', payment.notes or 'N/A'],
        ['Generated On:', datetime.now().isoformat()],
    ]

    table = Table(data, colWidths=[2.5 * inch, 4.5 * inch])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.white),
        ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 0), (-1, -1), 12),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
    ]))
    elements.append(table)

    doc.build(elements)
    pdf_content = buffer.getvalue()
    buffer.close()

    with open(pdf_file_path, 'wb') as pdf_file:
        pdf_file.write(pdf_content)

    return {
        'csv_path': csv_file_path,
        'csv_filename': csv_filename,
        'pdf_path': pdf_file_path,
        'pdf_filename': pdf_filename,
    }

def send_receipt_email(student, csv_path, csv_filename, pdf_path, pdf_filename):
    """Send both CSV and PDF receipts to the student's email."""
    try:
        email_address = student.email
        if not email_address or '@' not in email_address or '.' not in email_address:
            logger.error(f"Invalid or missing email for student {student.name} (ID: {student.id})")
            return False

        email = EmailMessage(
            subject=f'Payment Receipt {csv_filename}',
            body=f'Dear {student.name},\n\nPlease find attached your payment receipt in both CSV and PDF formats, including course fee, total paid, and pending amount.\n\nThank you!',
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=[email_address],
        )
        email.attach_file(csv_path)
        email.attach_file(pdf_path)
        email.send()
        logger.info(f"Receipts emailed to {email_address}")
        return True
    except SMTPException as e:
        logger.error(f"SMTP error for {email_address}: {e}")
        return False
    except Exception as e:
        logger.error(f"Failed to send email to {email_address}: {e}")
        return False

@role_required('admin', 'student')
def payment_management(request):
    """Render payment management page."""
    if request.user.role == 'admin':
        students = Student.objects.all()
        payments = Payment.objects.all()
    else:
        try:
            student = Student.objects.get(user=request.user)
            students = Student.objects.filter(id=student.id)
            payments = Payment.objects.filter(student=student)
        except Student.DoesNotExist:
            logger.error(f"No student profile for user {request.user.username}")
            return HttpResponseForbidden("No student profile linked.")

    metrics = {
        'total_revenue': payments.aggregate(total=Sum('amount'))['total'] or 0,
        'payments_received': payments.filter(status='paid').count(),
        'pending_payments': payments.filter(status='pending').count(),
        'overdue_payments': payments.filter(status='overdue').count(),
    }
    return render(request, 'payments/payments.html', {
        'students': students,
        'metrics': metrics,
        'courses': Course.objects.all(),
        'payments': payments,
        'is_admin': request.user.role == 'admin'
    })

@csrf_exempt
@role_required('admin', 'student')
def get_payments(request):
    """Fetch payment data via AJAX."""
    if request.method == 'POST':
        try:
            if request.user.role == 'admin':
                payments = Payment.objects.all()
                logger.debug(f"Admin {request.user.username} fetching all payments")
            else:
                try:
                    student = Student.objects.get(user=request.user)
                    payments = Payment.objects.filter(student=student)
                    logger.debug(f"Student {student.name} (ID: {student.id}) fetching payments")
                except Student.DoesNotExist:
                    logger.error(f"No student profile for user {request.user.username}")
                    return JsonResponse({'error': 'No student profile linked'}, status=403)

            payment_data = []
            for payment in payments:
                total_paid = Payment.objects.filter(
                    student=payment.student,
                    course=payment.course
                ).aggregate(total=Sum('amount'))['total'] or Decimal('0.00')
                
                course_fee = payment.course.fee if payment.course and hasattr(payment.course, 'fee') else Decimal('0.00')
                pending_amount = course_fee - total_paid if payment.course else Decimal('0.00')

                payment_data.append({
                    'id': payment.id,
                    'studentName': payment.student.name,
                    'student': payment.student.id,
                    'amount': float(payment.amount),
                    'course': payment.course.name if payment.course else 'N/A',
                    'course_id': payment.course.id if payment.course else None,
                    'course_fee': float(course_fee) if payment.course else 0.0,
                    'total_paid': float(total_paid),
                    'pending_amount': float(pending_amount),
                    'method': payment.method,
                    'date': payment.date.isoformat() if isinstance(payment.date, (date, datetime)) else payment.date,
                    'status': payment.status,
                    'transactionId': payment.transaction_id or '',
                    'notes': payment.notes or '',
                })
            logger.info(f"Returning {len(payment_data)} payments for {request.user.username}")
            return JsonResponse({'payments': payment_data})
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {e}")
            return JsonResponse({'error': 'Invalid JSON data'}, status=400)
        except Exception as e:
            logger.error(f"Error in get_payments: {e}")
            return JsonResponse({'error': str(e)}, status=500)
    return JsonResponse({'error': 'Invalid request method'}, status=405)

@role_required('admin')
def add_payment(request):
    """Add a new payment, send receipts, and trigger download of both CSV and PDF in a ZIP file."""
    if request.method == 'POST':
        try:
            student_id = request.POST.get('student')
            amount = request.POST.get('amount')
            course_id = request.POST.get('course_id')
            method = request.POST.get('method')
            date_str = request.POST.get('date')
            status = request.POST.get('status', 'pending')
            transaction_id = request.POST.get('transaction_id', '')
            notes = request.POST.get('notes', '')

            if not (student_id and amount and method and date_str):
                logger.warning("Missing required fields")
                return JsonResponse({'error': 'Please fill in all required fields'}, status=400)

            try:
                amount = Decimal(amount.replace(',', ''))
                if amount <= 0:
                    raise ValueError("Amount must be greater than zero")
            except (InvalidOperation, ValueError) as e:
                logger.error(f"Invalid amount format: {e}")
                return JsonResponse({'error': f'Invalid amount: {e}'}, status=400)

            try:
                payment_date = datetime.strptime(date_str, '%Y-%m-%d').date()
            except (ValueError, TypeError) as e:
                logger.error(f"Invalid date format: {e}")
                return JsonResponse({'error': f'Invalid date: {date_str}. Use YYYY-MM-DD'}, status=400)

            try:
                student = Student.objects.get(id=student_id)
                course = Course.objects.get(id=course_id) if course_id else None
            except Student.DoesNotExist:
                logger.error(f"Student not found: {student_id}")
                return JsonResponse({'error': 'Student not found'}, status=404)
            except Course.DoesNotExist:
                logger.error(f"Course not found: {course_id}")
                return JsonResponse({'error': 'Course not found'}, status=404)

            payment = Payment.objects.create(
                student=student,
                course=course,
                amount=amount,
                method=method,
                date=payment_date,
                status=status,
                transaction_id=transaction_id,
                notes=notes
            )
            logger.info(f"Payment {payment.id} created for student {student_id}")

            receipts = generate_receipts(payment)
            email_sent = send_receipt_email(
                student,
                receipts['csv_path'],
                receipts['csv_filename'],
                receipts['pdf_path'],
                receipts['pdf_filename']
            )

            with open(receipts['csv_path'], 'rb') as csv_f:
                csv_content = csv_f.read()
            csv_base64 = base64.b64encode(csv_content).decode('utf-8')

            with open(receipts['pdf_path'], 'rb') as pdf_f:
                pdf_content = pdf_f.read()
            pdf_base64 = base64.b64encode(pdf_content).decode('utf-8')

            zip_buffer = io.BytesIO()
            with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                zip_file.write(receipts['csv_path'], receipts['csv_filename'])
                zip_file.write(receipts['pdf_path'], receipts['pdf_filename'])
            zip_content = zip_buffer.getvalue()
            zip_buffer.close()

            for file_path in [receipts['csv_path'], receipts['pdf_path']]:
                try:
                    os.remove(file_path)
                    logger.info(f"Receipt file {file_path} deleted")
                except OSError as e:
                    logger.error(f"Failed to delete receipt file {file_path}: {e}")

            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'success': True,
                    'message': 'Payment added',
                    'email_sent': email_sent,
                    'csv_filename': receipts['csv_filename'],
                    'csv_content': csv_base64,
                    'pdf_filename': receipts['pdf_filename'],
                    'pdf_content': pdf_base64
                })
            else:
                response = HttpResponse(zip_content, content_type='application/zip')
                timestamp = receipts['csv_filename'].split('_')[2]  # Extract timestamp from filename
                zip_filename = f"receipt_{payment.id}_{timestamp}.zip"
                response['Content-Disposition'] = f'attachment; filename="{zip_filename}"'
                return response
        except Exception as e:
            logger.error(f"Error in add_payment: {e}")
            return JsonResponse({'error': str(e)}, status=500)
    return redirect('payments:payment_management')

@role_required('admin')
def edit_payment(request, payment_id):
    """Edit an existing payment, send receipts, and trigger download of both CSV and PDF in a ZIP file."""
    if request.method == 'POST':
        try:
            payment = Payment.objects.get(id=payment_id)
            student_id = request.POST.get('student')
            amount = request.POST.get('amount')
            course_id = request.POST.get('course_id')
            method = request.POST.get('method')
            date_str = request.POST.get('date')
            status = request.POST.get('status', 'pending')
            transaction_id = request.POST.get('transaction_id', '')
            notes = request.POST.get('notes', '')

            if not (student_id and amount and method and date_str):
                logger.warning("Missing required fields")
                return JsonResponse({'error': 'Please fill in all required fields'}, status=400)

            try:
                amount = Decimal(amount.replace(',', ''))
                if amount <= 0:
                    raise ValueError("Amount must be greater than zero")
            except (InvalidOperation, ValueError) as e:
                logger.error(f"Invalid amount format: {e}")
                return JsonResponse({'error': f'Invalid amount: {e}'}, status=400)

            try:
                payment_date = datetime.strptime(date_str, '%Y-%m-%d').date()
            except (ValueError, TypeError) as e:
                logger.error(f"Invalid date format: {e}")
                return JsonResponse({'error': f'Invalid date: {date_str}. Use YYYY-MM-DD'}, status=400)

            try:
                student = Student.objects.get(id=student_id)
                course = Course.objects.get(id=course_id) if course_id else None
            except Student.DoesNotExist:
                logger.error(f"Student not found: {student_id}")
                return JsonResponse({'error': 'Student not found'}, status=404)
            except Course.DoesNotExist:
                logger.error(f"Course not found: {course_id}")
                return JsonResponse({'error': 'Course not found'}, status=404)

            payment.student = student
            payment.course = course
            payment.amount = amount
            payment.method = method
            payment.date = payment_date
            payment.status = status
            payment.transaction_id = transaction_id
            payment.notes = notes
            payment.save()
            logger.info(f"Payment {payment_id} updated")

            receipts = generate_receipts(payment)
            email_sent = send_receipt_email(
                student,
                receipts['csv_path'],
                receipts['csv_filename'],
                receipts['pdf_path'],
                receipts['pdf_filename']
            )

            with open(receipts['csv_path'], 'rb') as csv_f:
                csv_content = csv_f.read()
            csv_base64 = base64.b64encode(csv_content).decode('utf-8')

            with open(receipts['pdf_path'], 'rb') as pdf_f:
                pdf_content = pdf_f.read()
            pdf_base64 = base64.b64encode(pdf_content).decode('utf-8')

            zip_buffer = io.BytesIO()
            with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                zip_file.write(receipts['csv_path'], receipts['csv_filename'])
                zip_file.write(receipts['pdf_path'], receipts['pdf_filename'])
            zip_content = zip_buffer.getvalue()
            zip_buffer.close()

            for file_path in [receipts['csv_path'], receipts['pdf_path']]:
                try:
                    os.remove(file_path)
                    logger.info(f"Receipt file {file_path} deleted")
                except OSError as e:
                    logger.error(f"Failed to delete receipt file {file_path}: {e}")

            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'success': True,
                    'message': 'Payment updated',
                    'email_sent': email_sent,
                    'csv_filename': receipts['csv_filename'],
                    'csv_content': csv_base64,
                    'pdf_filename': receipts['pdf_filename'],
                    'pdf_content': pdf_base64
                })
            else:
                response = HttpResponse(zip_content, content_type='application/zip')
                timestamp = receipts['csv_filename'].split('_')[2]  # Extract timestamp from filename
                zip_filename = f"receipt_{payment.id}_{timestamp}.zip"
                response['Content-Disposition'] = f'attachment; filename="{zip_filename}"'
                return response
        except Payment.DoesNotExist:
            logger.error(f"Payment not found: {payment_id}")
            return JsonResponse({'error': 'Payment not found'}, status=404)
        except Exception as e:
            logger.error(f"Error in edit_payment: {e}")
            return JsonResponse({'error': str(e)}, status=500)
    return JsonResponse({'error': 'Invalid request method'}, status=405)

@role_required('admin')
def delete_payment(request, payment_id):
    """Delete a payment."""
    if request.method == 'POST':
        try: 
            payment = Payment.objects.get(id=payment_id)
            payment.delete()
            logger.info(f"Payment {payment_id} deleted")
            return JsonResponse({'success': True})
        except Payment.DoesNotExist:
            logger.error(f"Payment not found: {payment_id}")
            return JsonResponse({'error': 'Payment not found'}, status=404)
        except Exception as e:
            logger.error(f"Error in delete_payment: {e}")
            return JsonResponse({'error': str(e)}, status=500)
    return JsonResponse({'error': 'Invalid request method'}, status=405)


