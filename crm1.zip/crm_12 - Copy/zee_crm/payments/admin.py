from django.contrib import admin
from .models import Student, Payment

class PaymentAdmin(admin.ModelAdmin):
    list_display = ('id', 'student', 'amount', 'course', 'method', 'date', 'status', 'transaction_id')
    list_filter = ('status', 'method', 'date')
    search_fields = ('student__name', 'course', 'transaction_id')
    list_per_page = 20

# admin.site.register(Student)
admin.site.register(Payment, PaymentAdmin)



