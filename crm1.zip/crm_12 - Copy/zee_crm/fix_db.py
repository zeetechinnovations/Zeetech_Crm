import sqlite3

# Connect to the database
conn = sqlite3.connect('db.sqlite3')
cursor = conn.cursor()

# Update the invalid foreign key to NULL
cursor.execute("UPDATE batches_batch SET course_id = NULL WHERE id = 1")

# Commit the changes
conn.commit()

# Close the connection
conn.close()
print("Database updated successfully. Run 'python manage.py migrate' next.")