# study_material/apps.py
from django.apps import AppConfig

class StudyMaterialConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'study_material'



    