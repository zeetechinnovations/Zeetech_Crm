from django.urls import path
from . import views

app_name = 'study_material'

urlpatterns = [
    path('study_material/', views.study_material_view, name='study_material'),
    path('get_materials/', views.get_materials, name='get_materials'),
    path('upload_material/', views.upload_material, name='upload_material'),
]