from django.shortcuts import render
import json
import logging
from courses.models import Course
from accounts.decorators import role_required
from students.models import Student
from django.contrib.auth.decorators import login_required

logger = logging.getLogger(__name__)

def study_material_view(request):
    try:
        if request.user.is_authenticated:
            if request.user.role == 'admin' or request.user.role == 'teacher':
                courses = Course.objects.all()
            else:  # student
                courses = Course.objects.filter(students=request.user)
        else:
            courses = Course.objects.none()
        
        courses_data = [
            {
                'id': course.id,
                'name': course.name,
            }
            for course in courses
        ]
        print("Courses Data in study_material_view:", courses_data)  # Debug
        logger.info(f"Fetched {len(courses_data)} courses for user {request.user.username}")
        return render(request, 'study_material/study_material.html', {
            'courses_json': json.dumps(courses_data),
        })
    except Exception as e:
        logger.error(f"Error in study_material_view: {str(e)}")
        return render(request, 'study_material/study_material.html', {
            'courses_json': json.dumps([]),
        })

from django.http import JsonResponse
from django.views.decorators.http import require_GET, require_POST
from django.views.decorators.csrf import csrf_exempt
from .models import StudyMaterial



@require_GET
@login_required
@role_required('admin', 'teacher', 'student')
def get_materials(request):
    try:
        course_id = request.GET.get('course_id')
        
        if request.user.role == 'student':
            try:
                student = Student.objects.get(user=request.user)
                materials = StudyMaterial.objects.filter(course=student.course)
            except Student.DoesNotExist:
                return JsonResponse({'materials': [], 'error': 'Student profile not found'}, status=400)
        else:
            materials = StudyMaterial.objects.all()
            if course_id:
                materials = materials.filter(course_id=course_id)

        materials_data = []
        for material in materials:
            materials_data.append({
                'id': material.id,
                'title': material.title,
                'description': material.description or '',
                'course_id': material.course.id if material.course else None,
                'course_name': material.course.name if material.course else 'No Course',
                'material_type': material.material_type,
                'file_url': material.file.url if material.file else '',
                'uploaded_at': material.uploaded_at.strftime('%Y-%m-%d %H:%M'),
            })
        logger.info(f"Fetched {len(materials_data)} materials")
        return JsonResponse({'status': 'success', 'materials': materials_data})

    except Exception as e:
        logger.error(f"Error fetching materials: {str(e)}")
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)



@require_POST
@csrf_exempt  # Temporarily for testing; consider proper CSRF handling in production
def upload_material(request):
    try:
        title = request.POST.get('title')
        description = request.POST.get('description')
        course_id = request.POST.get('course_id')
        material_type = request.POST.get('material_type')
        file = request.FILES.get('file')

        if not all([title, course_id, material_type, file]):
            logger.warning("Missing required fields in upload_material")
            return JsonResponse({'error': 'Missing required fields'}, status=400)

        try:
            course = Course.objects.get(id=course_id)
        except Course.DoesNotExist:
            logger.warning(f"Invalid course ID: {course_id}")
            return JsonResponse({'error': 'Invalid course ID'}, status=400)

        if material_type not in ['PDF', 'Video']:
            logger.warning(f"Invalid material type: {material_type}")
            return JsonResponse({'error': 'Invalid material type'}, status=400)

        material = StudyMaterial.objects.create(
            title=title,
            description=description,
            course=course,
            material_type=material_type,
            file=file
        )
        material_data = {
            'id': material.id,
            'title': material.title,
            'description': material.description or '',
            'course_id': material.course.id,
            'course_name': material.course.name,
            'material_type': material.material_type,
            'file_url': material.file.url if material.file else '',
            'uploaded_at': material.uploaded_at.isoformat(),
        }
        logger.info(f"Uploaded material: {material.title}")
        return JsonResponse({'material': material_data})
    except Exception as e:
        logger.error(f"Error uploading material: {str(e)}")
        return JsonResponse({'error': f'Error uploading material: {str(e)}'}, status=400)