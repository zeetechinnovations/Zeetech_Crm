from django.db import models
from accounts.models import User

class Course(models.Model):
    code = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=100)
    duration = models.PositiveIntegerField()  # Duration in months
    fee = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField(blank=True, null=True)
    max_students = models.PositiveIntegerField(default=30)
    students = models.ManyToManyField(
        User,
        related_name='courses_enrolled',
        limit_choices_to={'role': 'student'}
    )
    status = models.CharField(
        max_length=20,
        choices=[
            ('active', 'Active'),
            ('inactive', 'Inactive'),
            ('upcoming', 'Upcoming'),
        ],
        default='active'
    )

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Course"
        verbose_name_plural = "Courses"



