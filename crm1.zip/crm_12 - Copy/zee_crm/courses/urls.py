from django.urls import path
from . import views

urlpatterns = [
    path('', views.courses_view, name='courses'),
    path('get_courses/', views.get_courses, name='get_courses'),
    path('add/', views.add_course, name='add_course'),
    path('delete/<int:course_id>/', views.delete_course, name='delete_course'),
]
