from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from accounts.decorators import role_required
from .models import Course
from accounts.models import User
import json

@role_required('admin', 'teacher', 'student')
def courses_view(request):
    print(f"User: {request.user}, Role: {request.user.role}, Authenticated: {request.user.is_authenticated}")  # Debug
    if not request.user.is_authenticated:
        return redirect('accounts:login')  # Redirect to login page if not authenticated

    # Fetch courses based on user role
    if request.user.role == 'admin':
        courses = Course.objects.all()
    elif request.user.role == 'teacher':
        courses = Course.objects.all()  # Teachers see all courses since no teacher field
    else:  # student
        courses = Course.objects.filter(students=request.user)
    
    # Prepare course data for JSON
    courses_data = [
        {
            'id': course.id,
            'code': course.code,
            'name': course.name,
            'duration': course.duration,
            'fee': float(course.fee),
            'description': course.description,
            'max_students': course.max_students,
            'enrolled': course.students.count(),
            'status': course.status,
            'students': [student.id for student in course.students.all()],
        }
        for course in courses
    ]

    # Calculate statistics
    total_courses = courses.count()
    active_courses = courses.filter(status='active').count()
    enrolled_students = sum(course.students.count() for course in courses)
    students = User.objects.filter(role='student')  # Fetch students for form

    return render(request, 'courses/courses.html', {
        'courses_json': json.dumps(courses_data),
        'total_courses': total_courses,
        'active_courses': active_courses,
        'enrolled_students': enrolled_students,
        'students': students,
    })

@role_required('admin', 'teacher', 'student')
def get_courses(request):
    if request.method == 'GET':
        # Fetch courses based on user role
        if request.user.role == 'admin':
            courses = Course.objects.all()
        elif request.user.role == 'teacher':
            courses = Course.objects.all()
        else:  # student
            courses = Course.objects.filter(students=request.user)
        
        # Prepare course data for JSON response
        courses_data = [
            {
                'id': course.id,
                'code': course.code,
                'name': course.name,
                'duration': course.duration,
                'fee': float(course.fee),
                'description': course.description,
                'max_students': course.max_students,
                'enrolled': course.students.count(),
                'status': course.status,
                'students': [student.id for student in course.students.all()],
            }
            for course in courses
        ]
        return JsonResponse({'courses': courses_data})
    return JsonResponse({'error': 'Invalid request method'}, status=405)

@csrf_exempt
@role_required('admin')
def add_course(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Invalid request method'}, status=405)

    try:
        course_id = request.POST.get('course_id')
        code = request.POST.get('course_code')
        name = request.POST.get('course_name')
        duration = request.POST.get('duration')
        fee = request.POST.get('fee')
        description = request.POST.get('description') or None
        max_students = request.POST.get('max_students') or 30
        status = request.POST.get('status') or 'active'

        # Validate required fields
        if not (code and name and duration and fee):
            return JsonResponse({'error': 'Missing required fields'}, status=400)

        # Validate numeric fields
        try:
            duration = int(duration)
            fee = float(fee)
            max_students = int(max_students)
        except ValueError:
            return JsonResponse({'error': 'Invalid numeric values for duration, fee, or max students'}, status=400)

        if course_id:
            # Update existing course
            course = Course.objects.get(id=course_id)
            course.code = code
            course.name = name
            course.duration = duration
            course.fee = fee
            course.description = description
            course.max_students = max_students
            course.status = status
        else:
            # Create new course
            course = Course(
                code=code,
                name=name,
                duration=duration,
                fee=fee,
                description=description,
                max_students=max_students,
                status=status,
            )
        course.save()

        # Update students
        student_ids = request.POST.getlist('students')
        course.students.set(student_ids)

        # Return course data
        course_data = {
            'id': course.id,
            'code': course.code,
            'name': course.name,
            'duration': course.duration,
            'fee': float(course.fee),
            'description': course.description,
            'max_students': course.max_students,
            'enrolled': course.students.count(),
            'status': course.status,
            'students': [student.id for student in course.students.all()],
        }
        return JsonResponse({'course': course_data, 'success': True})
    except Course.DoesNotExist:
        return JsonResponse({'error': 'Course not found'}, status=404)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)

@csrf_exempt
@role_required('admin')
def delete_course(request, course_id):
    if request.method == 'POST':
        try:
            course = Course.objects.get(id=course_id)
            course.delete()
            return JsonResponse({'success': True})
        except Course.DoesNotExist:
            return JsonResponse({'error': 'Course not found'}, status=404)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=405)