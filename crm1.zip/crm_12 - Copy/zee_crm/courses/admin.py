from django.contrib import admin
from .models import Course

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ['id', 'code', 'name', 'duration', 'get_enrolled', 'fee', 'status']
    list_filter = ['status']
    search_fields = ['name', 'code']

    def get_enrolled(self, obj):
        return obj.students.count()
    get_enrolled.short_description = 'Enrolled Students'


    