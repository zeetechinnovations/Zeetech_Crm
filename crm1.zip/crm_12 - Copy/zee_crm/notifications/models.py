from django.db import models
from django.conf import settings
from students.models import Student

class Student(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    email = models.EmailField(max_length=254, blank=True, null=True)
    phone = models.CharField(max_length=15, blank=True, null=True)
    enrolled_course = models.CharField(max_length=100, blank=True, null=True)
    batch = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return self.user.username

class Notification(models.Model):
    TYPE_CHOICES = (
        ('payment', 'Payment Reminder'),
        ('course', 'Course Update'),
        ('batch', 'Batch Information'),
        ('general', 'General Announcement'),
    )
    
    RECIPIENT_CHOICES = (
        ('all', 'All Students'),
        ('course-specific', 'Course Specific'),
        ('batch-specific', 'Batch Specific'),
        ('individual', 'Individual Student'),
    )

    STATUS_CHOICES = (
        ('unread', 'Unread'),
        ('read', 'Read'),
    )

    title = models.CharField(max_length=200)
    message = models.TextField()
    type = models.CharField(max_length=50, choices=TYPE_CHOICES)
    recipients = models.CharField(max_length=50, choices=RECIPIENT_CHOICES)
    course = models.CharField(max_length=100, blank=True, null=True)
    student = models.ForeignKey(Student, on_delete=models.CASCADE, blank=True, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='unread')
    send_email = models.BooleanField(default=False)
    send_sms = models.BooleanField(default=False)
    delivery_status = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return self.title

    class Meta:
        ordering = ['-created_at']


        