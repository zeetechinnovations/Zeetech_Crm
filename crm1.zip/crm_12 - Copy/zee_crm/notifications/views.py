from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.conf import settings
from twilio.rest import Client
from twilio.base.exceptions import TwilioRestException
from .models import Notification
from students.models import Student
from django.utils import timezone
import json
import logging
from datetime import datetime
from accounts.decorators import role_required

# Configure logging
logger = logging.getLogger(__name__)

@role_required('admin')
@login_required
def notifications_view(request):
    students = Student.objects.all()
    return render(request, 'notifications/notifications.html', {'students': students})

@role_required('admin')
@login_required
def send_notification(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            title = data.get('title')
            message = data.get('message')
            notification_type = data.get('type')
            recipients = data.get('recipients')
            course = data.get('course')
            student_id = data.get('student_id')
            send_email = data.get('send_email', False)
            send_sms = data.get('send_sms', False)

            # Log the incoming request data
            logger.debug(f"Received notification request: {data}")

            # Validate required fields
            if not all([title, message, notification_type, recipients]):
                logger.error("Missing required fields: %s", data)
                return JsonResponse({'status': 'error', 'message': 'All required fields must be filled'}, status=400)

            # Determine recipients
            students = []
            if recipients == 'all':
                students = Student.objects.all()
                logger.debug("Fetching all students: %d found", students.count())
            elif recipients == 'course-specific' and course:
                students = Student.objects.filter(course=course)
                logger.debug("Fetching students for course '%s': %d found", course, students.count())
            elif recipients == 'batch-specific' and course:
                students = Student.objects.filter(batch=course)
                logger.debug("Fetching students for batch '%s': %d found", course, students.count())
            elif recipients == 'individual' and student_id:
                student = get_object_or_404(Student, id=student_id)
                students = [student]
                logger.debug("Fetching individual student ID %s: %s", student_id, student)
            else:
                logger.error("Invalid recipient selection: %s", recipients)
                return JsonResponse({'status': 'error', 'message': 'Invalid recipient selection'}, status=400)

            # Validate recipient data
            valid_students = []
            invalid_reasons = []
            for student in students:
                valid = True
                reasons = []
                if send_email:
                    if not student.email or '@' not in student.email:
                        valid = False
                        reasons.append(f"Invalid email: {student.email}")
                if send_sms:
                    # Ensure phone number is in E.164 format (starts with + followed by country code)
                    if not student.phone or len(student.phone) < 10 or not student.phone.startswith('+'):
                        valid = False
                        reasons.append(f"Invalid phone number (must be in E.164 format, e.g., +1234567890): {student.phone}")
                if valid:
                    valid_students.append(student)
                else:
                    invalid_reasons.append(f"Student {student.name}: {', '.join(reasons)}")

            # Create notification regardless of valid recipients
            delivery_status = None
            if not students:
                delivery_status = "No students found for the selected recipient criteria."
                logger.warning(delivery_status)
            elif not valid_students:
                delivery_status = "No students with valid email or phone number found."
                logger.warning(delivery_status)

            notification = Notification.objects.create(
                title=title,
                message=message,
                type=notification_type,
                recipients=recipients,
                course=course if recipients in ['course-specific', 'batch-specific'] else None,
                student=students[0] if recipients == 'individual' and students else None,
                send_email=send_email,
                send_sms=send_sms,
                created_by=request.user,
                delivery_status=delivery_status
            )

            if not valid_students:
                logger.warning("No valid recipients: %s", "; ".join(invalid_reasons) if invalid_reasons else "No valid recipients found.")
                return JsonResponse({
                    'status': 'warning',
                    'message': 'Notification saved, but no valid recipients found to send to.',
                    'details': delivery_status
                }, status=207)

            # Send email and/or SMS
            errors = []
            if send_email:
                for student in valid_students:
                    try:
                        send_mail(
                            subject=title,
                            message=message,
                            from_email=settings.DEFAULT_FROM_EMAIL,
                            recipient_list=[student.email],
                            fail_silently=False,
                        )
                        logger.info("Email sent to %s for notification %s", student.email, notification.id)
                    except Exception as e:
                        logger.error("Failed to send email to %s: %s", student.email, str(e))
                        errors.append(f"Failed to send email to {student.email}: {str(e)}")

            if send_sms:
                if not hasattr(settings, 'TWILIO_ACCOUNT_SID') or not settings.TWILIO_ACCOUNT_SID:
                    logger.error("Twilio credentials not configured in settings.py")
                    errors.append("Twilio credentials not configured in settings.py")
                else:
                    try:
                        client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
                        for student in valid_students:
                            try:
                                message_response = client.messages.create(
                                    body=message,
                                    from_=settings.TWILIO_PHONE_NUMBER,
                                    to=student.phone
                                )
                                logger.info("SMS sent to %s for notification %s. SID: %s", student.phone, notification.id, message_response.sid)
                            except TwilioRestException as e:
                                logger.error("Failed to send SMS to %s: [Code %s] %s", student.phone, e.code, e.msg)
                                errors.append(f"Failed to send SMS to {student.phone}: [Code {e.code}] {e.msg}")
                    except Exception as e:
                        logger.error("Twilio client initialization failed: %s", str(e))
                        errors.append(f"Twilio client initialization failed: {str(e)}")

            if errors:
                notification.delivery_status = "; ".join(errors)
                notification.save()
                return JsonResponse({
                    'status': 'error',
                    'message': 'Notification saved but some deliveries failed',
                    'errors': errors
                }, status=207)

            return JsonResponse({'status': 'success', 'message': 'Notification sent successfully'})
        except Exception as e:
            logger.error("Error processing notification: %s", str(e))
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'}, status=405)

@role_required('admin')
@login_required
def get_notifications(request):
    status_filter = request.GET.get('status', '')
    type_filter = request.GET.get('type', '')
    
    notifications = Notification.objects.all()
    if status_filter:
        notifications = notifications.filter(status=status_filter)
    if type_filter:
        notifications = notifications.filter(type=type_filter)
    
    notifications_data = [{
        'id': n.id,
        'type': n.type,
        'title': n.title,
        'message': n.message,
        'recipients': n.recipients,
        'status': n.status,
        'timestamp': n.created_at.isoformat(),
        'delivery_status': n.delivery_status if n.delivery_status else 'Sent successfully'
    } for n in notifications]
    
    return JsonResponse({'notifications': notifications_data})

@role_required('admin')
@login_required
def mark_notification_read(request, notification_id):
    notification = get_object_or_404(Notification, id=notification_id)
    notification.status = 'read'
    notification.save()
    return JsonResponse({'status': 'success', 'message': 'Notification marked as read'})

@role_required('admin')
@login_required
def mark_all_read(request):
    Notification.objects.filter(status='unread').update(status='read')
    return JsonResponse({'status': 'success', 'message': 'All notifications marked as read'})

@role_required('admin')
@login_required
def delete_notification(request, notification_id):
    notification = get_object_or_404(Notification, id=notification_id)
    notification.delete()
    return JsonResponse({'status': 'success', 'message': 'Notification deleted successfully'})