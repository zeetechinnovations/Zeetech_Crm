from django.core.mail import send_mail
from django.conf import settings
from twilio.rest import Client

def send_email_notification(subject, message, recipient_list):
    try:
        send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, recipient_list, fail_silently=False)
        return True
    except Exception as e:
        print(f"Email Error: {e}")
        return False

def send_sms_notification(message, recipient_number):
    try:
        client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
        client.messages.create(
            body=message,
            from_=settings.TWILIO_PHONE_NUMBER,
            to=recipient_number
        )
        return True
    except Exception as e:
        print(f"SMS Error: {e}")
        return False
