from django.shortcuts import render
from django.http import JsonResponse, HttpResponseForbidden
from django.views.decorators.csrf import csrf_exempt
from accounts.decorators import role_required
from .models import Batch
from courses.models import Course
import json
from datetime import datetime

@role_required('admin', 'teacher', 'student')
def batches_view(request):
    # Fetch batches based on user role
    if request.user.role == 'admin':
        batches = Batch.objects.all()
    elif request.user.role == 'teacher':
        batches = Batch.objects.all()  # Teachers can see all batches
    else:  # student
        batches = Batch.objects.filter(students=request.user)
    
    # Prepare batch data for JSON
    batches_data = [
        {
            'id': batch.id,
            'name': batch.name,
            'course': batch.course.name,
            'course_id': batch.course.id,
            'start_date': batch.start_date.strftime('%Y-%m-%d'),
            'end_date': batch.end_date.strftime('%Y-%m-%d'),
            'description': batch.description,
            'max_capacity': batch.max_capacity,
            'students': batch.students.count(),
            'status': batch.status,
        }
        for batch in batches
    ]

    # Calculate statistics
    total_batches = batches.count()
    active_batches = batches.filter(status__in=['ongoing', 'upcoming']).count()
    total_students = sum(batch.students.count() for batch in batches)
    courses = Course.objects.all()  # Fetch all courses for dropdown

    # Render template with batch data
    return render(request, 'batches/batches.html', {
        'batches_json': json.dumps(batches_data),
        'total_batches': total_batches,
        'active_batches': active_batches,
        'total_students': total_students,
        'courses': courses,
    })

@role_required('admin', 'teacher', 'student')
def get_batches(request):
    if request.method == 'GET':
        # Fetch batches based on user role
        if request.user.role == 'admin':
            batches = Batch.objects.all()
        elif request.user.role == 'teacher':
            batches = Batch.objects.all()
        else:  # student
            batches = Batch.objects.filter(students=request.user)
        
        # Prepare batch data for JSON response
        batches_data = [
            {
                'id': batch.id,
                'name': batch.name,
                'course': batch.course.name,
                'course_id': batch.course.id,
                'start_date': batch.start_date.strftime('%Y-%m-%d'),
                'end_date': batch.end_date.strftime('%Y-%m-%d'),
                'description': batch.description,
                'max_capacity': batch.max_capacity,
                'students': batch.students.count(),
                'status': batch.status,
            }
            for batch in batches
        ]
        return JsonResponse({'batches': batches_data})
    return JsonResponse({'error': 'Invalid request method'}, status=405)

@csrf_exempt
@role_required('admin')
def add_batch(request):
    if request.method == 'POST':
        try:
            batch_id = request.POST.get('batch_id')
            name = request.POST.get('batch_name')
            course_id = request.POST.get('course_id')
            start_date = request.POST.get('start_date')
            end_date = request.POST.get('end_date')
            description = request.POST.get('description') or ""
            max_capacity = request.POST.get('max_capacity') or 30
            status = request.POST.get('status') or 'upcoming'

            # Validate required fields
            if not name or not course_id or not start_date or not end_date:
                return JsonResponse({'error': 'Missing required fields'}, status=400)

            # Validate course
            try:
                course = Course.objects.get(id=course_id)
            except Course.DoesNotExist:
                return JsonResponse({'error': 'Invalid course selected'}, status=400)

            # Validate dates
            start_date_obj = datetime.strptime(start_date, '%Y-%m-%d').date()
            end_date_obj = datetime.strptime(end_date, '%Y-%m-%d').date()

            if start_date_obj > end_date_obj:
                return JsonResponse({'error': 'End date must be after start date'}, status=400)

            if batch_id:
                # Update existing batch
                batch = Batch.objects.get(id=batch_id)
                batch.name = name
                batch.course = course
                batch.start_date = start_date_obj
                batch.end_date = end_date_obj
                batch.description = description
                batch.max_capacity = max_capacity
                batch.status = status
            else:
                # Create new batch
                batch = Batch(
                    name=name,
                    course=course,
                    start_date=start_date_obj,
                    end_date=end_date_obj,
                    description=description,
                    max_capacity=max_capacity,
                    status=status
                )

            batch.save()
            if not batch_id:
                student_ids = request.POST.getlist('students')
                batch.students.set(student_ids)

            # Return the saved batch data
            return JsonResponse({
                'success': True,
                'batch': {
                    'id': batch.id,
                    'name': batch.name,
                    'course': batch.course.name,
                    'course_id': batch.course.id,
                    'start_date': batch.start_date.strftime('%Y-%m-%d'),
                    'end_date': batch.end_date.strftime('%Y-%m-%d'),
                    'description': batch.description,
                    'max_capacity': batch.max_capacity,
                    'students': batch.students.count(),
                    'status': batch.status,
                }
            })

        except Batch.DoesNotExist:
            return JsonResponse({'error': 'Batch not found'}, status=404)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)

    return JsonResponse({'error': 'Invalid request method'}, status=405)

@csrf_exempt
@role_required('admin')
def delete_batch(request, batch_id):
    if request.method == 'POST':
        try:
            batch = Batch.objects.get(id=batch_id)
            batch.delete()
            return JsonResponse({'success': True})
        except Batch.DoesNotExist:
            return JsonResponse({'error': 'Batch not found'}, status=404)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=405)



