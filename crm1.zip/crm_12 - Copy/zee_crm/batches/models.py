from django.db import models
from accounts.models import User
from courses.models import Course

class Batch(models.Model):
    name = models.CharField(max_length=100)
    old_course = models.CharField(max_length=100, null=True, blank=True)  # Legacy field
    course = models.ForeignKey(
        Course,
        on_delete=models.CASCADE,
        related_name='batches',
    )
    students = models.ManyToManyField(
        User,
        related_name='batches_enrolled',
        limit_choices_to={'role': 'student'}
    )
    start_date = models.DateField()
    end_date = models.DateField()
    description = models.TextField(blank=True, null=True)
    max_capacity = models.PositiveIntegerField(default=30)
    status = models.CharField(
        max_length=20,
        choices=[
            ('upcoming', 'Upcoming'),
            ('ongoing', 'Ongoing'),
            ('completed', 'Completed'),
        ],
        default='upcoming'
    )

    def __str__(self):
        return f"{self.name} ({self.course.name})"

    class Meta:
        verbose_name = "Batch"
        verbose_name_plural = "Batches"


        