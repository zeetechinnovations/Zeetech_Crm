from django.urls import path
from . import views

urlpatterns = [
    path('', views.batches_view, name='batches'),
    path('get_batches/', views.get_batches, name='get_batches'),
    path('add/', views.add_batch, name='add_batch'),
    path('delete/<int:batch_id>/', views.delete_batch, name='delete_batch'),
]
