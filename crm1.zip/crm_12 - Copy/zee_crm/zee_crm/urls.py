from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.shortcuts import redirect
from django.views.generic.base import RedirectView

def root_redirect(request):
    return redirect('login')

urlpatterns = [
    path('', root_redirect, name='root-redirect'),
    path('admin/', admin.site.urls),
    path('auth/', include(('accounts.urls', 'accounts'), namespace='accounts')),
    path('auth/', include('django.contrib.auth.urls')),  # Moved to avoid conflict
    path('dashboard/', include('dashboard.urls')),
    path('marketing/', include('marketing.urls')),
    path('students/', include('students.urls')),
    path('favicon.ico', RedirectView.as_view(url='/static/favicon.ico', permanent=True)),
    path('courses/', include('courses.urls')),
    path('batches/', include('batches.urls')),
    path('notifications/', include('notifications.urls')),
    path('payments/', include(('payments.urls', 'payments'), namespace='payments')),
    path('placements/', include('placements.urls')),
    path('study_material/', include('study_material.urls')),
    path('settings/', include('settings.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)



    