
        // Global Variables
        let currentModal = null;

        // Sidebar Toggle
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            const body = document.body;
            sidebar.classList.toggle('open');
            body.classList.toggle('sidebar-open'); // Toggle class to control body scroll
        }

        // Modal Functions
        function openModal(modalId) {
            const modal = document.getElementById(modalId);
            const overlay = document.getElementById('modal-overlay');
            
            if (modal && overlay) {
                modal.style.display = 'block';
                overlay.style.display = 'block';
                currentModal = modalId;
                document.body.style.overflow = 'hidden';
            }
        }

        function closeModal() {
            if (currentModal) {
                const modal = document.getElementById(currentModal);
                const overlay = document.getElementById('modal-overlay');
                
                if (modal && overlay) {
                    modal.style.display = 'none';
                    overlay.style.display = 'none';
                    currentModal = null;
                    document.body.style.overflow = 'auto';
                }
            }
        }

        // Table Search Function
        function searchTable(searchInput, tableId) {
            const filter = searchInput.value.toLowerCase();
            const table = document.getElementById(tableId);
            const rows = table.getElementsByTagName('tr');
            
            for (let i = 1; i < rows.length; i++) {
                const row = rows[i];
                const cells = row.getElementsByTagName('td');
                let found = false;
                
                for (let j = 0; j < cells.length; j++) {
                    if (cells[j].textContent.toLowerCase().includes(filter)) {
                        found = true;
                        break;
                    }
                }
                
                row.style.display = found ? '' : 'none';
            }
        }

        // Contact Actions
        function openWhatsApp(phone, name) {
            const message = encodeURIComponent(`Hi ${name}, I hope you're doing well!`);
            const cleanPhone = phone.replace(/[^0-9]/g, '');
            window.open(`https://wa.me/${cleanPhone}?text=${message}`, '_blank');
        }

        function makeCall(phone) {
            window.open(`tel:${phone}`, '_self');
        }

        function sendEmail(email, name) {
            const subject = encodeURIComponent(`Regarding your inquiry - ${name}`);
            const body = encodeURIComponent(`Dear ${name},\n\nI hope this email finds you well.\n\nBest regards,\nZee-Tech Academy`);
            window.open(`mailto:${email}?subject=${subject}&body=${body}`, '_self');
        }

        // Form Validation
        function validateForm(formId) {
            const form = document.getElementById(formId);
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.style.borderColor = '#ef4444';
                    isValid = false;
                } else {
                    field.style.borderColor = '#ddd';
                }
            });
            
            return isValid;
        }

        // Show Toast Messages
        function showToast(message, type = 'info') {
            const toast = document.createElement('div');
            toast.className = `toast toast-${type}`;
            toast.textContent = message;
            
            const styles = {
                position: 'fixed',
                top: '20px',
                right: '20px',
                padding: '12px 20px',
                borderRadius: '5px',
                color: 'white',
                fontWeight: '500',
                zIndex: '3000',
                minWidth: '200px'
            };
            
            Object.assign(toast.style, styles);
            
            if (type === 'success') toast.style.backgroundColor = '#10b981';
            else if (type === 'error') toast.style.backgroundColor = '#ef4444';
            else if (type === 'warning') toast.style.backgroundColor = '#f59e0b';
            else toast.style.backgroundColor = '#3b82f6';
            
            document.body.appendChild(toast);
            
            setTimeout(() => {
                toast.remove();
            }, 3000);
        }

        // Format Currency
        function formatCurrency(amount) {
            return new Intl.NumberFormat('en-IN', {
                style: 'currency',
                currency: 'INR',
                minimumFractionDigits: 0,
                maximumFractionDigits: 0
            }).format(amount);
        }

        // Date Formatting
        function formatDate(dateString) {
            const date = new Date(dateString);
            return date.toLocaleDateString('en-IN');
        }

        // Initialize on DOM Load
        document.addEventListener('DOMContentLoaded', function() {
            // Set active menu item
            const currentPath = window.location.pathname;
            const menuItems = document.querySelectorAll('.menu-item');
            
            menuItems.forEach(item => {
                if (item.getAttribute('href') === currentPath) {
                    item.classList.add('active');
                }
            });
            
            // Close modal on escape key
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && currentModal) {
                    closeModal();
                }
            });

            // Prevent touch scroll propagation from sidebar to body on mobile
            const sidebar = document.querySelector('.sidebar');
            sidebar.addEventListener('touchstart', function(e) {
                e.stopPropagation(); // Prevent touch events from bubbling to body
            });
            sidebar.addEventListener('touchmove', function(e) {
                e.stopPropagation();
            });
        });
    

        