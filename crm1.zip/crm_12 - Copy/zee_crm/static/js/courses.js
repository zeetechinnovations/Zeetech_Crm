let courses = [];
let editingCourseId = null;

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let cookie of cookies) {
            cookie = cookie.trim();
            if (cookie.startsWith(name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    console.log(`CSRF Token (${name}):`, cookieValue);
    return cookieValue;
}

document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM fully loaded at:', new Date().toISOString());

    const courseForm = document.getElementById('courseForm');
    if (courseForm) {
        console.log('courseForm found, attaching submit event listener');
        courseForm.addEventListener('submit', function(e) {
            e.preventDefault();
            console.log('Save Course button clicked at:', new Date().toISOString());
            saveCourse();
        });
    } else {
        console.error('courseForm not found');
    }

    // Load initial courses from template data
    courses = coursesData || [];
    console.log('Initial courses loaded:', courses);
    loadCourses();

    // Attach filter event listeners
    const courseSearch = document.getElementById('courseSearch');
    const statusFilter = document.getElementById('statusFilter');
    if (courseSearch && statusFilter) {
        console.log('Filter elements found, attaching event listeners');
        courseSearch.addEventListener('keyup', filterCourses);
        statusFilter.addEventListener('change', filterCourses);
    } else {
        console.error('Filter elements not found:', { courseSearch, statusFilter });
    }
});

function refreshCourses() {
    console.log('Fetching courses from server...');
    fetch('/courses/get_courses/', {
        method: 'GET',
        headers: {
            'X-CSRFToken': getCookie('csrftoken'),
        },
    })
    .then(response => {
        console.log('Fetch courses response status:', response.status);
        if (!response.ok) {
            return response.text().then(text => {
                throw new Error(`HTTP error ${response.status}: ${text}`);
            });
        }
        return response.json();
    })
    .then(data => {
        courses = data.courses || [];
        console.log('Courses loaded from server:', courses);
        loadCourses();
    })
    .catch(error => {
        console.error('Error fetching courses:', error);
        showNotification('error', 'Failed to load courses: ' + error.message);
    });
}

function loadCourses(filteredCourses = courses) {
    const tbody = document.getElementById('coursesTableBody');
    if (!tbody) {
        console.error('coursesTableBody not found');
        return;
    }
    tbody.innerHTML = '';
    console.log('Rendering courses:', filteredCourses);

    filteredCourses.forEach(course => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${course.code}</td>
            <td>${course.name}</td>
            <td>${course.duration} months</td>
            <td>₹${course.fee.toLocaleString()}</td>
            <td>${course.enrolled}/${course.max_students}</td>
            <td><span class="status-badge status-${course.status}">${course.status}</span></td>
            ${document.querySelector('meta[name="user-role"]').content === 'admin' ? `
                <td>
                    <div class="contact-actions">
                        <button class="contact-btn" onclick="editCourse(${course.id})" title="Edit">✏️</button>
                        <button class="contact-btn" onclick="deleteCourse(${course.id})" title="Delete">🗑️</button>
                        <button class="contact-btn" onclick="viewCourseDetails(${course.id})" title="View Details">👁</button>
                    </div>
                </td>
            ` : ''}
        `;
        tbody.appendChild(row);
    });
}

function filterCourses() {
    const searchTerm = document.getElementById('courseSearch').value.toLowerCase();
    const statusFilter = document.getElementById('statusFilter').value;

    console.log('Filtering courses with:', { searchTerm, statusFilter });

    const filteredCourses = courses.filter(course => {
        const matchesSearch = course.name.toLowerCase().includes(searchTerm) ||
                             course.code.toLowerCase().includes(searchTerm);
        const matchesStatus = !statusFilter || course.status === statusFilter;

        return matchesSearch && matchesStatus;
    });

    loadCourses(filteredCourses);
}

function openCourseModal() {
    editingCourseId = null;
    document.getElementById('courseModalTitle').textContent = 'Add Course';
    document.getElementById('courseForm').reset();
    document.getElementById('courseModal').style.display = 'block';
    document.getElementById('modal-overlay').style.display = 'block';
    console.log('Course modal opened');
}

function closeCourseModal() {
    document.getElementById('courseModal').style.display = 'none';
    document.getElementById('modal-overlay').style.display = 'none';
    console.log('Course modal closed');
}

function editCourse(courseId) {
    const course = courses.find(c => c.id === courseId);
    if (course) {
        editingCourseId = courseId;
        document.getElementById('courseModalTitle').textContent = 'Edit Course';

        document.getElementById('courseId').value = course.id;
        document.getElementById('courseName').value = course.name;
        document.getElementById('courseCode').value = course.code;
        document.getElementById('courseDuration').value = course.duration;
        document.getElementById('courseFee').value = course.fee;
        document.getElementById('courseDescription').value = course.description || '';
        document.getElementById('maxStudents').value = course.max_students;
        document.getElementById('courseStatus').value = course.status;

        // Handle multiple select for students
        const studentSelect = document.getElementById('students');
        Array.from(studentSelect.options).forEach(option => {
            option.selected = course.students.includes(parseInt(option.value));
        });

        document.getElementById('courseModal').style.display = 'block';
        document.getElementById('modal-overlay').style.display = 'block';
        console.log('Editing course:', courseId);
    }
}

function saveCourse() {
    const courseForm = document.getElementById('courseForm');
    if (!courseForm) {
        console.error('courseForm not found in saveCourse');
        return;
    }

    const formData = new FormData(courseForm);
    console.log('Form data:', Object.fromEntries(formData));

    fetch('/courses/add/', {
        method: 'POST',
        headers: {
            'X-CSRFToken': getCookie('csrftoken'),
        },
        body: formData,
    })
    .then(response => {
        console.log('Save course response status:', response.status);
        if (!response.ok) {
            return response.text().then(text => {
                throw new Error(`HTTP error ${response.status}: ${text}`);
            });
        }
        return response.json();
    })
    .then(data => {
        console.log('Response data:', data);
        if (data.error) {
            showNotification('error', data.error);
            return;
        }
        // Clear filters to ensure new course is visible
        document.getElementById('courseSearch').value = '';
        document.getElementById('statusFilter').value = '';
        showNotification('success', editingCourseId ? 'Course updated successfully!' : 'Course added successfully!');
        refreshCourses(); // Fetch latest courses from server
        closeCourseModal();
    })
    .catch(error => {
        console.error('Fetch error in saveCourse:', error);
        showNotification('error', 'Failed to save course: ' + error.message);
    });
}

function deleteCourse(courseId) {
    if (confirm('Are you sure you want to delete this course?')) {
        fetch(`/courses/delete/${courseId}/`, {
            method: 'POST',
            headers: {
                'X-CSRFToken': getCookie('csrftoken'),
            },
        })
        .then(response => {
            console.log('Delete course response status:', response.status);
            if (!response.ok) {
                return response.text().then(text => {
                    throw new Error(`HTTP error ${response.status}: ${text}`);
                });
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                showNotification('error', data.error);
                return;
            }
            showNotification('success', 'Course deleted successfully!');
            refreshCourses(); // Fetch latest courses
        })
        .catch(error => {
            console.error('Delete error:', error);
            showNotification('error', 'Failed to delete course: ' + error.message);
        });
    }
}

function viewCourseDetails(courseId) {
    const course = courses.find(c => c.id === courseId);
    if (course) {
        alert(`Course Details:\n\nName: ${course.name}\nCode: ${course.code}\nDuration: ${course.duration} months\nFee: ₹${course.fee.toLocaleString()}\nEnrolled: ${course.enrolled}/${course.max_students}\nStatus: ${course.status}\nDescription: ${course.description || 'N/A'}`);
    }
}

function showNotification(type, message) {
    console.log('Showing notification:', { type, message });
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <span class="icon">${type === 'success' ? '✅' : '❌'}</span>
        <span>${message}</span>
    `;
    document.body.appendChild(notification);
    setTimeout(() => notification.classList.add('show'), 100);
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => document.body.removeChild(notification), 300);
    }, 3000);
}
