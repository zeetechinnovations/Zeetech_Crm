function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let cookie of cookies) {
            cookie = cookie.trim();
            if (cookie.startsWith(name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

function showNotification(type, message) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <span class="icon">${type === 'success' ? '✅' : '❌'}</span>
        <span>${message}</span>
    `;
    document.body.appendChild(notification);
    setTimeout(() => notification.classList.add('show'), 100);
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

function openPlacementModal(placement = null) {
    const modal = document.getElementById('placementModal');
    const form = document.getElementById('placementForm');
    const modalTitle = document.getElementById('placementModalTitle');

    if (!modal || !form) {
        console.error('Modal or form not found');
        return;
    }

    // Reset form
    form.reset();
    document.getElementById('placementId').value = '';

    if (placement) {
        // Edit mode
        modalTitle.textContent = 'Edit Placement';
        document.getElementById('placementId').value = placement.id;
        document.getElementById('studentName').value = placement.student_name;
        document.getElementById('companyName').value = placement.company_name;
        document.getElementById('jobPosition').value = placement.job_position;
        document.getElementById('course').value = placement.course;
        document.getElementById('salary').value = placement.salary;
        document.getElementById('placementDate').value = placement.placement_date;
        document.getElementById('placementStatus').value = placement.status;
        document.getElementById('location').value = placement.location || '';
        document.getElementById('notes').value = placement.notes || '';
    } else {
        // Add mode
        modalTitle.textContent = 'Add Placement';
    }

    modal.style.display = 'block';
}

function closePlacementModal() {
    const modal = document.getElementById('placementModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

function loadPlacementMetrics() {
    fetch('/placements/api/placements/metrics/', {
        method: 'GET',
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('totalPlacements').textContent = data.totalPlacements;
        document.getElementById('avgPackage').textContent = data.avgPackage;
        document.getElementById('maxPackage').textContent = data.maxPackage;
        document.getElementById('placementRate').textContent = data.placementRate;
    })
    .catch(err => {
        console.error('Error loading metrics:', err);
        showNotification('error', 'Failed to load metrics');
    });
}

function loadPlacements() {
    const tableBody = document.getElementById('placementsTableBody');
    const searchQuery = document.getElementById('placementSearch').value;
    const statusFilter = document.getElementById('statusFilter').value;
    const courseFilter = document.getElementById('courseFilter').value;

    if (!tableBody) {
        console.error('Table body found');
        return;
    }

    const url = new URL('/placements/api/placements/', window.location.origin);
    if (searchQuery) url.searchParams.append('search', searchQuery);
    if (statusFilter) url.searchParams.append('status', statusFilter);
    if (courseFilter) url.searchParams.append('course', courseFilter);

    fetch(url, {
        method: 'GET',
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        tableBody.innerHTML = '';
        if (data.placements.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="8">No placements found.</td></tr>';
        } else {
            data.placements.forEach(placement => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${placement.student_name}</td>
                    <td>${placement.company_name}</td>
                    ${placement.job_position}
                    <td>${placement.course}</td>
                    <td>₹${parseFloat(placement.salary).toLocaleString('en-IN')}</td>
                    <td>${placement.placement_date || '-'}</td>
                    <td><span class="status-badge status-${placement.status}">${placement.status}</span></td>
                    <td>
                        <div class="contact-actions">
                            <button class="contact-btn" onclick='openPlacementModal(${JSON.stringify(placement)})' title="Edit">✏️</button>
                            <button class="contact-btn" onclick="deletePlacement(${placement.id})" title="Delete">🗑️</button>
                        </div>
                    </td>
                `;
                tableBody.appendChild(row);
            });
        }
    })
    .catch(err => {
        console.error('Error loading placements:', err);
        showNotification('error', 'Failed to load placements');
    });
}

function filterPlacements() {
    loadPlacements();
}

function deletePlacement(id) {
    if (confirm('Are you sure you want to delete this placement?')) {
        fetch(`/placements/api/placements/delete/${id}/`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCookie('csrftoken'),
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                showNotification('success', data.message);
                loadPlacements();
            } else {
                showNotification('error', data.message);
            }
        })
        .catch(err => {
            console.error('Error deleting placement:', err);
            showNotification('error', 'Failed to delete placement');
        });
    }
}

function handlePlacementFormSubmit(event) {
    event.preventDefault();
    const form = event.target;
    const formData = {
        placement_id: form.querySelector('#placementId').value,
        student_name: form.querySelector('#studentName').value,
        company_name: form.querySelector('#companyName').value,
        job_position: form.querySelector('#jobPosition').value,
        course: form.querySelector('#course').value,
        salary: form.querySelector('#salary').value,
        placement_date: form.querySelector('#placementDate').value,
        status: form.querySelector('#placementStatus').value,
        location: form.querySelector('#location').value,
        notes: form.querySelector('#notes').value
    };

    // Client-side validation
    if (!formData.student_name) {
        showNotification('error', 'Please enter student name');
        return;
    }
    if (!formData.company_name) {
        showNotification('error', 'Please enter company name');
        return;
    }
    if (!formData.job_position) {
        showNotification('error', 'Please enter job position');
        return;
    }
    if (!formData.course) {
        showNotification('error', 'Please select a course');
        return;
    }
    if (!formData.salary || formData.salary <= 0) {
        showNotification('error', 'Please enter a valid salary');
        return;
    }

    fetch('/placements/api/placements/create/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken'),
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showNotification('success', data.message);
            loadPlacements();
            closePlacementModal();
        } else {
            showNotification('error', data.message);
        }
    })
    .catch(err => {
        console.error('Error submitting form:', err);
        showNotification('error', 'Failed to save placement');
    });
}

function exportPlacements() {
    // Placeholder for export functionality
    showNotification('info', 'Export functionality not implemented yet');
}

function generateReport() {
    // Placeholder for report generation
    showNotification('info', 'Report generation not implemented yet');
}

document.addEventListener('DOMContentLoaded', () => {
    console.log('DOMContentLoaded, initializing placements page');
    loadPlacementMetrics();
    loadPlacements();

    const placementForm = document.getElementById('placementForm');
    if (placementForm) {
        placementForm.addEventListener('submit', handlePlacementFormSubmit);
    }

    const addPlacementButtons = document.querySelectorAll('.placementBtnPrimary');
    addPlacementButtons.forEach(button => {
        button.addEventListener('click', () => openPlacementModal());
    });

    const closeModalButtons = document.querySelectorAll('.placementModalClose, .placementBtnSecondary');
    closeModalButtons.forEach(button => {
        button.addEventListener('click', closePlacementModal);
    });

    const searchInput = document.getElementById('placementSearch');
    const statusFilter = document.getElementById('statusFilter');
    const courseFilter = document.getElementById('courseFilter');

    if (searchInput) searchInput.addEventListener('keyup', filterPlacements);
    if (statusFilter) statusFilter.addEventListener('change', filterPlacements);
    if (courseFilter) courseFilter.addEventListener('change', filterPlacements);
});

