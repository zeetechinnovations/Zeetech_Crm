function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let cookie of cookies) {
            cookie = cookie.trim();
            if (cookie.startsWith(name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    console.log(`CSRF Token (${name}):`, cookieValue);
    return cookieValue;
}

function showNotification(type, message) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <span class="icon">${type === 'success' ? '✅' : '❌'}</span>
        <span>${message}</span>
    `;
    document.body.appendChild(notification);
    setTimeout(() => notification.classList.add('show'), 100);
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => document.body.removeChild(notification), 300);
    }, 3000);
}

function updateDashboard() {
    const filterType = document.getElementById('filterType')?.value || 'all';
    const startDate = document.getElementById('startDate')?.value || '';
    const endDate = document.getElementById('endDate')?.value || '';

    const revenueCanvas = document.getElementById('revenueChart');
    const enrollmentCanvas = document.getElementById('enrollmentChart');
    if (!revenueCanvas || !enrollmentCanvas) {
        console.error('Chart canvas elements not found');
        showNotification('error', 'Chart elements missing');
        return;
    }

    fetch('/dashboard/data/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken'),
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({ filterType, startDate, endDate })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.error) {
            throw new Error(data.error);
        }

        // Update metric values with proper formatting
        document.getElementById('totalStudents').textContent = data.total_students || 0;
        document.getElementById('totalRevenue').textContent = `₹${(data.total_revenue || 0).toLocaleString('en-IN')}`;
        document.getElementById('pendingPayments').textContent = data.pending_payments || 0;
        document.getElementById('totalCourses').textContent = data.total_courses || 0;
        document.getElementById('activeBatches').textContent = data.active_batches || 0;

        console.log('Dashboard data:', data);

        // Safely destroy existing charts
        if (window.revenueChart && typeof window.revenueChart.destroy === 'function') {
            window.revenueChart.destroy();
        }
        if (window.enrollmentChart && typeof window.enrollmentChart.destroy === 'function') {
            window.enrollmentChart.destroy();
        }

        // Revenue Chart (Line)
        window.revenueChart = new Chart(revenueCanvas, {
            type: 'line',
            data: {
                labels: data.revenue_labels && data.revenue_labels.length ? data.revenue_labels : ['No Data'],
                datasets: [{
                    label: 'Revenue (₹)',
                    data: data.revenue_data && data.revenue_data.length ? data.revenue_data : [0],
                    borderColor: '#007bff',
                    backgroundColor: 'rgba(0, 123, 255, 0.1)',
                    fill: true,
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: { display: true, text: 'Revenue (₹)' },
                        ticks: {
                            callback: function(value) {
                                return '₹' + value.toLocaleString('en-IN');
                            }
                        }
                    },
                    x: { 
                        title: { display: true, text: 'Month' }
                    }
                }
            }
        });

        // Enrollment Chart (Pie)
        window.enrollmentChart = new Chart(enrollmentCanvas, {
            type: 'pie',
            data: {
                labels: data.enrollment_labels && data.enrollment_labels.length ? data.enrollment_labels : ['No Data'],
                datasets: [{
                    data: data.enrollment_data && data.enrollment_data.length ? data.enrollment_data : [0],
                    backgroundColor: ['#007bff', '#28a745', '#dc3545', '#6f42c1', '#fd7e14'],
                    hoverOffset: 20
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { 
                        position: 'top',
                        labels: {
                            font: {
                                size: 12
                            }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.label || '';
                                let value = context.parsed || 0;
                                let sum = context.dataset.data.reduce((a, b) => a + b, 0);
                                let percentage = Math.round((value / sum) * 100);
                                return `${label}: ${value} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });

        showNotification('success', 'Dashboard updated successfully');
    })
    .catch(error => {
        console.error('Error updating dashboard:', error);
        showNotification('error', `Failed to update dashboard: ${error.message}`);
    });
}

function resetFilters() {
    const filterType = document.getElementById('filterType');
    const startDate = document.getElementById('startDate');
    const endDate = document.getElementById('endDate');
    if (filterType) filterType.value = 'all';
    if (startDate) startDate.value = '';
    if (endDate) endDate.value = '';
    updateDashboard();
}

function showDetails(type) {
    const titles = {
        'students': 'All Students',
        'courses': 'All Courses',
        'batches': 'All Batches',
        'payment-done': 'Payments Received',
        'payment-due': 'Pending Payments'
    };
    const urls = {
        'students': '/students/students/',
        'courses': '/courses/',
        'batches': '/batches/',
        'payment-done': '/payments/?status=paid',
        'payment-due': '/payments/?status=pending'
    };

    const detailsTitle = document.getElementById('detailsTitle');
    const detailsContent = document.getElementById('detailsContent');
    if (detailsTitle && detailsContent) {
        detailsTitle.textContent = titles[type] || 'Details';
        detailsContent.innerHTML = `
            <p>Loading ${titles[type] || 'data'}...</p>
            <p><a href="${urls[type] || '#'}" class="btn btn-primary">View Full Details</a></p>
        `;
        openModal();
    } else {
        console.error('Modal elements not found');
    }
}

function openModal() {
    const modal = document.getElementById('detailsModal');
    if (modal) modal.style.display = 'flex';
}

function closeModal() {
    const modal = document.getElementById('detailsModal');
    if (modal) modal.style.display = 'none';
}

document.addEventListener('DOMContentLoaded', () => {
    console.log('Dashboard JS loaded');
    updateDashboard();
});

