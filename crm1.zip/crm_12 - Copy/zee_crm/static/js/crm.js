const ZeeTechCRM = {
  // Utility Functions
  utils: {
    getCsrfToken() {
      return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
    },

    showNotification(message, type = 'success') {
      const notification = document.createElement('div');
      notification.className = 'notification';
      notification.textContent = message;
      notification.style.background = type === 'success' ? '#27ae60' : '#e74c3c';
      notification.style.position = 'fixed';
      notification.style.top = '20px';
      notification.style.right = '20px';
      notification.style.padding = '1rem 2rem';
      notification.style.borderRadius = '8px';
      notification.style.boxShadow = '0 4px 15px rgba(0, 0, 0, 0.2)';
      notification.style.opacity = '0';
      notification.style.transform = 'translateX(100px)';
      notification.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
      notification.style.zIndex = '1000';
      notification.style.fontSize = '1rem';
      notification.style.fontWeight = '500';
      document.body.appendChild(notification);

      setTimeout(() => notification.classList.add('show'), 100);
      setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 500);
      }, 3000);
    },

    async sendAjaxRequest(url, method, data, contentType = 'application/json') {
      const headers = {
        'X-CSRFToken': this.getCsrfToken(),
      };
      if (contentType) headers['Content-Type'] = contentType;

      try {
        const response = await fetch(url, {
          method,
          headers,
          body: method !== 'GET' ? (contentType === 'application/json' ? JSON.stringify(data) : data) : undefined,
        });
        return await response.json();
      } catch (error) {
        console.error('AJAX Error:', error);
        this.showNotification('An error occurred. Please try again.', 'error');
        throw error;
      }
    },

    openModal(modalId) {
      const modal = document.getElementById(modalId);
      if (modal) modal.style.display = 'block';
    },

    closeModal(modalId) {
      const modal = document.getElementById(modalId);
      if (modal) {
        modal.style.display = 'none';
        const form = modal.querySelector('form');
        if (form) form.reset();
      }
    },
  },

  // Batches Page (batches.html)
  batches: {
    init() {
      if (!document.getElementById('batchesTable')) return;

      // Sample data (replace with API call)
      const batches = [
        { id: 'B001', name: 'Batch 2024-A', course: 'Full Stack Development', startDate: '2024-01-10', endDate: '2024-06-10', students: 30, status: 'Ongoing' },
        { id: 'B002', name: 'Batch 2024-B', course: 'Data Science', startDate: '2024-02-15', endDate: '2024-07-15', students: 25, status: 'Upcoming' },
      ];

      const loadBatches = () => {
        const tbody = document.getElementById('batchesTableBody');
        if (!tbody) return;
        tbody.innerHTML = '';
        batches.forEach(batch => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${batch.id}</td>
            <td>${batch.name}</td>
            <td>${batch.course}</td>
            <td>${batch.startDate}</td>
            <td>${batch.endDate}</td>
            <td>${batch.students}</td>
            <td><span class="status-badge status-${batch.status.toLowerCase()}">${batch.status}</span></td>
            <td>
              <button class="contact-btn" onclick="ZeeTechCRM.batches.editBatch('${batch.id}')">✏</button>
              <button class="contact-btn" onclick="ZeeTechCRM.batches.deleteBatch('${batch.id}')">🗑</button>
            </td>
          `;
          tbody.appendChild(row);
        });
      };

      this.filterBatches = () => {
        const searchTerm = document.getElementById('batchSearch')?.value.toLowerCase() || '';
        const courseFilter = document.getElementById('courseFilter')?.value.toLowerCase() || '';
        const statusFilter = document.getElementById('batchStatusFilter')?.value.toLowerCase() || '';

        const filteredBatches = batches.filter(batch => {
          return (
            (batch.name.toLowerCase().includes(searchTerm) || batch.id.toLowerCase().includes(searchTerm)) &&
            (courseFilter === '' || batch.course.toLowerCase().includes(courseFilter)) &&
            (statusFilter === '' || batch.status.toLowerCase() === statusFilter)
          );
        });

        const tbody = document.getElementById('batchesTableBody');
        if (!tbody) return;
        tbody.innerHTML = '';
        filteredBatches.forEach(batch => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${batch.id}</td>
            <td>${batch.name}</td>
            <td>${batch.course}</td>
            <td>${batch.startDate}</td>
            <td>${batch.endDate}</td>
            <td>${batch.students}</td>
            <td><span class="status-badge status-${batch.status.toLowerCase()}">${batch.status}</span></td>
            <td>
              <button class="contact-btn" onclick="ZeeTechCRM.batches.editBatch('${batch.id}')">✏</button>
              <button class="contact-btn" onclick="ZeeTechCRM.batches.deleteBatch('${batch.id}')">🗑</button>
            </td>
          `;
          tbody.appendChild(row);
        });
      };

      this.openBatchModal = () => {
        const title = document.getElementById('batchModalTitle');
        if (title) title.textContent = 'Create Batch';
        const batchId = document.getElementById('batchId');
        if (batchId) batchId.value = '';
        ZeeTechCRM.utils.openModal('batchModal');
      };

      this.closeBatchModal = () => ZeeTechCRM.utils.closeModal('batchModal');

      this.editBatch = (id) => {
        const batch = batches.find(b => b.id === id);
        if (batch) {
          const title = document.getElementById('batchModalTitle');
          if (title) title.textContent = 'Edit Batch';
          document.getElementById('batchId').value = batch.id;
          document.getElementById('batchName').value = batch.name;
          document.getElementById('batchCourse').value = batch.course.toLowerCase().replace(' ', '-');
          document.getElementById('startDate').value = batch.startDate;
          document.getElementById('endDate').value = batch.endDate;
          document.getElementById('maxCapacity').value = batch.students;
          document.getElementById('batchStatus').value = batch.status.toLowerCase();
          ZeeTechCRM.utils.openModal('batchModal');
        }
      };

      this.deleteBatch = (id) => {
        if (confirm('Are you sure you want to delete this batch?')) {
          const index = batches.findIndex(b => b.id === id);
          if (index !== -1) {
            batches.splice(index, 1);
            loadBatches();
            ZeeTechCRM.utils.showNotification('Batch deleted successfully!', 'success');
          }
        }
      };

      const batchForm = document.getElementById('batchForm');
      if (batchForm) {
        batchForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const formData = new FormData(e.target);
          const data = Object.fromEntries(formData);
          // Replace with API call: ZeeTechCRM.utils.sendAjaxRequest('/api/batches/', data.batch_id ? 'PUT' : 'POST', data);
          if (data.batch_id) {
            const batch = batches.find(b => b.id === data.batch_id);
            if (batch) {
              batch.name = data.batch_name;
              batch.course = data.course.replace('-', ' ').replace(/\b\w/g, c => c.toUpperCase());
              batch.startDate = data.start_date;
              batch.endDate = data.end_date;
              batch.students = data.max_capacity;
              batch.status = data.status.charAt(0).toUpperCase() + data.status.slice(1);
            }
            ZeeTechCRM.utils.showNotification('Batch updated successfully!', 'success');
          } else {
            batches.push({
              id: `B00${batches.length + 1}`,
              name: data.batch_name,
              course: data.course.replace('-', ' ').replace(/\b\w/g, c => c.toUpperCase()),
              startDate: data.start_date,
              endDate: data.end_date,
              students: data.max_capacity,
              status: data.status.charAt(0).toUpperCase() + data.status.slice(1),
            });
            ZeeTechCRM.utils.showNotification('Batch created successfully!', 'success');
          }
          loadBatches();
          ZeeTechCRM.utils.closeModal('batchModal');
        });
      }

      loadBatches();
    },
  },

  // Courses Page (courses.html)
  courses: {
    init() {
      if (!document.getElementById('coursesTable')) return;

      const courses = [
        { id: 'C001', name: 'Full Stack Development', duration: 6, fee: 60000, enrolled: 120, status: 'Active' },
        { id: 'C002', name: 'Data Science', duration: 5, fee: 55000, enrolled: 80, status: 'Upcoming' },
      ];

      const loadCourses = () => {
        const tbody = document.getElementById('coursesTableBody');
        if (!tbody) return;
        tbody.innerHTML = '';
        courses.forEach(course => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${course.id}</td>
            <td>${course.name}</td>
            <td>${course.duration} Months</td>
            <td>₹${course.fee}</td>
            <td>${course.enrolled}</td>
            <td><span class="status-badge status-${course.status.toLowerCase()}">${course.status}</span></td>
            <td>
              <button class="contact-btn" onclick="ZeeTechCRM.courses.editCourse('${course.id}')">✏</button>
              <button class="contact-btn" onclick="ZeeTechCRM.courses.deleteCourse('${course.id}')">🗑</button>
            </td>
          `;
          tbody.appendChild(row);
        });
      };

      this.filterCourses = () => {
        const searchTerm = document.getElementById('courseSearch')?.value.toLowerCase() || '';
        const statusFilter = document.getElementById('statusFilter')?.value.toLowerCase() || '';

        const filteredCourses = courses.filter(course => {
          return (
            (course.name.toLowerCase().includes(searchTerm) || course.id.toLowerCase().includes(searchTerm)) &&
            (statusFilter === '' || course.status.toLowerCase() === statusFilter)
          );
        });

        const tbody = document.getElementById('coursesTableBody');
        if (!tbody) return;
        tbody.innerHTML = '';
        filteredCourses.forEach(course => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${course.id}</td>
            <td>${course.name}</td>
            <td>${course.duration} Months</td>
            <td>₹${course.fee}</td>
            <td>${course.enrolled}</td>
            <td><span class="status-badge status-${course.status.toLowerCase()}">${course.status}</span></td>
            <td>
              <button class="contact-btn" onclick="ZeeTechCRM.courses.editCourse('${course.id}')">✏</button>
              <button class="contact-btn" onclick="ZeeTechCRM.courses.deleteCourse('${course.id}')">🗑</button>
            </td>
          `;
          tbody.appendChild(row);
        });
      };

      this.openCourseModal = () => {
        const title = document.getElementById('courseModalTitle');
        if (title) title.textContent = 'Add Course';
        const courseId = document.getElementById('courseId');
        if (courseId) courseId.value = '';
        ZeeTechCRM.utils.openModal('courseModal');
      };

      this.closeCourseModal = () => ZeeTechCRM.utils.closeModal('courseModal');

      this.editCourse = (id) => {
        const course = courses.find(c => c.id === id);
        if (course) {
          const title = document.getElementById('courseModalTitle');
          if (title) title.textContent = 'Edit Course';
          document.getElementById('courseId').value = course.id;
          document.getElementById('courseName').value = course.name;
          document.getElementById('courseCode').value = course.id;
          document.getElementById('courseDuration').value = course.duration;
          document.getElementById('courseFee').value = course.fee;
          document.getElementById('maxStudents').value = course.enrolled;
          document.getElementById('courseStatus').value = course.status.toLowerCase();
          ZeeTechCRM.utils.openModal('courseModal');
        }
      };

      this.deleteCourse = (id) => {
        if (confirm('Are you sure you want to delete this course?')) {
          const index = courses.findIndex(c => c.id === id);
          if (index !== -1) {
            courses.splice(index, 1);
            loadCourses();
            ZeeTechCRM.utils.showNotification('Course deleted successfully!', 'success');
          }
        }
      };

      const courseForm = document.getElementById('courseForm');
      if (courseForm) {
        courseForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const formData = new FormData(e.target);
          const data = Object.fromEntries(formData);
          // Replace with API call: ZeeTechCRM.utils.sendAjaxRequest('/api/courses/', data.course_id ? 'PUT' : 'POST', data);
          if (data.course_id) {
            const course = courses.find(c => c.id === data.course_id);
            if (course) {
              course.name = data.course_name;
              course.duration = parseInt(data.duration);
              course.fee = parseInt(data.fee);
              course.enrolled = parseInt(data.max_students);
              course.status = data.status.charAt(0).toUpperCase() + data.status.slice(1);
            }
            ZeeTechCRM.utils.showNotification('Course updated successfully!', 'success');
          } else {
            courses.push({
              id: `C00${courses.length + 1}`,
              name: data.course_name,
              duration: parseInt(data.duration),
              fee: parseInt(data.fee),
              enrolled: parseInt(data.max_students),
              status: data.status.charAt(0).toUpperCase() + data.status.slice(1),
            });
            ZeeTechCRM.utils.showNotification('Course added successfully!', 'success');
          }
          loadCourses();
          ZeeTechCRM.utils.closeModal('courseModal');
        });
      }

      loadCourses();
    },
  },

  // Add Marketing Data Page (add_marketing_data.html)
  addMarketingData: {
    init() {
      if (!document.getElementById('uploadForm')) return;

      this.downloadTemplate = () => {
        ZeeTechCRM.utils.showNotification('Template downloaded successfully!', 'success');
      };

      const uploadForm = document.getElementById('uploadForm');
      if (uploadForm) {
        uploadForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const formData = new FormData(e.target);
          const progressBar = document.querySelector('#uploadProgress .progress-fill');
          const progressText = document.querySelector('#uploadProgress .progress-text');
          const uploadProgress = document.getElementById('uploadProgress');
          const uploadResult = document.getElementById('uploadResult');

          if (!progressBar || !progressText || !uploadProgress || !uploadResult) return;

          uploadProgress.classList.remove('hidden');
          let progress = 0;
          const interval = setInterval(() => {
            progress += 10;
            progressBar.style.width = `${progress}%`;
            progressText.textContent = `Uploading... ${progress}%`;
            if (progress >= 100) {
              clearInterval(interval);
              uploadProgress.classList.add('hidden');
              // Replace with API call: ZeeTechCRM.utils.sendAjaxRequest('/api/marketing/upload/', 'POST', formData, null);
              uploadResult.classList.remove('hidden');
              uploadResult.textContent = 'File uploaded successfully!';
              ZeeTechCRM.utils.showNotification('Marketing data uploaded successfully!', 'success');
              e.target.reset();
            }
          }, 200);
        });
      }

      const manualEntryForm = document.getElementById('manualEntryForm');
      if (manualEntryForm) {
        manualEntryForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const formData = new FormData(e.target);
          // Replace with API call: ZeeTechCRM.utils.sendAjaxRequest('/api/marketing/leads/', 'POST', formData);
          ZeeTechCRM.utils.showNotification('Lead added successfully!', 'success');
          e.target.reset();
        });
      }
    },
  },

  // Marketing Sales Page (marketing_sales.html)
  marketingSales: {
    init() {
      if (!document.getElementById('leadsTable')) return;

      const leads = [
        { id: 'L001', name: 'John Doe', email: 'john@example.com', phone: '9876543210', course: 'Full Stack Development', status: 'Hot Lead', source: 'Website' },
        { id: 'L002', name: 'Jane Smith', email: 'jane@example.com', phone: '9876543211', course: 'Data Science', status: 'Converted', source: 'Referral' },
      ];

      const loadLeads = () => {
        const tbody = document.getElementById('leadsTableBody');
        if (!tbody) return;
        tbody.innerHTML = '';
        leads.forEach(lead => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${lead.id}</td>
            <td>${lead.name}</td>
            <td>${lead.email}</td>
            <td>${lead.phone}</td>
            <td>${lead.course}</td>
            <td><span class="status-badge status-${lead.status.toLowerCase().replace(' ', '-')}">${lead.status}</span></td>
            <td>${lead.source}</td>
            <td>
              <button class="contact-btn" onclick="ZeeTechCRM.marketingSales.editLead('${lead.id}')">✏</button>
              <button class="contact-btn" onclick="ZeeTechCRM.marketingSales.deleteLead('${lead.id}')">🗑</button>
            </td>
          `;
          tbody.appendChild(row);
        });
      };

      this.filterLeads = () => {
        const searchTerm = document.getElementById('leadSearch')?.value.toLowerCase() || '';
        const statusFilter = document.getElementById('statusFilter')?.value.toLowerCase() || '';
        const sourceFilter = document.getElementById('sourceFilter')?.value.toLowerCase() || '';

        const filteredLeads = leads.filter(lead => {
          return (
            (lead.name.toLowerCase().includes(searchTerm) || lead.email.toLowerCase().includes(searchTerm)) &&
            (statusFilter === '' || lead.status.toLowerCase().replace(' ', '-') === statusFilter) &&
            (sourceFilter === '' || lead.source.toLowerCase() === sourceFilter)
          );
        });

        const tbody = document.getElementById('leadsTableBody');
        if (!tbody) return;
        tbody.innerHTML = '';
        filteredLeads.forEach(lead => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${lead.id}</td>
            <td>${lead.name}</td>
            <td>${lead.email}</td>
            <td>${lead.phone}</td>
            <td>${lead.course}</td>
            <td><span class="status-badge status-${lead.status.toLowerCase().replace(' ', '-')}">${lead.status}</span></td>
            <td>${lead.source}</td>
            <td>
              <button class="contact-btn" onclick="ZeeTechCRM.marketingSales.editLead('${lead.id}')">✏</button>
              <button class="contact-btn" onclick="ZeeTechCRM.marketingSales.deleteLead('${lead.id}')">🗑</button>
            </td>
          `;
          tbody.appendChild(row);
        });
      };

      this.openLeadModal = () => ZeeTechCRM.utils.openModal('leadModal');

      this.closeLeadModal = () => ZeeTechCRM.utils.closeModal('leadModal');

      this.editLead = (id) => {
        const lead = leads.find(l => l.id === id);
        if (lead) {
          document.getElementById('leadName').value = lead.name;
          document.getElementById('leadEmail').value = lead.email;
          document.getElementById('leadPhone').value = lead.phone;
          document.getElementById('leadCourse').value = lead.course.toLowerCase().replace(' ', '-');
          document.getElementById('leadStatus').value = lead.status.toLowerCase().replace(' ', '-');
          document.getElementById('leadSource').value = lead.source.toLowerCase();
          ZeeTechCRM.utils.openModal('leadModal');
        }
      };

      this.deleteLead = (id) => {
        if (confirm('Are you sure you want to delete this lead?')) {
          const index = leads.findIndex(l => l.id === id);
          if (index !== -1) {
            leads.splice(index, 1);
            loadLeads();
            ZeeTechCRM.utils.showNotification('Lead deleted successfully!', 'success');
          }
        }
      };

      this.exportLeads = () => {
        ZeeTechCRM.utils.showNotification('Leads exported successfully!', 'success');
      };

      this.sendBulkEmail = () => {
        ZeeTechCRM.utils.showNotification('Bulk email sent successfully!', 'success');
      };

      const leadForm = document.getElementById('leadForm');
      if (leadForm) {
        leadForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const formData = new FormData(e.target);
          const data = Object.fromEntries(formData);
          // Replace with API call: ZeeTechCRM.utils.sendAjaxRequest('/api/leads/', 'POST', data);
          leads.push({
            id: `L00${leads.length + 1}`,
            name: data.name,
            email: data.email,
            phone: data.phone,
            course: data.course ? data.course.replace('-', ' ').replace(/\b\w/g, c => c.toUpperCase()) : 'N/A',
            status: data.status ? data.status.replace('-', ' ').replace(/\b\w/g, c => c.toUpperCase()) : 'Enquiry',
            source: data.source ? data.source.replace('-', ' ').replace(/\b\w/g, c => c.toUpperCase()) : 'N/A',
          });
          loadLeads();
          ZeeTechCRM.utils.showNotification('Lead added successfully!', 'success');
          ZeeTechCRM.utils.closeModal('leadModal');
        });
      }

      loadLeads();
    },
  },

  // Notifications Page (notifications.html)
  notifications: {
    init() {
      if (!document.getElementById('notificationForm')) return;

      const notifications = [
        { id: 1, type: 'payment', title: 'Payment Reminder', message: 'Your payment is due on 2025-06-10.', date: '2025-06-03', read: false },
        { id: 2, type: 'course', title: 'Course Update', message: 'New module added to Full Stack Development.', date: '2025-06-02', read: true },
      ];

      const loadNotifications = () => {
        const list = document.getElementById('notificationsList');
        if (!list) return;
        list.innerHTML = '';
        notifications.forEach(notif => {
          const item = document.createElement('div');
          item.className = `notification-item ${notif.read ? '' : 'unread'}`;
          item.innerHTML = `
            <div class="notification-icon ${notif.type}">${notif.type.charAt(0).toUpperCase()}</div>
            <div class="notification-content">
              <div class="notification-title">${notif.title}</div>
              <div class="notification-message">${notif.message}</div>
              <div class="notification-meta">${notif.date}</div>
            </div>
            <div class="notification-actions">
              <button class="btn btn-sm btn-primary" onclick="ZeeTechCRM.notifications.markRead(${notif.id})">${notif.read ? 'Mark Unread' : 'Mark Read'}</button>
              <button class="btn btn-sm btn-danger" onclick="ZeeTechCRM.notifications.deleteNotification(${notif.id})">Delete</button>
            </div>
          `;
          list.appendChild(item);
        });
      };

      this.filterNotifications = () => {
        const statusFilter = document.getElementById('statusFilter')?.value.toLowerCase() || '';
        const typeFilter = document.getElementById('typeFilter')?.value.toLowerCase() || '';

        const filteredNotifications = notifications.filter(notif => {
          const matchesStatus = statusFilter === '' || (statusFilter === 'read' && notif.read) || (statusFilter === 'unread' && !notif.read);
          const matchesType = typeFilter === '' || notif.type.toLowerCase() === typeFilter;
          return matchesStatus && matchesType;
        });

        const list = document.getElementById('notificationsList');
        if (!list) return;
        list.innerHTML = '';
        filteredNotifications.forEach(notif => {
          const item = document.createElement('div');
          item.className = `notification-item ${notif.read ? '' : 'unread'}`;
          item.innerHTML = `
            <div class="notification-icon ${notif.type}">${notif.type.charAt(0).toUpperCase()}</div>
            <div class="notification-content">
              <div class="notification-title">${notif.title}</div>
              <div class="notification-message">${notif.message}</div>
              <div class="notification-meta">${notif.date}</div>
            </div>
            <div class="notification-actions">
              <button class="btn btn-sm btn-primary" onclick="ZeeTechCRM.notifications.markRead(${notif.id})">${notif.read ? 'Mark Unread' : 'Mark Read'}</button>
              <button class="btn btn-sm btn-danger" onclick="ZeeTechCRM.notifications.deleteNotification(${notif.id})">Delete</button>
            </div>
          `;
          list.appendChild(item);
        });
      };

      this.markRead = (id) => {
        const notif = notifications.find(n => n.id === id);
        if (notif) {
          notif.read = !notif.read;
          loadNotifications();
          ZeeTechCRM.utils.showNotification(`Notification marked as ${notif.read ? 'read' : 'unread'}!`, 'success');
        }
      };

      this.deleteNotification = (id) => {
        if (confirm('Are you sure you want to delete this notification?')) {
          const index = notifications.findIndex(n => n.id === id);
          if (index !== -1) {
            notifications.splice(index, 1);
            loadNotifications();
            ZeeTechCRM.utils.showNotification('Notification deleted successfully!', 'success');
          }
        }
      };

      this.markAllRead = () => {
        notifications.forEach(notif => notif.read = true);
        loadNotifications();
        ZeeTechCRM.utils.showNotification('All notifications marked as read!', 'success');
      };

      const notificationForm = document.getElementById('notificationForm');
      if (notificationForm) {
        notificationForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const formData = new FormData(e.target);
          const data = Object.fromEntries(formData);
          // Replace with API call: ZeeTechCRM.utils.sendAjaxRequest('/api/notifications/', 'POST', data);
          notifications.push({
            id: notifications.length + 1,
            type: data.type,
            title: data.title,
            message: data.message,
            date: '2025-06-03',
            read: false,
          });
          loadNotifications();
          ZeeTechCRM.utils.showNotification('Notification sent successfully!', 'success');
          e.target.reset();
        });
      }

      const recipientsSelect = document.getElementById('recipients');
      const courseSelectGroup = document.getElementById('courseSelectGroup');
      if (recipientsSelect && courseSelectGroup) {
        recipientsSelect.addEventListener('change', () => {
          courseSelectGroup.style.display = recipientsSelect.value === 'course-specific' ? 'block' : 'none';
        });
      }

      loadNotifications();
    },
  },

  // Payments Page (payments.html)
  payments: {
    init() {
      if (!document.getElementById('paymentsTable')) return;

      const payments = [
        { id: 'P001', student: 'John Doe', course: 'Full Stack Development', amount: 15000, method: 'Online', date: '2025-06-01', status: 'Paid' },
        { id: 'P002', student: 'Jane Smith', course: 'Data Science', amount: 12000, method: 'Cash', date: '2025-06-02', status: 'Pending' },
      ];

      const loadPayments = () => {
        const tbody = document.getElementById('paymentsTableBody');
        if (!tbody) return;
        tbody.innerHTML = '';
        payments.forEach(payment => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${payment.id}</td>
            <td>${payment.student}</td>
            <td>${payment.course}</td>
            <td>₹${payment.amount}</td>
            <td>${payment.method}</td>
            <td>${payment.date}</td>
            <td><span class="status-badge status-${payment.status.toLowerCase()}">${payment.status}</span></td>
            <td>
              <button class="contact-btn" onclick="ZeeTechCRM.payments.editPayment('${payment.id}')">✏</button>
              <button class="contact-btn" onclick="ZeeTechCRM.payments.deletePayment('${payment.id}')">🗑</button>
            </td>
          `;
          tbody.appendChild(row);
        });
      };

      this.filterPayments = () => {
        const searchTerm = document.getElementById('paymentSearch')?.value.toLowerCase() || '';
        const statusFilter = document.getElementById('statusFilter')?.value.toLowerCase() || '';
        const methodFilter = document.getElementById('methodFilter')?.value.toLowerCase() || '';

        const filteredPayments = payments.filter(payment => {
          return (
            (payment.student.toLowerCase().includes(searchTerm) || payment.id.toLowerCase().includes(searchTerm)) &&
            (statusFilter === '' || payment.status.toLowerCase() === statusFilter) &&
            (methodFilter === '' || payment.method.toLowerCase() === methodFilter)
          );
        });

        const tbody = document.getElementById('paymentsTableBody');
        if (!tbody) return;
        tbody.innerHTML = '';
        filteredPayments.forEach(payment => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${payment.id}</td>
            <td>${payment.student}</td>
            <td>${payment.course}</td>
            <td>₹${payment.amount}</td>
            <td>${payment.method}</td>
            <td>${payment.date}</td>
            <td><span class="status-badge status-${payment.status.toLowerCase()}">${payment.status}</span></td>
            <td>
              <button class="contact-btn" onclick="ZeeTechCRM.payments.editPayment('${payment.id}')">✏</button>
              <button class="contact-btn" onclick="ZeeTechCRM.payments.deletePayment('${payment.id}')">🗑</button>
            </td>
          `;
          tbody.appendChild(row);
        });
      };

      this.openPaymentModal = () => {
        const title = document.getElementById('paymentModalTitle');
        if (title) title.textContent = 'Add Payment';
        const paymentId = document.getElementById('paymentId');
        if (paymentId) paymentId.value = '';
        ZeeTechCRM.utils.openModal('paymentModal');
      };

      this.closePaymentModal = () => ZeeTechCRM.utils.closeModal('paymentModal');

      this.editPayment = (id) => {
        const payment = payments.find(p => p.id === id);
        if (payment) {
          const title = document.getElementById('paymentModalTitle');
          if (title) title.textContent = 'Edit Payment';
          document.getElementById('paymentId').value = payment.id;
          document.getElementById('studentSelect').value = payment.student === 'John Doe' ? '1' : '2';
          document.getElementById('paymentAmount').value = payment.amount;
          document.getElementById('paymentMethod').value = payment.method.toLowerCase();
          document.getElementById('paymentDate').value = payment.date;
          document.getElementById('paymentStatus').value = payment.status.toLowerCase();
          ZeeTechCRM.utils.openModal('paymentModal');
        }
      };

      this.deletePayment = (id) => {
        if (confirm('Are you sure you want to delete this payment?')) {
          const index = payments.findIndex(p => p.id === id);
          if (index !== -1) {
            payments.splice(index, 1);
            loadPayments();
            ZeeTechCRM.utils.showNotification('Payment deleted successfully!', 'success');
          }
        }
      };

      const paymentForm = document.getElementById('paymentForm');
      if (paymentForm) {
        paymentForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const formData = new FormData(e.target);
          const data = Object.fromEntries(formData);
          // Replace with API call: ZeeTechCRM.utils.sendAjaxRequest('/api/payments/', data.payment_id ? 'PUT' : 'POST', data);
          if (data.payment_id) {
            const payment = payments.find(p => p.id === data.payment_id);
            if (payment) {
              payment.student = data.student === '1' ? 'John Doe' : 'Jane Smith';
              payment.course = payment.student === 'John Doe' ? 'Full Stack Development' : 'Data Science';
              payment.amount = data.amount;
              payment.method = data.method.charAt(0).toUpperCase() + data.method.slice(1);
              payment.date = data.date;
              payment.status = data.status.charAt(0).toUpperCase() + data.status.slice(1);
            }
            ZeeTechCRM.utils.showNotification('Payment updated successfully!', 'success');
          } else {
            payments.push({
              id: `P00${payments.length + 1}`,
              student: data.student === '1' ? 'John Doe' : 'Jane Smith',
              course: data.student === '1' ? 'Full Stack Development' : 'Data Science',
              amount: data.amount,
              method: data.method.charAt(0).toUpperCase() + data.method.slice(1),
              date: data.date,
              status: data.status.charAt(0).toUpperCase() + data.status.slice(1),
            });
            ZeeTechCRM.utils.showNotification('Payment added successfully!', 'success');
          }
          loadPayments();
          ZeeTechCRM.utils.closeModal('paymentModal');
        });
      }

      loadPayments();
    },
  },

  // Add Placement Data Page (add_placement_data.html)
  addPlacementData: {
    init() {
      if (!document.getElementById('placementUploadForm')) return;

      this.downloadPlacementTemplate = () => {
        ZeeTechCRM.utils.showNotification('Placement template downloaded successfully!', 'success');
      };

      const placementUploadForm = document.getElementById('placementUploadForm');
      if (placementUploadForm) {
        placementUploadForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const formData = new FormData(e.target);
          const progressBar = document.querySelector('#placementUploadProgress .progress-fill');
          const progressText = document.querySelector('#placementUploadProgress .progress-text');
          const uploadProgress = document.getElementById('placementUploadProgress');
          const uploadResult = document.getElementById('placementUploadResult');

          if (!progressBar || !progressText || !uploadProgress || !uploadResult) return;

          uploadProgress.classList.remove('hidden');
          let progress = 0;
          const interval = setInterval(() => {
            progress += 10;
            progressBar.style.width = `${progress}%`;
            progressText.textContent = `Uploading... ${progress}%`;
            if (progress >= 100) {
              clearInterval(interval);
              uploadProgress.classList.add('hidden');
              // Replace with API call: ZeeTechCRM.utils.sendAjaxRequest('/api/placements/upload/', 'POST', formData, null);
              uploadResult.classList.remove('hidden');
              uploadResult.textContent = 'Placement data uploaded successfully!';
              ZeeTechCRM.utils.showNotification('Placement data uploaded successfully!', 'success');
              e.target.reset();
            }
          }, 200);
        });
      }

      const placementManualForm = document.getElementById('placementManualForm');
      if (placementManualForm) {
        placementManualForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const formData = new FormData(e.target);
          // Replace with API call: ZeeTechCRM.utils.sendAjaxRequest('/api/placements/', 'POST', formData);
          ZeeTechCRM.utils.showNotification('Placement added successfully!', 'success');
          e.target.reset();
        });
      }
    },
  },

  // Placements Page (placements.html)
  placements: {
    init() {
      if (!document.getElementById('placementsTable')) return;

      const placements = [
        { id: 'PL001', student: 'John Doe', company: 'TechCorp', position: 'Developer', course: 'Full Stack Development', package: 600000, date: '2025-06-01', status: 'Placed' },
        { id: 'PL002', student: 'Jane Smith', company: 'DataInc', position: 'Analyst', course: 'Data Science', package: 550000, date: '2025-06-02', status: 'Interview' },
      ];

      const loadPlacements = () => {
        const tbody = document.getElementById('placementsTableBody');
        if (!tbody) return;
        tbody.innerHTML = '';
        placements.forEach(placement => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${placement.student}</td>
            <td>${placement.company}</td>
            <td>${placement.position}</td>
            <td>${placement.course}</td>
            <td>₹${(placement.package / 100000).toFixed(1)}L</td>
            <td>${placement.date}</td>
            <td><span class="status-badge status-${placement.status.toLowerCase()}">${placement.status}</span></td>
            <td>
              <button class="contact-btn" onclick="ZeeTechCRM.placements.editPlacement('${placement.id}')">✏</button>
              <button class="contact-btn" onclick="ZeeTechCRM.placements.deletePlacement('${placement.id}')">🗑</button>
            </td>
          `;
          tbody.appendChild(row);
        });
      };

      this.filterPlacements = () => {
        const searchTerm = document.getElementById('placementSearch')?.value.toLowerCase() || '';
        const statusFilter = document.getElementById('statusFilter')?.value.toLowerCase() || '';
        const courseFilter = document.getElementById('courseFilter')?.value.toLowerCase() || '';

        const filteredPlacements = placements.filter(placement => {
          return (
            (placement.student.toLowerCase().includes(searchTerm) || placement.company.toLowerCase().includes(searchTerm)) &&
            (statusFilter === '' || placement.status.toLowerCase() === statusFilter) &&
            (courseFilter === '' || placement.course.toLowerCase().includes(courseFilter))
          );
        });

        const tbody = document.getElementById('placementsTableBody');
        if (!tbody) return;
        tbody.innerHTML = '';
        filteredPlacements.forEach(placement => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${placement.student}</td>
            <td>${placement.company}</td>
            <td>${placement.position}</td>
            <td>${placement.course}</td>
            <td>₹${(placement.package / 100000).toFixed(1)}L</td>
            <td>${placement.date}</td>
            <td><span class="status-badge status-${placement.status.toLowerCase()}">${placement.status}</span></td>
            <td>
              <button class="contact-btn" onclick="ZeeTechCRM.placements.editPlacement('${placement.id}')">✏</button>
              <button class="contact-btn" onclick="ZeeTechCRM.placements.deletePlacement('${placement.id}')">🗑</button>
            </td>
          `;
          tbody.appendChild(row);
        });
      };

      this.openPlacementModal = () => {
        const title = document.getElementById('placementModalTitle');
        if (title) title.textContent = 'Add Placement';
        const placementId = document.getElementById('placementId');
        if (placementId) placementId.value = '';
        ZeeTechCRM.utils.openModal('placementModal');
      };

      this.closePlacementModal = () => ZeeTechCRM.utils.closeModal('placementModal');

      this.editPlacement = (id) => {
        const placement = placements.find(p => p.id === id);
        if (placement) {
          const title = document.getElementById('placementModalTitle');
          if (title) title.textContent = 'Edit Placement';
          document.getElementById('placementId').value = placement.id;
          document.getElementById('studentName').value = placement.student;
          document.getElementById('companyName').value = placement.company;
          document.getElementById('jobPosition').value = placement.position;
          document.getElementById('course').value = placement.course.toLowerCase().replace(' ', '-');
          document.getElementById('salary').value = placement.package;
          document.getElementById('placementDate').value = placement.date;
          document.getElementById('placementStatus').value = placement.status.toLowerCase();
          ZeeTechCRM.utils.openModal('placementModal');
        }
      };

      this.deletePlacement = (id) => {
        if (confirm('Are you sure you want to delete this placement?')) {
          const index = placements.findIndex(p => p.id === id);
          if (index !== -1) {
            placements.splice(index, 1);
            loadPlacements();
            ZeeTechCRM.utils.showNotification('Placement deleted successfully!', 'success');
          }
        }
      };

      this.exportPlacements = () => {
        ZeeTechCRM.utils.showNotification('Placements exported successfully!', 'success');
      };

      this.generateReport = () => {
        ZeeTechCRM.utils.showNotification('Placement report generated successfully!', 'success');
      };

      const placementForm = document.getElementById('placementForm');
      if (placementForm) {
        placementForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const formData = new FormData(e.target);
          const data = Object.fromEntries(formData);
          // Replace with API call: ZeeTechCRM.utils.sendAjaxRequest('/api/placements/', data.placement_id ? 'PUT' : 'POST', data);
          if (data.placement_id) {
            const placement = placements.find(p => p.id === data.placement_id);
            if (placement) {
              placement.student = data.student_name;
              placement.company = data.company_name;
              placement.position = data.job_position;
              placement.course = data.course.replace('-', ' ').replace(/\b\w/g, c => c.toUpperCase());
              placement.package = parseInt(data.salary);
              placement.date = data.placement_date || 'N/A';
              placement.status = data.status.charAt(0).toUpperCase() + data.status.slice(1);
            }
            ZeeTechCRM.utils.showNotification('Placement updated successfully!', 'success');
          } else {
            placements.push({
              id: `PL00${placements.length + 1}`,
              student: data.student_name,
              company: data.company_name,
              position: data.job_position,
              course: data.course.replace('-', ' ').replace(/\b\w/g, c => c.toUpperCase()),
              package: parseInt(data.salary),
              date: data.placement_date || 'N/A',
              status: data.status.charAt(0).toUpperCase() + data.status.slice(1),
            });
            ZeeTechCRM.utils.showNotification('Placement added successfully!', 'success');
          }
          loadPlacements();
          ZeeTechCRM.utils.closeModal('placementModal');
        });
      }

      loadPlacements();
    },
  },

  // Settings Page (settings.html)
  settings: {
    init() {
      if (!document.getElementById('profileForm')) return;

      const profileForm = document.getElementById('profileForm');
      if (profileForm) {
        profileForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const formData = new FormData(e.target);
          // Replace with API call: ZeeTechCRM.utils.sendAjaxRequest('/api/profile/', 'PUT', formData);
          ZeeTechCRM.utils.showNotification('Profile updated successfully!', 'success');
        });
      }

      const passwordForm = document.getElementById('passwordForm');
      if (passwordForm) {
        passwordForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const formData = new FormData(e.target);
          const data = Object.fromEntries(formData);
          if (data.new_password !== data.confirm_password) {
            ZeeTechCRM.utils.showNotification('New passwords do not match!', 'error');
            return;
          }
          // Replace with API call: ZeeTechCRM.utils.sendAjaxRequest('/api/password/', 'PUT', data);
          ZeeTechCRM.utils.showNotification('Password changed successfully!', 'success');
          e.target.reset();
        });
      }

      const systemForm = document.getElementById('systemForm');
      if (systemForm) {
        systemForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const formData = new FormData(e.target);
          // Replace with API call: ZeeTechCRM.utils.sendAjaxRequest('/api/system/', 'PUT', formData);
          ZeeTechCRM.utils.showNotification('System settings updated successfully!', 'success');
        });
      }

      const academyForm = document.getElementById('academyForm');
      if (academyForm) {
        academyForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const formData = new FormData(e.target);
          // Replace with API call: ZeeTechCRM.utils.sendAjaxRequest('/api/academy/', 'PUT', formData);
          ZeeTechCRM.utils.showNotification('Academy information updated successfully!', 'success');
        });
      }

      this.exportData = (type) => {
        ZeeTechCRM.utils.showNotification(`${type.charAt(0).toUpperCase() + type.slice(1)} data exported successfully!`, 'success');
      };

      this.createBackup = () => {
        ZeeTechCRM.utils.showNotification('Backup created successfully!', 'success');
      };
    },
  },

  // Add Student Page (add_students.html)
//   addStudents: {
//     init() {
//       const form = document.querySelector('form[action="{% url \'add_student\' %}"]');
//       if (form) {
//         form.addEventListener('submit', async (e) => {
//           // Let the form submit naturally to Django
//           ZeeTechCRM.utils.showNotification('Student added successfully!', 'success');
//         });
//       }
//     },
//   },

  // Students Page (students.html)
  students: {
    init() {
      if (!document.getElementById('studentsTable')) return;

      const students = [
        { id: 1, name: 'John Doe', email: 'john@example.com', phone: '9876543210', course: 'Full Stack Development', batch: 'Batch 2024-A', status: 'Active' },
        { id: 2, name: 'Jane Smith', email: 'jane@example.com', phone: '9876543211', course: 'Data Science', batch: 'Batch 2024-B', status: 'Completed' },
      ];

      const loadStudents = () => {
        const tbody = document.getElementById('studentsTableBody');
        if (!tbody) return;
        tbody.innerHTML = '';
        students.forEach(student => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>STU${String(student.id).padStart(3, '0')}</td>
            <td>${student.name}</td>
            <td>${student.email}</td>
            <td>${student.phone}</td>
            <td>${student.course}</td>
            <td>${student.batch}</td>
            <td><span class="status-badge status-${student.status.toLowerCase()}">${student.status}</span></td>
            <td>
              <div class="contact-actions">
                <button class="contact-btn" onclick="ZeeTechCRM.students.openWhatsApp('${student.phone}', '${student.name}')">💬</button>
                <button class="contact-btn" onclick="ZeeTechCRM.students.makeCall('${student.phone}')">📞</button>
                <button class="contact-btn" onclick="ZeeTechCRM.students.sendEmail('${student.email}', '${student.name}')">📧</button>
                <button class="contact-btn" onclick="ZeeTechCRM.students.editStudent(${student.id})">✏</button>
                <button class="contact-btn" onclick="ZeeTechCRM.students.deleteStudent(${student.id})">🗑</button>
                <button class="contact-btn" onclick="ZeeTechCRM.students.viewStudentDetails(${student.id})">👁</button>
              </div>
            </td>
          `;
          tbody.appendChild(row);
        });
      };

      this.filterStudents = () => {
        const searchTerm = document.getElementById('studentSearch')?.value.toLowerCase() || '';
        const courseFilter = document.getElementById('courseFilter')?.value.toLowerCase() || '';
        const statusFilter = document.getElementById('statusFilter')?.value.toLowerCase() || '';

        const filteredStudents = students.filter(student => {
          return (
            (student.name.toLowerCase().includes(searchTerm) || student.email.toLowerCase().includes(searchTerm)) &&
            (courseFilter === '' || student.course.toLowerCase().includes(courseFilter)) &&
            (statusFilter === '' || student.status.toLowerCase() === statusFilter)
          );
        });

        const tbody = document.getElementById('studentsTableBody');
        if (!tbody) return;
        tbody.innerHTML = '';
        filteredStudents.forEach(student => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>STU${String(student.id).padStart(3, '0')}</td>
            <td>${student.name}</td>
            <td>${student.email}</td>
            <td>${student.phone}</td>
            <td>${student.course}</td>
            <td>${student.batch}</td>
            <td><span class="status-badge status-${student.status.toLowerCase()}">${student.status}</span></td>
            <td>
              <div class="contact-actions">
                <button class="contact-btn" onclick="ZeeTechCRM.students.openWhatsApp('${student.phone}', '${student.name}')">💬</button>
                <button class="contact-btn" onclick="ZeeTechCRM.students.makeCall('${student.phone}')">📞</button>
                <button class="contact-btn" onclick="ZeeTechCRM.students.sendEmail('${student.email}', '${student.name}')">📧</button>
                <button class="contact-btn" onclick="ZeeTechCRM.students.editStudent(${student.id})">✏</button>
                <button class="contact-btn" onclick="ZeeTechCRM.students.deleteStudent(${student.id})">🗑</button>
                <button class="contact-btn" onclick="ZeeTechCRM.students.viewStudentDetails(${student.id})">👁</button>
              </div>
            </td>
          `;
          tbody.appendChild(row);
        });
      };

      this.openStudentModal = () => {
        const title = document.getElementById('studentModalTitle');
        if (title) title.textContent = 'Add Student';
        const studentId = document.getElementById('studentId');
        if (studentId) studentId.value = '';
        ZeeTechCRM.utils.openModal('studentModal');
      };

      this.closeStudentModal = () => ZeeTechCRM.utils.closeModal('studentModal');

      this.editStudent = (id) => {
        const student = students.find(s => s.id === id);
        if (student) {
          const title = document.getElementById('studentModalTitle');
          if (title) title.textContent = 'Edit Student';
          document.getElementById('studentId').value = student.id;
          document.getElementById('studentName').value = student.name;
          document.getElementById('studentEmail').value = student.email;
          document.getElementById('studentPhone').value = student.phone;
          document.getElementById('studentCourse').value = student.course.toLowerCase().replace(' ', '-');
          document.getElementById('studentBatch').value = student.batch.toLowerCase().replace(' ', '-');
          document.getElementById('studentStatus').value = student.status.toLowerCase();
          ZeeTechCRM.utils.openModal('studentModal');
        }
      };

      this.deleteStudent = (id) => {
        if (confirm('Are you sure you want to delete this student?')) {
          const index = students.findIndex(s => s.id === id);
          if (index !== -1) {
            students.splice(index, 1);
            loadStudents();
            ZeeTechCRM.utils.showNotification('Student deleted successfully!', 'success');
          }
        }
      };

      this.openWhatsApp = (phone, name) => {
        window.open(`https://wa.me/${phone}?text=Hello%20${name},%20this%20is%20Zee-Tech%20Academy.`, '_blank');
      };

      this.makeCall = (phone) => {
        window.location.href = `tel:${phone}`;
      };

      this.sendEmail = (email, name) => {
        window.location.href = `mailto:${email}?subject=Message%20from%20Zee-Tech%20Academy&body=Hello%20${name},`;
      };

      this.viewStudentDetails = (id) => {
        const student = students.find(s => s.id === id);
        if (student) {
          alert(`Student Details:\nName: ${student.name}\nEmail: ${student.email}\nPhone: ${student.phone}\nCourse: ${student.course}\nBatch: ${student.batch}\nStatus: ${student.status}`);
        }
      };

      const studentForm = document.getElementById('studentForm');
      if (studentForm) {
        studentForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const formData = new FormData(e.target);
          const data = Object.fromEntries(formData);
          // Replace with API call: ZeeTechCRM.utils.sendAjaxRequest('/api/students/', data.student_id ? 'PUT' : 'POST', data);
          if (data.student_id) {
            const student = students.find(s => s.id === parseInt(data.student_id));
            if (student) {
              student.name = data.name;
              student.email = data.email;
              student.phone = data.phone;
              student.course = data.course.replace('-', ' ').replace(/\b\w/g, c => c.toUpperCase());
              student.batch = data.batch ? data.batch.replace('-', ' ').replace(/\b\w/g, c => c.toUpperCase()) : 'N/A';
              student.status = data.status.charAt(0).toUpperCase() + data.status.slice(1);
            }
            ZeeTechCRM.utils.showNotification('Student updated successfully!', 'success');
          } else {
            students.push({
              id: students.length + 1,
              name: data.name,
              email: data.email,
              phone: data.phone,
              course: data.course.replace('-', ' ').replace(/\b\w/g, c => c.toUpperCase()),
              batch: data.batch ? data.batch.replace('-', ' ').replace(/\b\w/g, c => c.toUpperCase()) : 'N/A',
              status: data.status.charAt(0).toUpperCase() + data.status.slice(1),
            });
            ZeeTechCRM.utils.showNotification('Student added successfully!', 'success');
          }
          loadStudents();
          ZeeTechCRM.utils.closeModal('studentModal');
        });
      }

      loadStudents();
    },
  },

  // Study Material Page (study_material.html)
  studyMaterial: {
    init() {
      if (!document.getElementById('materialsGrid')) return;

      const materials = [
        { id: 'M001', title: 'JavaScript Basics', course: 'Full Stack Development', type: 'pdf', description: 'Introduction to JavaScript.' },
        { id: 'M002', title: 'Python for Data Science', course: 'Data Science', type: 'video', description: 'Python programming for data analysis.' },
      ];

      const loadMaterials = () => {
        const grid = document.getElementById('materialsGrid');
        if (!grid) return;
        grid.innerHTML = '';
        materials.forEach(material => {
          const card = document.createElement('div');
          card.className = 'material-card';
          card.innerHTML = `
            <div class="material-header">
              <span class="material-type type-${material.type}">${material.type.toUpperCase()}</span>
            </div>
            <div class="material-title">${material.title}</div>
            <div class="material-course">${material.course}</div>
            <div class="material-description">${material.description}</div>
            <div class="material-actions">
              <button class="btn btn-primary" onclick="ZeeTechCRM.studyMaterial.downloadMaterial('${material.id}')">Download</button>
              <button class="btn btn-danger" onclick="ZeeTechCRM.studyMaterial.deleteMaterial('${material.id}')">Delete</button>
            </div>
          `;
          grid.appendChild(card);
        });
      };

      this.filterMaterials = () => {
        const searchTerm = document.getElementById('materialSearch')?.value.toLowerCase() || '';
        const courseFilter = document.getElementById('courseFilter')?.value.toLowerCase() || '';
        const typeFilter = document.getElementById('typeFilter')?.value.toLowerCase() || '';

        const filteredMaterials = materials.filter(material => {
          return (
            (material.title.toLowerCase().includes(searchTerm) || material.description.toLowerCase().includes(searchTerm)) &&
            (courseFilter === '' || material.course.toLowerCase().includes(courseFilter)) &&
            (typeFilter === '' || material.type.toLowerCase() === typeFilter)
          );
        });

        const grid = document.getElementById('materialsGrid');
        if (!grid) return;
        grid.innerHTML = '';
        filteredMaterials.forEach(material => {
          const card = document.createElement('div');
          card.className = 'material-card';
          card.innerHTML = `
            <div class="material-header">
              <span class="material-type type-${material.type}">${material.type.toUpperCase()}</span>
            </div>
            <div class="material-title">${material.title}</div>
            <div class="material-course">${material.course}</div>
            <div class="material-description">${material.description}</div>
            <div class="material-actions">
              <button class="btn btn-primary" onclick="ZeeTechCRM.studyMaterial.downloadMaterial('${material.id}')">Download</button>
              <button class="btn btn-danger" onclick="ZeeTechCRM.studyMaterial.deleteMaterial('${material.id}')">Delete</button>
            </div>
          `;
          grid.appendChild(card);
        });
      };

      this.openMaterialModal = () => ZeeTechCRM.utils.openModal('materialModal');

      this.closeMaterialModal = () => ZeeTechCRM.utils.closeModal('materialModal');

      this.downloadMaterial = (id) => {
        ZeeTechCRM.utils.showNotification('Material downloaded successfully!', 'success');
      };

      this.deleteMaterial = (id) => {
        if (confirm('Are you sure you want to delete this material?')) {
          const index = materials.findIndex(m => m.id === id);
          if (index !== -1) {
            materials.splice(index, 1);
            loadMaterials();
            ZeeTechCRM.utils.showNotification('Material deleted successfully!', 'success');
          }
        }
      };

      const materialForm = document.getElementById('materialForm');
      if (materialForm) {
        materialForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const formData = new FormData(e.target);
          const data = Object.fromEntries(formData);
          // Replace with API call: ZeeTechCRM.utils.sendAjaxRequest('/api/materials/', 'POST', data);
          materials.push({
            id: `M00${materials.length + 1}`,
            title: data.title,
            course: data.course.replace('-', ' ').replace(/\b\w/g, c => c.toUpperCase()),
            type: data.type,
            description: data.description || 'No description provided.',
          });
          loadMaterials();
          ZeeTechCRM.utils.showNotification('Material added successfully!', 'success');
          ZeeTechCRM.utils.closeModal('materialModal');
        });
      }

      loadMaterials();
    },
  },

  // Initialize all modules
  init() {
    this.batches.init();
    this.courses.init();
    this.addMarketingData.init();
    this.marketingSales.init();
    this.notifications.init();
    this.payments.init();
    this.addPlacementData.init();
    this.placements.init();
    this.settings.init();
    this.addStudents.init();
    this.students.init();
    this.studyMaterial.init();
  },
};

document.addEventListener('DOMContentLoaded', () => {
  ZeeTechCRM.init();
});
