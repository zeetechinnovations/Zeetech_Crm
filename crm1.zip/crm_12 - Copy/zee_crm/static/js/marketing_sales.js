// marketing_sales.js

// Fetch CSRF token from cookies
function getCSRFToken() {
    const name = 'csrftoken';
    const cookies = document.cookie.split(';');
    for (let cookie of cookies) {
        cookie = cookie.trim();
        if (cookie.startsWith(name + '=')) {
            return cookie.substring(name.length + 1);
        }
    }
    return null;
}

// Open Lead Modal
function openLeadModal() {
    document.getElementById('leadModal').style.display = 'block';
    document.getElementById('modal-overlay').style.display = 'block';
    document.getElementById('leadModalTitle').textContent = 'Add Lead';
    document.getElementById('leadForm').reset();
    document.getElementById('leadId').value = '';
}

// Close Lead Modal
function closeLeadModal() {
    document.getElementById('leadModal').style.display = 'none';
    document.getElementById('modal-overlay').style.display = 'none';
}

// Open Upload Modal
function openUploadModal() {
    document.getElementById('uploadModal').style.display = 'block';
    document.getElementById('modal-overlay').style.display = 'block';
    document.getElementById('uploadForm').reset();
    document.getElementById('uploadProgress').classList.add('hidden');
    document.getElementById('uploadResult').classList.add('hidden');
}

// Close Upload Modal
function closeUploadModal() {
    document.getElementById('uploadModal').style.display = 'none';
    document.getElementById('modal-overlay').style.display = 'none';
}

// Open Bulk Email Modal
function openBulkEmailModal() {
    fetch('/marketing/get-leads/')
        .then(response => response.json())
        .then(data => {
            if (data.leads.length === 0) {
                alert('No leads available to send bulk emails.');
                return;
            }
            document.getElementById('bulkEmailModal').style.display = 'block';
            document.getElementById('modal-overlay').style.display = 'block';
            document.getElementById('bulkEmailMessage').textContent = `Are you sure you want to send a bulk email to ${data.leads.length} leads?`;
        })
        .catch(error => {
            console.error('Error fetching leads:', error);
            alert('Failed to fetch leads.');
        });
}

// Close Bulk Email Modal
function closeBulkEmailModal() {
    document.getElementById('bulkEmailModal').style.display = 'none';
    document.getElementById('modal-overlay').style.display = 'none';
    document.getElementById('bulkEmailMessage').classList.remove('error-message', 'success-message');
}

// Save Lead
function saveLead(event) {
    event.preventDefault();
    const form = document.getElementById('leadForm');
    const formData = new FormData(form);
    const leadData = {
        name: formData.get('name'),
        email: formData.get('email'),
        phone: formData.get('phone'),
        course: formData.get('course') || 'N/A',
        status: formData.get('status'),
        source: formData.get('source') || 'N/A',
        notes: formData.get('notes') || ''
    };

    fetch('/marketing/add-lead/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCSRFToken()
        },
        body: JSON.stringify(leadData)
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateLeadsTable();
                updateMetrics();
                closeLeadModal();
            } else {
                alert('Error: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error saving lead:', error);
            alert('Failed to save lead.');
        });
}

// Upload Data (Simulate Upload with Progress)
function uploadData(event) {
    event.preventDefault();
    const form = document.getElementById('uploadForm');
    const formData = new FormData(form);
    const progressBar = document.querySelector('.progress-fill');
    const progressText = document.querySelector('.progress-text');
    const uploadProgress = document.getElementById('uploadProgress');
    const uploadResult = document.getElementById('uploadResult');

    uploadProgress.classList.remove('hidden');
    let progress = 0;

    const interval = setInterval(() => {
        progress += 10;
        progressBar.style.width = `${progress}%`;
        progressText.textContent = `Uploading... ${progress}%`;

        if (progress >= 100) {
            clearInterval(interval);
            // Simulate backend upload (replace with actual API call if implemented)
            uploadProgress.classList.add('hidden');
            uploadResult.classList.remove('hidden');
            uploadResult.textContent = 'Upload Completed Successfully!';
            setTimeout(closeUploadModal, 1000);
            updateLeadsTable();
            updateMetrics();
        }
    }, 300);
}

// Export Leads
function exportLeads() {
    window.location.href = '/marketing/export-leads/';
    setTimeout(() => {
        updateExportHistory();
    }, 1000);
}

// Send Bulk Email
function sendBulkEmail() {
    const messageElement = document.getElementById('bulkEmailMessage');
    messageElement.textContent = 'Sending bulk email...';
    messageElement.classList.remove('error-message', 'success-message');

    fetch('/marketing/send-bulk-email/', {
        method: 'POST',
        headers: {
            'X-CSRFToken': getCSRFToken()
        }
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                messageElement.textContent = 'Bulk email sent successfully!';
                messageElement.classList.add('success-message');
            } else {
                messageElement.textContent = 'Failed to send bulk email: ' + data.error;
                messageElement.classList.add('error-message');
            }
            updateEmailHistory();
            setTimeout(closeBulkEmailModal, 1500);
        })
        .catch(error => {
            messageElement.textContent = 'Failed to send bulk email.';
            messageElement.classList.add('error-message');
            updateEmailHistory();
            setTimeout(closeBulkEmailModal, 1500);
            console.error('Error sending bulk email:', error);
        });
}

// Download Template
function downloadTemplate() {
    const templateContent = 'Lead ID,Name,Email,Phone,Course Interest,Status,Source,Notes\n';
    const blob = new Blob([templateContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'lead_template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Filter Leads
function filterLeads() {
    const search = document.getElementById('leadSearch').value.toLowerCase();
    const status = document.getElementById('statusFilter').value;
    const source = document.getElementById('sourceFilter').value;

    fetch('/marketing/get-leads/')
        .then(response => response.json())
        .then(data => {
            const filteredLeads = data.leads.filter(lead => {
                const matchesSearch = lead.name.toLowerCase().includes(search) || lead.email.toLowerCase().includes(search);
                const matchesStatus = status === '' || lead.status === status;
                const matchesSource = source === '' || lead.source === source;
                return matchesSearch && matchesStatus && matchesSource;
            });
            updateLeadsTable(filteredLeads);
        })
        .catch(error => {
            console.error('Error filtering leads:', error);
            alert('Failed to filter leads.');
        });
}

// Update Leads Table
function updateLeadsTable(filteredLeads = null) {
    const tbody = document.getElementById('leadsTableBody');
    tbody.innerHTML = '';

    if (filteredLeads) {
        filteredLeads.forEach(lead => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${lead.id}</td>
                <td>${lead.name}</td>
                <td>${lead.email}</td>
                <td>${lead.phone}</td>
                <td>${lead.course}</td>
                <td>${lead.status}</td>
                <td>${lead.source}</td>
                <td><button onclick="editLead(${lead.id})">Edit</button></td>
            `;
            tbody.appendChild(row);
        });
    } else {
        fetch('/marketing/get-leads/')
            .then(response => response.json())
            .then(data => {
                data.leads.forEach(lead => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${lead.id}</td>
                        <td>${lead.name}</td>
                        <td>${lead.email}</td>
                        <td>${lead.phone}</td>
                        <td>${lead.course}</td>
                        <td>${lead.status}</td>
                        <td>${lead.source}</td>
                        <td><button onclick="editLead(${lead.id})">Edit</button></td>
                    `;
                    tbody.appendChild(row);
                });
            })
            .catch(error => {
                console.error('Error updating leads table:', error);
                alert('Failed to load leads.');
            });
    }
}

// Edit Lead
function editLead(leadId) {
    fetch('/marketing/get-leads/')
        .then(response => response.json())
        .then(data => {
            const lead = data.leads.find(l => l.id === leadId);
            if (lead) {
                openLeadModal();
                document.getElementById('leadModalTitle').textContent = 'Edit Lead';
                document.getElementById('leadId').value = lead.id;
                document.getElementById('leadName').value = lead.name;
                document.getElementById('leadEmail').value = lead.email;
                document.getElementById('leadPhone').value = lead.phone;
                document.getElementById('leadCourse').value = lead.course === 'N/A' ? '' : lead.course;
                document.getElementById('leadStatus').value = lead.status;
                document.getElementById('leadSource').value = lead.source === 'N/A' ? '' : lead.source;
                document.getElementById('leadNotes').value = lead.notes;
            }
        })
        .catch(error => {
            console.error('Error fetching lead for edit:', error);
            alert('Failed to load lead for editing.');
        });
}

// Update Metrics
function updateMetrics() {
    fetch('/marketing/get-leads/')
        .then(response => response.json())
        .then(data => {
            const totalLeads = data.leads.length;
            const hotLeads = data.leads.filter(lead => lead.status === 'hot').length;
            const convertedLeads = data.leads.filter(lead => lead.status === 'converted').length;
            const conversionRate = totalLeads > 0 ? ((convertedLeads / totalLeads) * 100).toFixed(1) : 0;

            document.querySelector('.metric-card.blue .metric-value').textContent = totalLeads;
            document.querySelector('.metric-card.green .metric-value').textContent = hotLeads;
            document.querySelector('.metric-card.orange .metric-value').textContent = convertedLeads;
            document.querySelector('.metric-card.purple .metric-value').textContent = `${conversionRate}%`;
        })
        .catch(error => {
            console.error('Error updating metrics:', error);
            alert('Failed to update metrics.');
        });
}

// Update Export History
function updateExportHistory() {
    fetch('/marketing/get-action-history/')
        .then(response => response.json())
        .then(data => {
            const exportList = document.getElementById('exportHistory');
            exportList.innerHTML = '';
            data.history
                .filter(item => item.action_type === 'export')
                .forEach(item => {
                    const div = document.createElement('div');
                    div.className = 'history-item';
                    div.innerHTML = `
                        Exported ${item.count} leads - ${item.status}
                        <span>${item.timestamp}</span>
                    `;
                    exportList.appendChild(div);
                });
        })
        .catch(error => {
            console.error('Error updating export history:', error);
        });
}

// Update Email History
function updateEmailHistory() {
    fetch('/marketing/get-action-history/')
        .then(response => response.json())
        .then(data => {
            const emailList = document.getElementById('emailHistory');
            emailList.innerHTML = '';
            data.history
                .filter(item => item.action_type === 'email')
                .forEach(item => {
                    const div = document.createElement('div');
                    div.className = 'history-item';
                    div.innerHTML = `
                        Sent to ${item.count} leads - ${item.status}
                        <span>${item.timestamp}</span>
                    `;
                    emailList.appendChild(div);
                });
        })
        .catch(error => {
            console.error('Error updating email history:', error);
        });
}

// Initialize page
document.addEventListener('DOMContentLoaded', () => {
    updateLeadsTable();
    updateMetrics();
    updateExportHistory();
    updateEmailHistory();
});