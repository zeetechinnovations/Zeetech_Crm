let batches = [];
let editingBatchId = null;

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let cookie of cookies) {
            cookie = cookie.trim();
            if (cookie.startsWith(name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    console.log(`CSRF Token (${name}):`, cookieValue);
    return cookieValue;
}

document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM fully loaded at:', new Date().toISOString());

    const batchForm = document.getElementById('batchForm');
    if (batchForm) {
        console.log('batchForm found, attaching submit event listener');
        batchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            console.log('Save Batch button clicked at:', new Date().toISOString());
            saveBatch();
        });
    } else {
        console.error('batchForm not found');
    }

    // Load initial batches from template data
    batches = batchesData || [];
    console.log('Initial batches loaded:', batches);
    loadBatches();

    // Attach filter event listeners
    const batchSearch = document.getElementById('batchSearch');
    const courseFilter = document.getElementById('courseFilter');
    const batchStatusFilter = document.getElementById('batchStatusFilter');
    if (batchSearch && courseFilter && batchStatusFilter) {
        console.log('Filter elements found, attaching event listeners');
        batchSearch.addEventListener('keyup', filterBatches);
        courseFilter.addEventListener('change', filterBatches);
        batchStatusFilter.addEventListener('change', filterBatches);
    } else {
        console.error('Filter elements not found:', { batchSearch, courseFilter, batchStatusFilter });
    }
});

function refreshBatches() {
    console.log('Fetching batches from server...');
    fetch('/batches/get_batches/', {
        method: 'GET',
        headers: {
            'X-CSRFToken': getCookie('csrftoken'),
        },
    })
    .then(response => {
        console.log('Fetch batches response status:', response.status);
        if (!response.ok) {
            return response.text().then(text => {
                throw new Error(`HTTP error ${response.status}: ${text}`);
            });
        }
        return response.json();
    })
    .then(data => {
        batches = data.batches || [];
        console.log('Batches loaded from server:', batches);
        loadBatches();
    })
    .catch(error => {
        console.error('Error fetching batches:', error);
        showNotification('error', 'Failed to load batches: ' + error.message);
    });
}

function loadBatches(filteredBatches = batches) {
    const tbody = document.getElementById('batchesTableBody');
    if (!tbody) {
        console.error('batchesTableBody not found');
        return;
    }
    tbody.innerHTML = '';
    console.log('Rendering batches:', filteredBatches);

    filteredBatches.forEach(batch => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>BATCH${String(batch.id).padStart(3, '0')}</td>
            <td>${batch.name}</td>
            <td>${batch.course}</td>
            <td>${formatDate(batch.start_date)}</td>
            <td>${formatDate(batch.end_date)}</td>
            <td>${batch.students}/${batch.max_capacity}</td>
            <td><span class="status-badge status-${batch.status}">${batch.status}</span></td>
            ${document.querySelector('meta[name="user-role"]').content === 'admin' ? `
                <td>
                    <div class="contact-actions">
                        <button class="contact-btn" onclick="editBatch(${batch.id})" title="Edit">✏️</button>
                        <button class="contact-btn" onclick="deleteBatch(${batch.id})" title="Delete">🗑️</button>
                        <button class="contact-btn" onclick="viewBatchStudents(${batch.id})" title="View Students">👥</button>
                    </div>
                </td>
            ` : ''}
        `;
        tbody.appendChild(row);
    });
}

function filterBatches() {
    const searchTerm = document.getElementById('batchSearch').value.toLowerCase();
    const courseFilter = document.getElementById('courseFilter').value;
    const statusFilter = document.getElementById('batchStatusFilter').value;

    console.log('Filtering batches with:', { searchTerm, courseFilter, statusFilter });

    const filteredBatches = batches.filter(batch => {
        const matchesSearch = batch.name.toLowerCase().includes(searchTerm);
        const matchesCourse = !courseFilter || batch.course_id === parseInt(courseFilter);
        const matchesStatus = !statusFilter || batch.status === statusFilter;

        return matchesSearch && matchesCourse && matchesStatus;
    });

    loadBatches(filteredBatches);
}

function openBatchModal() {
    editingBatchId = null;
    document.getElementById('batchModalTitle').textContent = 'Create Batch';
    document.getElementById('batchForm').reset();
    document.getElementById('batchModal').style.display = 'block';
    document.getElementById('modal-overlay').style.display = 'block';
    console.log('Batch modal opened');
}

function closeBatchModal() {
    document.getElementById('batchModal').style.display = 'none';
    document.getElementById('modal-overlay').style.display = 'none';
    console.log('Batch modal closed');
}

function editBatch(batchId) {
    const batch = batches.find(b => b.id === batchId);
    if (batch) {
        editingBatchId = batchId;
        document.getElementById('batchModalTitle').textContent = 'Edit Batch';

        document.getElementById('batchId').value = batch.id;
        document.getElementById('batchName').value = batch.name;
        document.getElementById('batchCourse').value = batch.course_id;
        document.getElementById('startDate').value = batch.start_date;
        document.getElementById('endDate').value = batch.end_date;
        document.getElementById('maxCapacity').value = batch.max_capacity;
        document.getElementById('batchStatus').value = batch.status;
        document.getElementById('batchDescription').value = batch.description || '';

        document.getElementById('batchModal').style.display = 'block';
        document.getElementById('modal-overlay').style.display = 'block';
        console.log('Editing batch:', batchId);
    }
}

function saveBatch() {
    const batchForm = document.getElementById('batchForm');
    if (!batchForm) {
        console.error('batchForm not found in saveBatch');
        return;
    }

    const formData = new FormData(batchForm);
    console.log('Form data:', Object.fromEntries(formData));

    fetch('/batches/add/', {
        method: 'POST',
        headers: {
            'X-CSRFToken': getCookie('csrftoken'),
        },
        body: formData,
    })
    .then(response => {
        console.log('Save batch response status:', response.status);
        if (!response.ok) {
            return response.text().then(text => {
                throw new Error(`HTTP error ${response.status}: ${text}`);
            });
        }
        return response.json();
    })
    .then(data => {
        console.log('Response data:', data);
        if (data.error) {
            showNotification('error', data.error);
            return;
        }
        // Clear filters to ensure new batch is visible
        document.getElementById('batchSearch').value = '';
        document.getElementById('courseFilter').value = '';
        document.getElementById('batchStatusFilter').value = '';
        showNotification('success', editingBatchId ? 'Batch updated successfully!' : 'Batch created successfully!');
        refreshBatches(); // Fetch latest batches from server
        closeBatchModal();
    })
    .catch(error => {
        console.error('Fetch error in saveBatch:', error);
        showNotification('error', 'Failed to save batch: ' + error.message);
    });
}

function deleteBatch(batchId) {
    if (confirm('Are you sure you want to delete this batch?')) {
        fetch(`/batches/delete/${batchId}/`, {
            method: 'POST',
            headers: {
                'X-CSRFToken': getCookie('csrftoken'),
            },
        })
        .then(response => {
            console.log('Delete batch response status:', response.status);
            if (!response.ok) {
                return response.text().then(text => {
                    throw new Error(`HTTP error ${response.status}: ${text}`);
                });
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                showNotification('error', data.error);
                return;
            }
            showNotification('success', 'Batch deleted successfully!');
            refreshBatches(); // Fetch latest batches
        })
        .catch(error => {
            console.error('Delete error:', error);
            showNotification('error', 'Failed to delete batch: ' + error.message);
        });
    }
}

function viewBatchStudents(batchId) {
    const batch = batches.find(b => b.id === batchId);
    if (batch) {
        alert(`Students in ${batch.name}:\n\nTotal Students: ${batch.students}\nMax Capacity: ${batch.max_capacity}\n\nThis would open a detailed student list in a real application.`);
    }
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB');
}

function showNotification(type, message) {
    console.log('Showing notification:', { type, message });
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <span class="icon">${type === 'success' ? '✅' : '❌'}</span>
        <span>${message}</span>
    `;
    document.body.appendChild(notification);
    setTimeout(() => notification.classList.add('show'), 100);
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => document.body.removeChild(notification), 300);
    }, 3000);
}

