// Global Variables
let currentModal = null;

// Sample Data
let students = [
    {
        id: 1,
        name: 'John Doe',
        email: 'john@example.com',
        phone: '9876543210',
        course: 'full-stack',
        batch: 'batch-1',
        status: 'active',
        admissionDate: '2024-01-15'
    },
    {
        id: 2,
        name: 'Jane Smith',
        email: 'jane@example.com',
        phone: '9876543211',
        course: 'data-science',
        batch: 'batch-2',
        status: 'active',
        admissionDate: '2024-02-01'
    }
];

let courses = [
    {
        id: 1,
        code: 'FS001',
        name: 'Full Stack Development',
        duration: 6,
        fee: 60000,
        enrolled: 45,
        maxStudents: 50,
        status: 'active'
    },
    {
        id: 2,
        code: 'DS001',
        name: 'Data Science',
        duration: 8,
        fee: 75000,
        enrolled: 32,
        maxStudents: 40,
        status: 'active'
    }
];

let batches = [
    {
        id: 1,
        name: 'FS Batch 2024-A',
        course: 'full-stack',
        startDate: '2024-06-01',
        endDate: '2024-11-30',
        students: 25,
        maxCapacity: 30,
        status: 'ongoing'
    },
    {
        id: 2,
        name: 'DS Batch 2024-B',
        course: 'data-science',
        startDate: '2024-07-01',
        endDate: '2025-02-28',
        students: 20,
        maxCapacity: 25,
        status: 'upcoming'
    }
];

let leads = [
    {
        id: 1,
        name: 'John Doe',
        email: 'john@example.com',
        phone: '9876543210',
        course: 'full-stack',
        status: 'hot',
        source: 'website'
    },
    {
        id: 2,
        name: 'Jane Smith',
        email: 'jane@example.com',
        phone: '9876543211',
        course: 'data-science',
        status: 'enquiry',
        source: 'social-media'
    }
];

let payments = [
    {
        id: 1,
        studentName: 'John Doe',
        studentId: 'STU001',
        amount: 25000,
        method: 'online',
        date: '2024-05-15',
        status: 'paid',
        transactionId: 'TXN123456'
    },
    {
        id: 2,
        studentName: 'Jane Smith',
        studentId: 'STU002',
        amount: 30000,
        method: 'cash',
        date: '2024-05-20',
        status: 'pending'
    }
];

let placements = [
    {
        id: 1,
        studentName: 'John Doe',
        studentId: 'STU001',
        company: 'Tech Corp',
        position: 'Software Developer',
        salary: 600000,
        status: 'placed',
        course: 'Full Stack Development',
        placementDate: '2024-05-15'
    },
    {
        id: 2,
        studentName: 'Jane Smith',
        studentId: 'STU002',
        company: 'Data Inc',
        position: 'Data Analyst',
        salary: 550000,
        status: 'placed',
        course: 'Data Science',
        placementDate: '2024-05-20'
    }
];

let notifications = [
    {
        id: 1,
        type: 'payment',
        title: 'Payment Reminder',
        message: 'Your course fee payment is due in 3 days.',
        recipients: 'individual',
        status: 'unread',
        timestamp: '2024-05-28 10:30:00'
    },
    {
        id: 2,
        type: 'course',
        title: 'New Course Available',
        message: 'Mobile Development course is now available for enrollment.',
        recipients: 'all',
        status: 'read',
        timestamp: '2024-05-27 14:15:00'
    }
];

let studyMaterials = [
    {
        id: 1,
        title: 'JavaScript Fundamentals',
        course: 'Full Stack Development',
        type: 'PDF',
        size: '2.5 MB',
        uploadDate: '2024-05-20',
        downloads: 45
    },
    {
        id: 2,
        title: 'Python Basics',
        course: 'Data Science',
        type: 'Video',
        size: '150 MB',
        uploadDate: '2024-05-18',
        downloads: 32
    }
];

// Editing IDs
let editingStudentId = null;
let editingCourseId = null;
let editingBatchId = null;
let editingPaymentId = null;
let editingPlacementId = null;

// Initialize on DOM Load
document.addEventListener('DOMContentLoaded', function() {
    // Set active menu item
    const currentPath = window.location.pathname;
    const menuItems = document.querySelectorAll('.menu-item');
    
    menuItems.forEach(item => {
        if (item.getAttribute('href') === currentPath) {
            item.classList.add('active');
        }
    });
    
    // Close modal on escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && currentModal) {
            closeModal();
        }
    });

    // Load data based on page
    loadPageData();
});

// Load data based on current page
function loadPageData() {
    const currentPath = window.location.pathname;
    
    if (currentPath.includes('students') && typeof loadStudents === 'function') {
        loadStudents();
    } else if (currentPath.includes('courses') && typeof loadCourses === 'function') {
        loadCourses();
    } else if (currentPath.includes('batches') && typeof loadBatches === 'function') {
        loadBatches();
    } else if (currentPath.includes('marketing') && typeof loadLeads === 'function') {
        loadLeads();
    } else if (currentPath.includes('payments') && typeof loadPayments === 'function') {
        loadPayments();
    } else if (currentPath.includes('placements') && typeof loadPlacements === 'function') {
        loadPlacements();
    } else if (currentPath.includes('notifications') && typeof loadNotifications === 'function') {
        loadNotifications();
    } else if (currentPath.includes('study-material') && typeof loadStudyMaterials === 'function') {
        loadStudyMaterials();
    }
}

// Sidebar Toggle
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.classList.toggle('open');
}

// Modal Functions
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    const overlay = document.getElementById('modal-overlay');
    
    if (modal && overlay) {
        modal.style.display = 'block';
        overlay.style.display = 'block';
        currentModal = modalId;
        document.body.style.overflow = 'hidden';
    }
}

function closeModal() {
    if (currentModal) {
        const modal = document.getElementById(currentModal);
        const overlay = document.getElementById('modal-overlay');
        
        if (modal && overlay) {
            modal.style.display = 'none';
            overlay.style.display = 'none';
            currentModal = null;
            document.body.style.overflow = 'auto';
        }
    }
}

// Students Functions
function loadStudents() {
    const tbody = document.getElementById('studentsTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    students.forEach(student => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>STU${String(student.id).padStart(3, '0')}</td>
            <td>${student.name}</td>
            <td>${student.email}</td>
            <td>${student.phone}</td>
            <td>${getCourseDisplayName(student.course)}</td>
            <td>${getBatchDisplayName(student.batch)}</td>
            <td><span class="status-badge status-${student.status}">${student.status}</span></td>
            <td>
                <div class="contact-actions">
                    <button class="contact-btn" onclick="openWhatsApp('${student.phone}', '${student.name}')" title="WhatsApp">💬</button>
                    <button class="contact-btn" onclick="makeCall('${student.phone}')" title="Call">📞</button>
                    <button class="contact-btn" onclick="sendEmail('${student.email}', '${student.name}')" title="Email">📧</button>
                    <button class="contact-btn" onclick="editStudent(${student.id})" title="Edit">✏</button>
                    <button class="contact-btn" onclick="deleteStudent(${student.id})" title="Delete">🗑</button>
                </div>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function openStudentModal() {
    editingStudentId = null;
    document.getElementById('studentModalTitle').textContent = 'Add Student';
    document.getElementById('studentForm').reset();
    openModal('studentModal');
}

function closeStudentModal() {
    closeModal();
}

function editStudent(studentId) {
    const student = students.find(s => s.id === studentId);
    if (student) {
        editingStudentId = studentId;
        document.getElementById('studentModalTitle').textContent = 'Edit Student';
        
        document.getElementById('studentName').value = student.name;
        document.getElementById('studentEmail').value = student.email;
        document.getElementById('studentPhone').value = student.phone;
        document.getElementById('studentCourse').value = student.course;
        document.getElementById('studentBatch').value = student.batch;
        document.getElementById('studentStatus').value = student.status;
        document.getElementById('admissionDate').value = student.admissionDate;
        
        openModal('studentModal');
    }
}

function saveStudent() {
    const formData = new FormData(document.getElementById('studentForm'));
    
    const studentData = {
        id: editingStudentId || (students.length + 1),
        name: formData.get('name'),
        email: formData.get('email'),
        phone: formData.get('phone'),
        course: formData.get('course'),
        batch: formData.get('batch'),
        status: formData.get('status'),
        admissionDate: formData.get('admission_date')
    };
    
    if (editingStudentId) {
        const index = students.findIndex(s => s.id === editingStudentId);
        students[index] = studentData;
        showToast('Student updated successfully!', 'success');
    } else {
        students.push(studentData);
        showToast('Student added successfully!', 'success');
    }
    
    loadStudents();
    closeStudentModal();
}

function deleteStudent(studentId) {
    if (confirm('Are you sure you want to delete this student?')) {
        students = students.filter(s => s.id !== studentId);
        loadStudents();
        showToast('Student deleted successfully!', 'success');
    }
}

function filterStudents() {
    const searchTerm = document.getElementById('studentSearch').value.toLowerCase();
    const courseFilter = document.getElementById('courseFilter').value;
    const statusFilter = document.getElementById('statusFilter').value;
    
    const filteredStudents = students.filter(student => {
        const matchesSearch = student.name.toLowerCase().includes(searchTerm) ||
                            student.email.toLowerCase().includes(searchTerm) ||
                            student.phone.includes(searchTerm);
        const matchesCourse = !courseFilter || student.course === courseFilter;
        const matchesStatus = !statusFilter || student.status === statusFilter;
        
        return matchesSearch && matchesCourse && matchesStatus;
    });
    
    displayFilteredStudents(filteredStudents);
}

function displayFilteredStudents(filteredStudents) {
    const tbody = document.getElementById('studentsTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    filteredStudents.forEach(student => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>STU${String(student.id).padStart(3, '0')}</td>
            <td>${student.name}</td>
            <td>${student.email}</td>
            <td>${student.phone}</td>
            <td>${getCourseDisplayName(student.course)}</td>
            <td>${getBatchDisplayName(student.batch)}</td>
            <td><span class="status-badge status-${student.status}">${student.status}</span></td>
            <td>
                <div class="contact-actions">
                    <button class="contact-btn" onclick="openWhatsApp('${student.phone}', '${student.name}')" title="WhatsApp">💬</button>
                    <button class="contact-btn" onclick="makeCall('${student.phone}')" title="Call">📞</button>
                    <button class="contact-btn" onclick="sendEmail('${student.email}', '${student.name}')" title="Email">📧</button>
                    <button class="contact-btn" onclick="editStudent(${student.id})" title="Edit">✏</button>
                    <button class="contact-btn" onclick="deleteStudent(${student.id})" title="Delete">🗑</button>
                </div>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Courses Functions
function loadCourses() {
    const tbody = document.getElementById('coursesTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    courses.forEach(course => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${course.code}</td>
            <td>${course.name}</td>
            <td>${course.duration} months</td>
            <td>₹${course.fee.toLocaleString()}</td>
            <td>${course.enrolled}/${course.maxStudents}</td>
            <td><span class="status-badge status-${course.status}">${course.status}</span></td>
            <td>
                <div class="contact-actions">
                    <button class="contact-btn" onclick="editCourse(${course.id})" title="Edit">✏</button>
                    <button class="contact-btn" onclick="deleteCourse(${course.id})" title="Delete">🗑</button>
                </div>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function openCourseModal() {
    editingCourseId = null;
    document.getElementById('courseModalTitle').textContent = 'Add Course';
    document.getElementById('courseForm').reset();
    openModal('courseModal');
}

function closeCourseModal() {
    closeModal();
}

function editCourse(courseId) {
    const course = courses.find(c => c.id === courseId);
    if (course) {
        editingCourseId = courseId;
        document.getElementById('courseModalTitle').textContent = 'Edit Course';
        
        document.getElementById('courseName').value = course.name;
        document.getElementById('courseCode').value = course.code;
        document.getElementById('courseDuration').value = course.duration;
        document.getElementById('courseFee').value = course.fee;
        document.getElementById('maxStudents').value = course.maxStudents;
        document.getElementById('courseStatus').value = course.status;
        
        openModal('courseModal');
    }
}

function saveCourse() {
    const formData = new FormData(document.getElementById('courseForm'));
    
    const courseData = {
        id: editingCourseId || (courses.length + 1),
        name: formData.get('course_name'),
        code: formData.get('course_code'),
        duration: parseInt(formData.get('duration')),
        fee: parseInt(formData.get('fee')),
        maxStudents: parseInt(formData.get('max_students')),
        status: formData.get('status'),
        enrolled: editingCourseId ? courses.find(c => c.id === editingCourseId).enrolled : 0
    };
    
    if (editingCourseId) {
        const index = courses.findIndex(c => c.id === editingCourseId);
        courses[index] = courseData;
        showToast('Course updated successfully!', 'success');
    } else {
        courses.push(courseData);
        showToast('Course added successfully!', 'success');
    }
    
    loadCourses();
    closeCourseModal();
}

function deleteCourse(courseId) {
    if (confirm('Are you sure you want to delete this course?')) {
        courses = courses.filter(c => c.id !== courseId);
        loadCourses();
        showToast('Course deleted successfully!', 'success');
    }
}

// Batches Functions
function loadBatches() {
    const tbody = document.getElementById('batchesTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    batches.forEach(batch => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>BATCH${String(batch.id).padStart(3, '0')}</td>
            <td>${batch.name}</td>
            <td>${getCourseDisplayName(batch.course)}</td>
            <td>${formatDate(batch.startDate)}</td>
            <td>${formatDate(batch.endDate)}</td>
            <td>${batch.students}/${batch.maxCapacity}</td>
            <td><span class="status-badge status-${batch.status}">${batch.status}</span></td>
            <td>
                <div class="contact-actions">
                    <button class="contact-btn" onclick="editBatch(${batch.id})" title="Edit">✏</button>
                    <button class="contact-btn" onclick="deleteBatch(${batch.id})" title="Delete">🗑</button>
                </div>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function openBatchModal() {
    editingBatchId = null;
    document.getElementById('batchModalTitle').textContent = 'Create Batch';
    document.getElementById('batchForm').reset();
    openModal('batchModal');
}

function closeBatchModal() {
    closeModal();
}

function editBatch(batchId) {
    const batch = batches.find(b => b.id === batchId);
    if (batch) {
        editingBatchId = batchId;
        document.getElementById('batchModalTitle').textContent = 'Edit Batch';
        
        document.getElementById('batchName').value = batch.name;
        document.getElementById('batchCourse').value = batch.course;
        document.getElementById('startDate').value = batch.startDate;
        document.getElementById('endDate').value = batch.endDate;
        document.getElementById('maxCapacity').value = batch.maxCapacity;
        document.getElementById('batchStatus').value = batch.status;
        
        openModal('batchModal');
    }
}

function saveBatch() {
    const formData = new FormData(document.getElementById('batchForm'));
    
    const batchData = {
        id: editingBatchId || (batches.length + 1),
        name: formData.get('batch_name'),
        course: formData.get('course'),
        startDate: formData.get('start_date'),
        endDate: formData.get('end_date'),
        maxCapacity: parseInt(formData.get('max_capacity')),
        status: formData.get('status'),
        students: editingBatchId ? batches.find(b => b.id === editingBatchId).students : 0
    };
    
    if (editingBatchId) {
        const index = batches.findIndex(b => b.id === editingBatchId);
        batches[index] = batchData;
        showToast('Batch updated successfully!', 'success');
    } else {
        batches.push(batchData);
        showToast('Batch created successfully!', 'success');
    }
    
    loadBatches();
    closeBatchModal();
}

function deleteBatch(batchId) {
    if (confirm('Are you sure you want to delete this batch?')) {
        batches = batches.filter(b => b.id !== batchId);
        loadBatches();
        showToast('Batch deleted successfully!', 'success');
    }
}

// Marketing/Leads Functions
function loadLeads() {
    const tbody = document.getElementById('leadsTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    leads.forEach(lead => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>LED${String(lead.id).padStart(3, '0')}</td>
            <td>${lead.name}</td>
            <td>${lead.email}</td>
            <td>${lead.phone}</td>
            <td>${getCourseDisplayName(lead.course)}</td>
            <td><span class="status-badge status-${lead.status}">${lead.status}</span></td>
            <td>${lead.source}</td>
            <td>
                <div class="contact-actions">
                    <button class="contact-btn" onclick="openWhatsApp('${lead.phone}', '${lead.name}')" title="WhatsApp">💬</button>
                    <button class="contact-btn" onclick="makeCall('${lead.phone}')" title="Call">📞</button>
                    <button class="contact-btn" onclick="sendEmail('${lead.email}', '${lead.name}')" title="Email">📧</button>
                    <button class="contact-btn" onclick="editLead(${lead.id})" title="Edit">✏</button>
                    <button class="contact-btn" onclick="deleteLead(${lead.id})" title="Delete">🗑</button>
                </div>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function openLeadModal() {
    document.getElementById('leadForm').reset();
    openModal('leadModal');
}

function closeLeadModal() {
    closeModal();
}

function saveLead() {
    const formData = new FormData(document.getElementById('leadForm'));
    
    const newLead = {
        id: leads.length + 1,
        name: formData.get('name'),
        email: formData.get('email'),
        phone: formData.get('phone'),
        course: formData.get('course'),
        status: formData.get('status'),
        source: formData.get('source')
    };
    
    leads.push(newLead);
    loadLeads();
    closeLeadModal();
    
    showToast('Lead added successfully!', 'success');
}

function editLead(leadId) {
    const lead = leads.find(l => l.id === leadId);
    if (lead) {
        document.getElementById('leadName').value = lead.name;
        document.getElementById('leadEmail').value = lead.email;
        document.getElementById('leadPhone').value = lead.phone;
        document.getElementById('leadCourse').value = lead.course;
        document.getElementById('leadStatus').value = lead.status;
        document.getElementById('leadSource').value = lead.source;
        
        openLeadModal();
    }
}

function deleteLead(leadId) {
    if (confirm('Are you sure you want to delete this lead?')) {
        leads = leads.filter(l => l.id !== leadId);
        loadLeads();
        showToast('Lead deleted successfully!', 'success');
    }
}

function filterLeads() {
    const searchTerm = document.getElementById('leadSearch').value.toLowerCase();
    const statusFilter = document.getElementById('statusFilter').value;
    const sourceFilter = document.getElementById('sourceFilter').value;
    
    const filteredLeads = leads.filter(lead => {
        const matchesSearch = lead.name.toLowerCase().includes(searchTerm) ||
                            lead.email.toLowerCase().includes(searchTerm) ||
                            lead.phone.includes(searchTerm);
        const matchesStatus = !statusFilter || lead.status === statusFilter;
        const matchesSource = !sourceFilter || lead.source === sourceFilter;
        
        return matchesSearch && matchesStatus && matchesSource;
    });
    
    displayFilteredLeads(filteredLeads);
}

function displayFilteredLeads(filteredLeads) {
    const tbody = document.getElementById('leadsTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    filteredLeads.forEach(lead => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>LED${String(lead.id).padStart(3, '0')}</td>
            <td>${lead.name}</td>
            <td>${lead.email}</td>
            <td>${lead.phone}</td>
            <td>${getCourseDisplayName(lead.course)}</td>
            <td><span class="status-badge status-${lead.status}">${lead.status}</span></td>
            <td>${lead.source}</td>
            <td>
                <div class="contact-actions">
                    <button class="contact-btn" onclick="openWhatsApp('${lead.phone}', '${lead.name}')" title="WhatsApp">💬</button>
                    <button class="contact-btn" onclick="makeCall('${lead.phone}')" title="Call">📞</button>
                    <button class="contact-btn" onclick="sendEmail('${lead.email}', '${lead.name}')" title="Email">📧</button>
                    <button class="contact-btn" onclick="editLead(${lead.id})" title="Edit">✏</button>
                    <button class="contact-btn" onclick="deleteLead(${lead.id})" title="Delete">🗑</button>
                </div>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Payments Functions
function loadPayments() {
    const tbody = document.getElementById('paymentsTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    payments.forEach(payment => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>PAY${String(payment.id).padStart(3, '0')}</td>
            <td>${payment.studentName}</td>
            <td>Course Name</td>
            <td>₹${payment.amount.toLocaleString()}</td>
            <td>${payment.method}</td>
            <td>${formatDate(payment.date)}</td>
            <td><span class="status-badge status-${payment.status}">${payment.status}</span></td>
            <td>
                <div class="contact-actions">
                    <button class="contact-btn" onclick="editPayment(${payment.id})" title="Edit">✏</button>
                    <button class="contact-btn" onclick="deletePayment(${payment.id})" title="Delete">🗑</button>
                </div>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function openPaymentModal() {
    editingPaymentId = null;
    document.getElementById('paymentModalTitle').textContent = 'Add Payment';
    document.getElementById('paymentForm').reset();
    openModal('paymentModal');
}

function closePaymentModal() {
    closeModal();
}

function savePayment() {
    const formData = new FormData(document.getElementById('paymentForm'));
    
    const paymentData = {
        id: editingPaymentId || (payments.length + 1),
        studentName: formData.get('student'),
        amount: parseInt(formData.get('amount')),
        method: formData.get('method'),
        date: formData.get('date'),
        status: formData.get('status'),
        transactionId: formData.get('transaction_id')
    };
    
    if (editingPaymentId) {
        const index = payments.findIndex(p => p.id === editingPaymentId);
        payments[index] = paymentData;
        showToast('Payment updated successfully!', 'success');
    } else {
        payments.push(paymentData);
        showToast('Payment added successfully!', 'success');
    }
    
    loadPayments();
    closePaymentModal();
}

function filterPayments() {
    const searchTerm = document.getElementById('paymentSearch').value.toLowerCase();
    const statusFilter = document.getElementById('statusFilter').value;
    const methodFilter = document.getElementById('methodFilter').value;
    
    const filteredPayments = payments.filter(payment => {
        const matchesSearch = payment.studentName.toLowerCase().includes(searchTerm);
        const matchesStatus = !statusFilter || payment.status === statusFilter;
        const matchesMethod = !methodFilter || payment.method === methodFilter;
        
        return matchesSearch && matchesStatus && matchesMethod;
    });
    
    displayFilteredPayments(filteredPayments);
}

function displayFilteredPayments(filteredPayments) {
    const tbody = document.getElementById('paymentsTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    filteredPayments.forEach(payment => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>PAY${String(payment.id).padStart(3, '0')}</td>
            <td>${payment.studentName}</td>
            <td>Course Name</td>
            <td>₹${payment.amount.toLocaleString()}</td>
            <td>${payment.method}</td>
            <td>${formatDate(payment.date)}</td>
            <td><span class="status-badge status-${payment.status}">${payment.status}</span></td>
            <td>
                <div class="contact-actions">
                    <button class="contact-btn" onclick="editPayment(${payment.id})" title="Edit">✏</button>
                    <button class="contact-btn" onclick="deletePayment(${payment.id})" title="Delete">🗑</button>
                </div>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Placements Functions
function loadPlacements() {
    const tbody = document.getElementById('placementsTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    placements.forEach(placement => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>PLC${String(placement.id).padStart(3, '0')}</td>
            <td>${placement.studentName}</td>
            <td>${placement.company}</td>
            <td>${placement.position}</td>
            <td>₹${placement.salary.toLocaleString()}</td>
            <td>${placement.course}</td>
            <td><span class="status-badge status-${placement.status}">${placement.status}</span></td>
            <td>
                <div class="contact-actions">
                    <button class="contact-btn" onclick="editPlacement(${placement.id})" title="Edit">✏</button>
                    <button class="contact-btn" onclick="deletePlacement(${placement.id})" title="Delete">🗑</button>
                </div>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function openPlacementModal() {
    editingPlacementId = null;
    document.getElementById('placementModalTitle').textContent = 'Add Placement';
    document.getElementById('placementForm').reset();
    openModal('placementModal');
}

function closePlacementModal() {
    closeModal();
}

function savePlacement() {
    const formData = new FormData(document.getElementById('placementForm'));
    
    const placementData = {
        id: editingPlacementId || (placements.length + 1),
        studentName: formData.get('student_name'),
        studentId: formData.get('student_id'),
        company: formData.get('company'),
        position: formData.get('position'),
        salary: parseInt(formData.get('salary')),
        course: formData.get('course'),
        status: formData.get('status'),
        placementDate: formData.get('placement_date')
    };
    
    if (editingPlacementId) {
        const index = placements.findIndex(p => p.id === editingPlacementId);
        placements[index] = placementData;
        showToast('Placement updated successfully!', 'success');
    } else {
        placements.push(placementData);
        showToast('Placement added successfully!', 'success');
    }
    
    loadPlacements();
    closePlacementModal();
}

// Notifications Functions
function loadNotifications() {
    const notificationsList = document.getElementById('notificationsList');
    if (!notificationsList) return;
    
    notificationsList.innerHTML = '';
    
    notifications.forEach(notification => {
        const notificationItem = createNotificationItem(notification);
        notificationsList.appendChild(notificationItem);
    });
}

function createNotificationItem(notification) {
    const item = document.createElement('div');
    item.className = notification-item `${notification.status}`;
    
    const iconMap = {
        'payment': '💳',
        'course': '📚',
        'batch': '🎓',
        'general': '📢'
    };
    
    item.innerHTML = `
        <div class="notification-icon ${notification.type}">
            ${iconMap[notification.type]}
        </div>
        <div class="notification-content">
            <div class="notification-title">${notification.title}</div>
            <div class="notification-message">${notification.message}</div>
            <div class="notification-meta">
                ${formatDateTime(notification.timestamp)} • ${notification.recipients}
            </div>
        </div>
        <div class="notification-actions">
            ${notification.status === 'unread' ? 
                <button class="btn btn-small btn-secondary" onclick="markAsRead(${notification.id})">Mark Read</button> :
                <span class="status-badge status-read">Read</span>
            }
            <button class="btn btn-small btn-danger" onclick="deleteNotification(${notification.id})">Delete</button>
        </div>
    `;
    
    return item;
}

function sendNotification() {
    const formData = new FormData(document.getElementById('notificationForm'));
    
    const newNotification = {
        id: notifications.length + 1,
        type: formData.get('type'),
        title: formData.get('title'),
        message: formData.get('message'),
        recipients: formData.get('recipients'),
        status: 'unread',
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19)
    };
    
    notifications.unshift(newNotification);
    loadNotifications();
    
    document.getElementById('notificationForm').reset();
    
    showToast('Notification sent successfully!', 'success');
}

function markAsRead(notificationId) {
    const notification = notifications.find(n => n.id === notificationId);
    if (notification) {
        notification.status = 'read';
        loadNotifications();
        showToast('Notification marked as read!', 'success');
    }
}

function deleteNotification(notificationId) {
    if (confirm('Are you sure you want to delete this notification?')) {
        notifications = notifications.filter(n => n.id !== notificationId);
        loadNotifications();
        showToast('Notification deleted successfully!', 'success');
    }
}

// Study Materials Functions
function loadStudyMaterials() {
    const materialsList = document.getElementById('materialsList');
    if (!materialsList) return;
    
    materialsList.innerHTML = '';
    
    studyMaterials.forEach(material => {
        const materialCard = createMaterialCard(material);
        materialsList.appendChild(materialCard);
    });
}

function createMaterialCard(material) {
    const card = document.createElement('div');
    card.className = 'material-card';
    
    card.innerHTML = `
        <div class="material-header">
            <div class="material-title">${material.title}</div>
            <div class="material-meta">
                <span>${material.course}</span>
                <span>${material.type} • ${material.size}</span>
            </div>
        </div>
        <div class="material-actions">
            <button class="btn btn-primary btn-small" onclick="downloadMaterial(${material.id})">Download</button>
            <button class="btn btn-secondary btn-small" onclick="editMaterial(${material.id})">Edit</button>
            <button class="btn btn-danger btn-small" onclick="deleteMaterial(${material.id})">Delete</button>
        </div>
    `;
    
    return card;
}

function uploadMaterial() {
    const formData = new FormData(document.getElementById('materialForm'));
    
    const newMaterial = {
        id: studyMaterials.length + 1,
        title: formData.get('title'),
        course: formData.get('course'),
        type: 'PDF',
        size: '2.5 MB',
        uploadDate: new Date().toISOString().split('T')[0],
        downloads: 0
    };
    
    studyMaterials.push(newMaterial);
    loadStudyMaterials();
    
    document.getElementById('materialForm').reset();
    showToast('Material uploaded successfully!', 'success');
}

function downloadMaterial(materialId) {
    const material = studyMaterials.find(m => m.id === materialId);
    if (material) {
        material.downloads++;
        showToast(Downloading `${material.title}..., 'info'`);
    }
}

// KPI Dashboard Functions
function updateDashboard() {
    const filterType = document.getElementById('filterType')?.value;
    const startDate = document.getElementById('startDate')?.value;
    const endDate = document.getElementById('endDate')?.value;
    
    console.log('Updating dashboard with filters:', { filterType, startDate, endDate });
    showToast('Dashboard updated successfully', 'success');
}

function resetFilters() {
    if (document.getElementById('filterType')) {
        document.getElementById('filterType').value = 'all';
        document.getElementById('startDate').value = '';
        document.getElementById('endDate').value = '';
        updateDashboard();
    }
}

function showDetails(type) {
    const titles = {
        'admissions': 'All Students',
        'courses': 'All Courses',
        'batches': 'All Batches',
        'payment-done': 'Students with Payments Done',
        'payment-due': 'Students with Due Payments'
    };
    
    alert(`${titles[type]} details would be displayed here.`);
}

// Contact Actions
function openWhatsApp(phone, name) {
    const message = encodeURIComponent(`Hi ${name}, I hope you're doing well!`);
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    window.open(`https://wa.me/${cleanPhone}?text=${message}`, '_blank');
}

function makeCall(phone) {
    window.open(`tel:${phone}`, '_self');
}

function sendEmail(email, name) {
    const subject = encodeURIComponent(`Regarding your inquiry - ${name}`);
    const body = encodeURIComponent(`Dear ${name},\n\nI hope this email finds you well.\n\nBest regards,\nZee-Tech Academy`);
    window.open(`mailto:${email}?subject=${subject}&body=${body}`, '_self');
}

// Export Functions
function exportLeads() {
    const csvContent = "Lead ID,Name,Email,Phone,Course,Status,Source\n" +
                      leads.map(lead => 
                          `LED${String(lead.id).padStart(3, '0')},${lead.name},${lead.email},${lead.phone},${lead.course},${lead.status},${lead.source}`
                      ).join('\n');
    
    downloadCSV(csvContent, 'leads_export.csv');
    showToast('Leads exported successfully!', 'success');
}

function exportData(dataType) {
    showToast(`Preparing ${dataType} data for export...`, 'info');
    
    setTimeout(() => {
        let csvContent = '';
        let filename = '';
        
        switch(dataType) {
            case 'students':
                csvContent = "Student ID,Name,Email,Phone,Course,Status\n" +
                           students.map(s => `STU${String(s.id).padStart(3, '0')},${s.name},${s.email},${s.phone},${s.course},${s.status}`).join('\n');
                filename = 'students_export.csv';
                break;
            case 'payments':
                csvContent = "Payment ID,Student Name,Amount,Date,Status\n" +
                           payments.map(p => `PAY${String(p.id).padStart(3, '0')},${p.studentName},${p.amount},${p.date},${p.status}`).join('\n');
                filename = 'payments_export.csv';
                break;
            case 'marketing':
                csvContent = "Lead ID,Name,Email,Phone,Status\n" +
                           leads.map(l => `LED${String(l.id).padStart(3, '0')},${l.name},${l.email},${l.phone},${l.status}`).join('\n');
                filename = 'marketing_export.csv';
                break;
        }
        
        downloadCSV(csvContent, filename);
        showToast(`${dataType} data exported successfully!`, 'success');
    }, 2000);
}

// Upload Functions
function downloadTemplate() {
    const csvContent = "Lead Name,Email,Phone,Course,Status,Source,Notes\n" +
                      "John Doe,john@example.com,9876543210,Full Stack Development,enquiry,website,Interested in course\n" +
                      "Jane Smith,jane@example.com,9876543211,Data Science,hot,social-media,Ready to enroll";
    
    downloadCSV(csvContent, 'marketing_data_template.csv');
}

function downloadPlacementTemplate() {
    const csvContent = "Student Name,Student ID,Company Name,Job Position,Salary,Status,Course,Placement Date,Notes\n" +
                      "John Doe,STU001,Tech Corp,Software Developer,600000,placed,Full Stack Development,2024-05-15,Great performance\n" +
                      "Jane Smith,STU002,Data Inc,Data Analyst,550000,placed,Data Science,2024-05-20,Excellent skills";
    
    downloadCSV(csvContent, 'placement_data_template.csv');
}

// Utility Functions
function downloadCSV(csvContent, filename) {
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
}

function getCourseDisplayName(courseCode) {
    const courseNames = {
        'full-stack': 'Full Stack Development',
        'data-science': 'Data Science',
        'web-dev': 'Web Development',
        'mobile-dev': 'Mobile Development'
    };
    return courseNames[courseCode] || courseCode;
}

function getBatchDisplayName(batchCode) {
    const batchNames = {
        'batch-1': 'Batch 2024-A',
        'batch-2': 'Batch 2024-B',
        'batch-3': 'Batch 2024-C'
    };
    return batchNames[batchCode] || batchCode;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB');
}

function formatDateTime(dateTimeString) {
    const date = new Date(dateTimeString);
    return date.toLocaleDateString('en-GB') + ' ' + date.toLocaleTimeString('en-GB', {hour: '2-digit', minute:'2-digit'});
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(amount);
}

// Show Toast Messages
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `notification ${type}`;
    
    const iconMap = {
        'success': '✅',
        'error': '❌',
        'info': 'ℹ',
        'warning': '⚠'
    };
    
    toast.innerHTML = `
        <span class="icon">${iconMap[type]}</span>
        <span>${message}</span>
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, 3000);
}

// Form Validation
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return true;
    
    const requiredFields = form.querySelectorAll('[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.style.borderColor = '#ef4444';
            isValid = false;
        } else {
            field.style.borderColor = '#ddd';
        }
    });
    
    return isValid;
}

// Initialize forms on page load
document.addEventListener('DOMContentLoaded', function() {
    // Attach form event listeners
    const forms = ['studentForm', 'courseForm', 'batchForm', 'leadForm', 'paymentForm', 'placementForm', 'notificationForm', 'materialForm'];
    
    forms.forEach(formId => {
        const form = document.getElementById(formId);
        if (form) {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                
                if (validateForm(formId)) {
                    // Call appropriate save function based on form
                    switch(formId) {
                        case 'studentForm': saveStudent(); break;
                        case 'courseForm': saveCourse(); break;
                        case 'batchForm': saveBatch(); break;
                        case 'leadForm': saveLead(); break;
                        case 'paymentForm': savePayment(); break;
                        case 'placementForm': savePlacement(); break;
                        case 'notificationForm': sendNotification(); break;
                        case 'materialForm': uploadMaterial(); break;
                    }
                }
            });
        }
    });
});