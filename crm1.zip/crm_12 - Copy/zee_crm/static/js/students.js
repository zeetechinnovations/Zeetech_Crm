document.addEventListener('DOMContentLoaded', function () {
    // Get CSRF token from cookie or hidden input
    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let cookie of cookies) {
                cookie = cookie.trim();
                if (cookie.startsWith(name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue || document.querySelector('input[name="csrfmiddlewaretoken"]')?.value;
    }

    // Show notification
    function showNotification(type, message) {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        const iconMap = {
            'success': '✅',
            'error': '❌',
            'info': 'ℹ'
        };
        notification.innerHTML = `
            <span class="icon">${iconMap[type]}</span>
            <span>${message}</span>
        `;
        document.body.appendChild(notification);
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    // Get user role
    const userRole = document.querySelector('meta[name="user-role"]')?.content || 'student';
    console.log('User role:', userRole);

    // Open student modal
    window.openStudentModal = function () {
        console.log('Opening student modal');
        const modal = document.getElementById('studentModal');
        const overlay = document.getElementById('modal-overlay');
        const modalTitle = document.getElementById('studentModalTitle');
        const studentForm = document.getElementById('studentForm');
        const studentId = document.getElementById('studentId');
        const formError = document.getElementById('formError');

        if (!modal || !overlay || !modalTitle || !studentForm || !studentId || !formError) {
            console.error('Modal elements missing:', { modal, overlay, modalTitle, studentForm, studentId, formError });
            showNotification('error', 'Form elements not found');
            return;
        }

        modal.style.display = 'block';
        overlay.style.display = 'block';
        modalTitle.textContent = 'Add Student';
        studentForm.reset();
        studentId.value = '';
        formError.textContent = '';
    };

    // Close student modal
    window.closeStudentModal = function () {
        console.log('Closing student modal');
        const modal = document.getElementById('studentModal');
        const overlay = document.getElementById('modal-overlay');
        if (modal && overlay) {
            modal.style.display = 'none';
            overlay.style.display = 'none';
        } else {
            console.error('Modal or overlay not found');
        }
    };

    // Filter students
    window.filterStudents = function () {
        if (userRole === 'student') return;
        const search = document.getElementById('studentSearch')?.value.toLowerCase() || '';
        const course = document.getElementById('courseFilter')?.value.toLowerCase() || '';
        const status = document.getElementById('statusFilter')?.value.toLowerCase() || '';
        const rows = document.getElementById('studentsTableBody')?.getElementsByTagName('tr') || [];
        for (let row of rows) {
            const name = row.cells[1]?.textContent.toLowerCase() || '';
            const courseCell = row.cells[4]?.textContent.toLowerCase() || '';
            const statusCell = row.cells[6]?.textContent.toLowerCase() || '';
            const show = (search === '' || name.includes(search)) &&
                         (course === '' || courseCell.includes(course)) &&
                         (status === '' || statusCell.includes(status));
            row.style.display = show ? '' : 'none';
        }
    };

    // Handle form submission
    const studentForm = document.getElementById('studentForm');
    if (studentForm && userRole === 'admin') {
        studentForm.addEventListener('submit', function (e) {
            e.preventDefault();
            console.log('Form submitted');
            const formData = new FormData(this);
            const data = Object.fromEntries(formData);
            data.placed = formData.get('placed') === 'on';
            console.log('Form data:', data);

            // Enhanced client-side validation
            if (!data.name || !data.name.trim()) {
                showNotification('error', 'Please enter a valid name');
                document.getElementById('formError').textContent = 'Please enter a valid name';
                return;
            }
            if (!data.email || !data.email.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/)) {
                showNotification('error', 'Please enter a valid email address');
                document.getElementById('formError').textContent = 'Please enter a valid email address';
                return;
            }
            if (!data.phone || !data.phone.match(/^\+?[1-9]\d{1,14}$/)) {
                showNotification('error', 'Please enter a valid phone number');
                document.getElementById('formError').textContent = 'Please enter a valid phone number';
                return;
            }
            if (!data.course_id) {
                showNotification('error', 'Please select a course');
                document.getElementById('formError').textContent = 'Please select a course';
                return;
            }

            const studentId = data.id;
            const url = studentId ? `/students/edit-student/${studentId}/` : '/students/add-student/';

            fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCookie('csrftoken'),
                    'X-Requested-With': 'XMLHttpRequest',
                },
                body: JSON.stringify(data),
            })
            .then(response => {
                console.log('Response status:', response.status);
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(result => {
                console.log('Response data:', result);
                if (result.status === 'success') {
                    showNotification('success', studentId ? 'Student updated successfully!' : 'Student added successfully!');
                    closeStudentModal();
                    // Update table dynamically
                    if (!studentId) {
                        const tableBody = document.getElementById('studentsTableBody');
                        const row = document.createElement('tr');
                        row.setAttribute('data-student-id', result.student.id);
                        row.innerHTML = `
                            <td>${result.student.student_id}</td>
                            <td>${result.student.name}</td>
                            <td>${result.student.email}</td>
                            <td>${result.student.phone}</td>
                            <td>${result.student.formatted_course}</td>
                            <td>${result.student.formatted_batch}</td>
                            <td><span class="status-badge status-${result.student.status}">${result.student.status}</span></td>
                            <td>${result.student.placed ? 'Yes' : 'No'}</td>
                            <td>
                                <div class="action-buttons">
                                    <button class="btn btn-edit" onclick="openWhatsApp('${result.student.phone}', '${result.student.name}')">💬</button>
                                    <button class="btn btn-edit" onclick="makeCall('${result.student.phone}')">📞</button>
                                    <button class="btn btn-edit" onclick="sendEmail('${result.student.email}', '${result.student.name}')">📧</button>
                                    <button class="btn btn-edit" onclick="editStudent(${result.student.id})">✏</button>
                                    <button class="btn btn-delete" onclick="deleteStudent(${result.student.id})">🗑</button>
                                    <button class="btn btn-view" onclick="viewStudentDetails(${result.student.id})">👁</button>
                                </div>
                            </td>
                        `;
                        tableBody.insertBefore(row, tableBody.firstChild);
                    }
                } else {
                    showNotification('error', result.message || 'An error occurred');
                    document.getElementById('formError').textContent = result.message || 'An error occurred';
                }
            })
            .catch(error => {
                console.error('Fetch error:', error);
                showNotification('error', 'Failed to save student: ' + error.message);
                document.getElementById('formError').textContent = error.message;
            });
        });
    }

    // Edit student
    window.editStudent = function (id) {
        if (userRole !== 'admin') return;
        console.log('Editing student:', id);
        fetch(`/students/view-student/${id}/`, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('Student data:', data);
            if (data.status === 'error') {
                showNotification('error', data.message || 'Failed to load student data');
                return;
            }
            document.getElementById('studentId').value = data.id || '';
            document.getElementById('studentName').value = data.name || '';
            document.getElementById('studentEmail').value = data.email || '';
            document.getElementById('studentPhone').value = data.phone || '';
            document.getElementById('studentDOB').value = data.dob || '';
            document.getElementById('studentCourse').value = data.course_id || '';
            document.getElementById('studentBatch').value = data.batch_id || '';
            document.getElementById('admissionDate').value = data.admission_date || '';
            document.getElementById('studentStatus').value = data.status || 'active';
            document.getElementById('studentPlaced').checked = data.placed || false;
            document.getElementById('studentAddress').value = data.address || '';
            document.getElementById('studentModalTitle').textContent = 'Edit Student';
            document.getElementById('studentModal').style.display = 'block';
            document.getElementById('modal-overlay').style.display = 'block';
        })
        .catch(error => {
            console.error('Error loading student:', error);
            showNotification('error', 'Failed to load student data: ' + error.message);
        });
    };

    // Delete student
    window.deleteStudent = function (id) {
        if (userRole !== 'admin') return;
        if (confirm('Are you sure you want to delete this student?')) {
            console.log('Deleting student:', id);
            fetch(`/students/delete-student/${id}/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCookie('csrftoken'),
                    'X-Requested-With': 'XMLHttpRequest',
                },
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(result => {
                console.log('Delete response:', result);
                if (result.status === 'success') {
                    showNotification('success', 'Student deleted successfully!');
                    const row = document.querySelector(`tr[data-student-id="${id}"]`);
                    if (row) row.remove();
                } else {
                    showNotification('error', result.message || 'Error deleting student');
                }
            })
            .catch(error => {
                console.error('Error deleting student:', error);
                showNotification('error', 'Failed to delete student: ' + error.message);
            });
        }
    };

    // Open WhatsApp
    window.openWhatsApp = function (phone, name) {
        window.open(`https://wa.me/${phone}?text=Hello%20${encodeURIComponent(name)}`, '_blank');
    };

    // Make phone call
    window.makeCall = function (phone) {
        window.location.href = `tel:${phone}`;
    };

    // Send email
    window.sendEmail = function (email, name) {
        window.location.href = `mailto:${email}?subject=Hello%20${encodeURIComponent(name)}`;
    };

    // View student details
    window.viewStudentDetails = function (id) {
        console.log('Viewing student details:', id);
        fetch(`/students/view-student/${id}/`, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('Student details:', data);
            if (data.status === 'error') {
                showNotification('error', data.message || 'Failed to load student details');
                return;
            }
            const details = [
                `Name: ${data.name || 'N/A'}`,
                `Email: ${data.email || 'N/A'}`,
                `Phone: ${data.phone || 'N/A'}`,
                `Course: ${data.course || 'None'}`,
                `Batch: ${data.batch || 'None'}`,
                `Status: ${data.status || 'N/A'}`,
                `Placed: ${data.placed ? 'Yes' : 'No'}`,
                `Address: ${data.address || 'None'}`
            ].join('\n');
            alert(`Student Details:\n${details}`);
        })
        .catch(error => {
            console.error('Error viewing student:', error);
            showNotification('error', 'Failed to load student details: ' + error.message);
        });
    };
});