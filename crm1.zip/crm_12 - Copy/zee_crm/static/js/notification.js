document.addEventListener('DOMContentLoaded', function() {
    const notificationForm = document.getElementById('notificationForm');
    const recipientsSelect = document.getElementById('recipients');
    const courseSelectGroup = document.getElementById('courseSelectGroup');
    const studentSelectGroup = document.getElementById('studentSelectGroup');
    
    // Load notifications on page load
    loadNotifications();

    // Handle form submission
    notificationForm.addEventListener('submit', function(e) {
        e.preventDefault();
        sendNotification();
    });

    // Show/hide course and student selection based on recipient type
    recipientsSelect.addEventListener('change', function() {
        courseSelectGroup.style.display = this.value === 'course-specific' || this.value === 'batch-specific' ? 'block' : 'none';
        studentSelectGroup.style.display = this.value === 'individual' ? 'block' : 'none';
    });
});

function loadNotifications() {
    const statusFilter = document.getElementById('statusFilter').value;
    const typeFilter = document.getElementById('typeFilter').value;
    const url = `/notifications/list/?status=${statusFilter}&type=${typeFilter}`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            const notificationsList = document.getElementById('notificationsList');
            notificationsList.innerHTML = '';
            
            // Update metrics
            const totalNotifications = data.notifications.length;
            const unreadNotifications = data.notifications.filter(n => n.status === 'unread').length;
            document.getElementById('totalNotifications').textContent = totalNotifications;
            document.getElementById('unreadNotifications').textContent = unreadNotifications;
            document.getElementById('readNotifications').textContent = totalNotifications - unreadNotifications;
            
            // Populate notifications
            data.notifications.forEach(notification => {
                const notificationItem = createNotificationItem(notification);
                notificationsList.appendChild(notificationItem);
            });
        })
        .catch(error => showNotification('error', 'Failed to load notifications: ' + error.message));
}

function createNotificationItem(notification) {
    const item = document.createElement('div');
    item.className = `notification-item ${notification.status}`;
    
    const iconMap = {
        'payment': '💳',
        'course': '📚',
        'batch': '🎓',
        'general': '📢'
    };
    
    item.innerHTML = `
        <div class="notification-icon ${notification.type}">
            ${iconMap[notification.type]}
        </div>
        <div class="notification-content">
            <div class="notification-title">${notification.title}</div>
            <div class="notification-message">${notification.message}</div>
            <div class="notification-meta">
                ${formatDateTime(notification.timestamp)} • ${notification.recipients}
            </div>
        </div>
        <div class="notification-actions">
            ${notification.status === 'unread' ? 
                `<button class="btn btn-small btn-secondary" onclick="markAsRead(${notification.id})">Mark Read</button>` :
                `<span class="status-badge status-read">Read</span>`
            }
            <button class="btn btn-small btn-danger" onclick="deleteNotification(${notification.id})">Delete</button>
        </div>
    `;
    
    return item;
}

function filterNotifications() {
    loadNotifications();
}

function sendNotification() {
    const formData = new FormData(document.getElementById('notificationForm'));
    const data = Object.fromEntries(formData);
    // Respect checkbox values
    data.send_email = document.getElementById('sendEmail').checked;
    data.send_sms = document.getElementById('sendSMS').checked;
    console.log('Form Data:', data);
    
    fetch('/notifications/send/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            document.getElementById('notificationForm').reset();
            document.getElementById('courseSelectGroup').style.display = 'none';
            document.getElementById('studentSelectGroup').style.display = 'none';
            loadNotifications();
            showNotification('success', data.message);
        } else if (data.status === 'warning') {
            showNotification('warning', data.message + (data.details ? ': ' + data.details : ''));
        } else {
            let errorMessage = data.message;
            if (data.errors) {
                errorMessage += ': ' + data.errors.join('; ');
            }
            showNotification('error', errorMessage);
        }
    })
    .catch(error => showNotification('error', 'Failed to send notification: ' + error.message));
}

function markAsRead(notificationId) {
    fetch(`/notifications/mark-read/${notificationId}/`, {
        method: 'POST',
        headers: {
            'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            loadNotifications();
            showNotification('success', data.message);
        } else {
            showNotification('error', data.message);
        }
    })
    .catch(error => showNotification('error', 'Failed to mark notification as read: ' + error.message));
}

function markAllRead() {
    fetch('/notifications/mark-all-read/', {
        method: 'POST',
        headers: {
            'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            loadNotifications();
            showNotification('success', data.message);
        } else {
            showNotification('error', data.message);
        }
    })
    .catch(error => showNotification('error', 'Failed to mark all notifications as read: ' + error.message));
}

function deleteNotification(notificationId) {
    if (confirm('Are you sure you want to delete this notification?')) {
        fetch(`/notifications/delete/${notificationId}/`, {
            method: 'POST',
            headers: {
                'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                loadNotifications();
                showNotification('success', data.message);
            } else {
                showNotification('error', data.message);
            }
        })
        .catch(error => showNotification('error', 'Failed to delete notification: ' + error.message));
    }
}

function formatDateTime(dateTimeString) {
    const date = new Date(dateTimeString);
    return date.toLocaleDateString('en-GB') + ' ' + date.toLocaleTimeString('en-GB', {hour: '2-digit', minute:'2-digit'});
}

function showNotification(type, message) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    
    const iconMap = {
        'success': '✅',
        'error': '❌',
        'info': 'ℹ',
        'warning': '⚠'
    };
    
    notification.innerHTML = `
        <span class="icon">${iconMap[type]}</span>
        <span>${message}</span>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 5000);
}


