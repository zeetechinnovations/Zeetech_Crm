document.addEventListener('DOMContentLoaded', function() {
    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let cookie of cookies) {
                cookie = cookie.trim();
                if (cookie.startsWith(name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        console.log(`CSRF Token for ${name}:`, cookieValue); // Debugging
        return cookieValue;
    }

    function showNotification(type, message) {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        const iconMap = {
            'success': '✅',
            'error': '❌',
            'info': 'ℹ'
        };
        notification.innerHTML = `
            <span class="icon">${iconMap[type]}</span>
            <span>${message}</span>
        `;
        document.body.appendChild(notification);
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    // Profile Form Submission
    const profileForm = document.getElementById('profileForm');
    if (profileForm) {
        profileForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const firstName = document.getElementById('firstName').value.trim();
            const lastName = document.getElementById('lastName').value.trim();
            const email = document.getElementById('email').value.trim();
            const phone = document.getElementById('phone').value.trim();

            if (!firstName || !lastName) {
                showNotification('error', 'First name and last name are required');
                return;
            }
            if (!email.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/)) {
                showNotification('error', 'Please enter a valid email address');
                return;
            }
            if (!phone.match(/^[0-9]{10}$/)) {
                showNotification('error', 'Please enter a valid 10-digit phone number');
                return;
            }

            const formData = new FormData(profileForm);
            console.log('Profile Form Data:', Object.fromEntries(formData)); // Debugging
            fetch(profileForm.action, {
                method: 'POST',
                headers: {
                    'X-CSRFToken': getCookie('csrftoken'),
                },
                body: formData,
            })
            .then(response => {
                console.log('Profile Response Status:', response.status); // Debugging
                return response.json();
            })
            .then(data => {
                if (data.error) {
                    showNotification('error', data.error);
                } else {
                    showNotification('success', 'Profile updated successfully!');
                }
            })
            .catch(error => {
                console.error('Profile Update Error:', error); // Debugging
                showNotification('error', 'Failed to update profile: ' + error.message);
            });
        });
    }
    // Password Form Submission
    const passwordForm = document.getElementById('passwordForm');
    if (passwordForm) {
        passwordForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const currentPassword = document.getElementById('currentPassword').value;
            const newPassword = document.getElementById('newPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;

            if (newPassword !== confirmPassword) {
                showNotification('error', 'New passwords do not match!');
                return;
            }
            if (newPassword.length < 8) {
                showNotification('error', 'Password must be at least 8 characters long!');
                return;
            }

            const formData = new FormData(passwordForm);
            console.log('Password Form Data:', Object.fromEntries(formData)); // Debugging
            fetch(passwordForm.action, {
                method: 'POST',
                headers: {
                    'X-CSRFToken': getCookie('csrftoken'),
                },
                body: formData,
            })
            .then(response => {
                console.log('Password Response Status:', response.status); // Debugging
                return response.json();
            })
            .then(data => {
                if (data.error) {
                    showNotification('error', data.error);
                } else {
                    showNotification('success', 'Password changed successfully! Please log in again if prompted.');
                    passwordForm.reset();
                }
            })
            .catch(error => {
                console.error('Password Change Error:', error); // Debugging
                showNotification('error', 'Failed to change password: ' + error.message);
            });
        });
    }

    // System Settings Form Submission
    const systemForm = document.getElementById('systemForm');
    if (systemForm) {
        systemForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(systemForm);
            console.log('System Form Data:', Object.fromEntries(formData)); // Debugging
            fetch(systemForm.action, {
                method: 'POST',
                headers: {
                    'X-CSRFToken': getCookie('csrftoken'),
                },
                body: formData,
            })
            .then(response => {
                console.log('System Response Status:', response.status); // Debugging
                return response.json();
            })
            .then(data => {
                if (data.error) {
                    showNotification('error', data.error);
                } else {
                    showNotification('success', 'System settings saved successfully!');
                }
            })
            .catch(error => {
                console.error('System Settings Error:', error); // Debugging
                showNotification('error', 'Failed to save system settings: ' + error.message);
            });
        });
    }

    // Academy Information Form Submission
    const academyForm = document.getElementById('academyForm');
    if (academyForm) {
        academyForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const academyPhone = document.getElementById('academyPhone').value.trim();
            const academyWebsite = document.getElementById('academyWebsite').value.trim();
            if (!academyPhone.match(/^[0-9]{10}$/)) {
                showNotification('error', 'Please enter a valid 10-digit phone number');
                return;
            }
            if (!academyWebsite.match(/^https?:\/\/[^\s/$.?#].[^\s]*$/)) {
                showNotification('error', 'Please enter a valid URL');
                return;
            }

            const formData = new FormData(academyForm);
            console.log('Academy Form Data:', Object.fromEntries(formData)); // Debugging
            fetch(academyForm.action, {
                method: 'POST',
                headers: {
                    'X-CSRFToken': getCookie('csrftoken'),
                },
                body: formData,
            })
            .then(response => {
                console.log('Academy Response Status:', response.status); // Debugging
                return response.json();
            })
            .then(data => {
                if (data.error) {
                    showNotification('error', data.error);
                } else {
                    showNotification('success', 'Academy information updated successfully!');
                }
            })
            .catch(error => {
                console.error('Academy Update Error:', error); // Debugging
                showNotification('error', 'Failed to update academy information: ' + error.message);
            });
        });
    }

    // Data Management Functions
    window.exportData = function(type) {
        showNotification('info', `Preparing ${type} data for export...`);
        fetch(`/settings/export/${type}/`, {
            method: 'POST',
            headers: {
                'X-CSRFToken': getCookie('csrftoken'),
            },
        })
        .then(response => {
            console.log('Export Response Status:', response.status); // Debugging
            if (!response.ok) {
                return response.json().then(data => {
                    throw new Error(data.error || `Failed to export ${type} data`);
                });
            }
            return response.blob();
        })
        .then(blob => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${type}_export_${new Date().toISOString().slice(0,10)}.csv`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);
            showNotification('success', `${type.charAt(0).toUpperCase() + type.slice(1)} data exported successfully!`);
        })
        .catch(error => {
            console.error('Export Error:', error); // Debugging
            showNotification('error', `Failed to export ${type} data: ${error.message}`);
        });
    };

    window.createBackup = function() {
        showNotification('info', 'Creating system backup...');
        fetch('/settings/backup/', {
            method: 'POST',
            headers: {
                'X-CSRFToken': getCookie('csrftoken'),
            },
        })
        .then(response => {
            console.log('Backup Response Status:', response.status); // Debugging
            if (!response.ok) {
                return response.json().then(data => {
                    throw new Error(data.error || 'Failed to create backup');
                });
            }
            return response.blob();
        })
        .then(blob => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `backup_${new Date().toISOString().slice(0,10)}.zip`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);
            showNotification('success', 'Backup created successfully!');
        })
        .catch(error => {
            console.error('Backup Error:', error); // Debugging
            showNotification('error', 'Failed to create backup: ' + error.message);
        });
    };

    window.restoreBackup = function() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.zip';
        input.onchange = function(event) {
            const file = event.target.files[0];
            if (!file) {
                showNotification('error', 'No file selected');
                return;
            }

            const formData = new FormData();
            formData.append('backup_file', file);
            showNotification('info', 'Restoring backup...');
            fetch('/settings/restore/', {
                method: 'POST',
                headers: {
                    'X-CSRFToken': getCookie('csrftoken'),
                },
                body: formData,
            })
            .then(response => {
                console.log('Restore Response Status:', response.status); // Debugging
                return response.json();
            })
            .then(data => {
                if (data.error) {
                    showNotification('error', data.error);
                } else {
                    showNotification('success', 'Backup restored successfully! Please refresh the page.');
                }
            })
            .catch(error => {
                console.error('Restore Error:', error); // Debugging
                showNotification('error', 'Failed to restore backup: ' + error.message);
            });
        };
        input.click();
    };
});