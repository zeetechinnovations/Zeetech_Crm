async function fetchMaterials() {
    try {
        document.getElementById('materialList').innerHTML = '<p>Loading materials...</p>';
        const response = await fetch('/study_material/get_materials/');
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const data = await response.json();
        console.log('Fetched materials:', data.materials);
        if (data.error) console.warn('Backend error:', data.error);
        return data.materials || [];
    } catch (error) {
        console.error('Error fetching materials:', error);
        document.getElementById('materialList').innerHTML = '<p>Error loading materials. Please try again later.</p>';
        return [];
    }
}

async function fetchCourses() {
    try {
        const response = await fetch('/courses/get_courses/');
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const data = await response.json();
        console.log('Fetched courses:', data.courses);
        return data.courses || [];
    } catch (error) {
        console.error('Error fetching courses:', error);
        return [];
    }
}

function populateCourseFilter(courses) {
    const courseFilter = document.getElementById('courseFilter');
    courseFilter.innerHTML = '<option value="all">All Courses</option>';
    if (!courses || courses.length === 0) {
        console.warn('No courses available');
        const option = document.createElement('option');
        option.value = 'none';
        option.textContent = 'No Courses Available';
        courseFilter.appendChild(option);
    } else {
        courses.forEach(course => {
            const option = document.createElement('option');
            option.value = course.id;
            option.textContent = course.name;
            courseFilter.appendChild(option);
        });
    }
}

function displayMaterials(materials) {
    console.log('Displaying materials:', materials);
    const materialList = document.getElementById('materialList');
    materialList.innerHTML = materials.length === 0 ? '<p>No materials found. Please check filters or upload new materials.</p>' : '';
    materials.forEach(material => {
        const card = document.createElement('div');
        card.className = `material-card course-${material.course_id || 'none'}`;
        card.innerHTML = `
            <h3>${material.title}</h3>
            <p>${material.description || 'No description'}</p>
            <p><strong>Course:</strong> ${material.course_name || 'No Course'}</p>
            <p><strong>Type:</strong> ${material.material_type}</p>
            <span class="type-icon">${material.material_type === 'PDF' ? '📄' : '🎥'}</span>
            ${material.file_url ? `<a href="${material.file_url}" target="_blank" rel="noopener noreferrer">Download / View</a>` : '<p>No file available</p>'}
        `;
        materialList.appendChild(card);
    });

    document.getElementById('totalMaterials').textContent = materials.length;
    document.getElementById('availableMaterials').textContent = materials.filter(m => m.file_url).length;
    document.getElementById('downloadedMaterials').textContent = 0; // Placeholder
}

// Utility function for CSRF token
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.startsWith(name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

function filterMaterials() {
    const searchInput = document.getElementById('searchInput').value.toLowerCase();
    const courseFilter = document.getElementById('courseFilter').value;

    fetchMaterials().then(materials => {
        console.log('Materials before filtering:', materials);
        const filteredMaterials = materials.filter(material => {
            const matchesSearch = material.title.toLowerCase().includes(searchInput) ||
                                 (material.description && material.description.toLowerCase().includes(searchInput));
            const matchesCourse = courseFilter === 'all' || 
                                 (material.course_id ? material.course_id.toString() === courseFilter : courseFilter === 'none');
            console.log('Material:', material, 'Matches Search:', matchesSearch, 'Matches Course:', matchesCourse);
            return matchesSearch && matchesCourse;
        });
        console.log('Filtered materials:', filteredMaterials);
        displayMaterials(filteredMaterials);
    });
}

async function initializePage() {
    try {
        console.log(' initializing page...');
        const courses = await fetchCourses();
        populateCourseFilter(courses);
        await filterMaterials();
    } catch (error) {
        console.error('Initialization error:', error);
        document.getElementById('materialList').innerHTML = '<p>Error initializing page. Please try again later.</p>';
    }
}


