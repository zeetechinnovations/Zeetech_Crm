function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let cookie of cookies) {
            cookie = cookie.trim();
            if (cookie.startsWith(name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    console.log(`CSRF Token (${name}):`, cookieValue);
    return cookieValue;
}

function showNotification(type, message) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <span class="icon">${type === 'success' ? '✅' : '❌'}</span>
        <span>${message}</span>
    `;
    document.body.appendChild(notification);
    setTimeout(() => notification.classList.add('show'), 100);
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

function showZtechPayAddModal() {
    const modal = document.getElementById('ztechPayAddModal');
    if (modal) {
        closeAllZtechPayModals();
        modal.style.display = 'block';
        console.log('Opened add payment modal at', new Date().toLocaleString());
    } else {
        console.error('Add payment modal not found');
        showNotification('error', 'Add payment modal not found');
    }
}

function showZtechPayEditModal(payment) {
    console.log('Attempting to open edit payment modal for payment:', payment);
    const modal = document.getElementById('ztechPayEditModal');
    if (!modal) {
        console.error('Edit payment modal not found');
        showNotification('error', 'Edit payment modal not found');
        return;
    }

    const form = modal.querySelector('#ztechPayEditForm');
    if (!form) {
        console.error('Edit payment form not found');
        showNotification('error', 'Edit payment form not found');
        return;
    }

    try {
        form.querySelector('#ztechPayEditStudentSelect').value = payment.student || '';
        form.querySelector('#ztechPayEditCourseSelect').value = payment.course_id || '';
        form.querySelector('#ztechPayEditAmount').value = payment.amount || '';
        form.querySelector('#ztechPayEditMethod').value = payment.method || '';
        form.querySelector('#ztechPayEditDate').value = payment.date || '';
        form.querySelector('#ztechPayEditStatus').value = payment.status || '';
        form.querySelector('#ztechPayEditTransactionId').value = payment.transactionId || '';
        form.querySelector('#ztechPayEditNotes').value = payment.notes || '';
        form.querySelector('#ztechPayEditId').value = payment.id || '';

        closeAllZtechPayModals();
        modal.style.display = 'block';
        console.log('Opened edit payment modal for payment ID:', payment.id);
    } catch (error) {
        console.error('Error populating edit payment form:', error);
        showNotification('error', 'Failed to populate edit payment form');
    }
}

function closeAllZtechPayModals() {
    const modals = document.querySelectorAll('.ztechPay-modal');
    modals.forEach(modal => {
        modal.style.display = 'none';
        console.log(`Closed modal: ${modal.id} at`, new Date().toLocaleString());
    });
}

function closeZtechPayModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
        console.log(`Closed modal: ${modalId} at`, new Date().toLocaleString());
    }
}

function loadZtechPayPayments() {
    const tableBody = document.getElementById('ztechPayTableBody');
    const loadingIndicator = document.getElementById('ztechPayLoadingIndicator');
    const userRole = document.querySelector('meta[name="user-role"]').content;

    if (!tableBody || !loadingIndicator) {
        console.error('Required DOM elements not found');
        showNotification('error', 'Required DOM elements not found');
        return;
    }

    loadingIndicator.style.display = 'block';

    fetch('/payments/get-payments/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken'),
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({})
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Network response was not ok: ${response.status} ${response.statusText}`);
        }
        return response.json();
    })
    .then(data => {
        console.log('Received payments data:', data);
        if (data.payments && Array.isArray(data.payments)) {
            tableBody.innerHTML = '';
            if (data.payments.length === 0) {
                tableBody.innerHTML = `<tr><td colspan="${userRole === 'admin' ? 9 : 7}">No payments found.</td></tr>`;
            } else {
                data.payments.forEach(payment => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${payment.id}</td>
                        <td>${payment.studentName}</td>
                        <td>${payment.course}</td>
                        <td>₹${payment.amount.toLocaleString('en-IN')}</td>
                        <td>${payment.method.charAt(0).toUpperCase() + payment.method.slice(1)}</td>
                        <td>${payment.date}</td>
                        <td>${payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}</td>
                        ${userRole === 'admin' ? `
                            <td>
                                <button class="contact-btn" onclick="showZtechPayEditModal({
                                    id: ${payment.id},
                                    student: ${payment.student},
                                    studentName: '${payment.studentName.replace(/'/g, "\\'")}',
                                    course: '${payment.course.replace(/'/g, "\\'")}',
                                    course_id: ${payment.course_id || 'null'},
                                    amount: ${payment.amount},
                                    method: '${payment.method}',
                                    date: '${payment.date}',
                                    status: '${payment.status}',
                                    transactionId: '${payment.transactionId.replace(/'/g, "\\'")}',
                                    notes: '${payment.notes ? payment.notes.replace(/'/g, "\\'") : ''}'
                                })">✏️</button>
                                <button class="contact-btn" onclick="deleteZtechPay(${payment.id})">🗑</button>
                            </td>
                        ` : ''}
                    `;
                    tableBody.appendChild(row);
                });
            }
        } else {
            showNotification('error', 'Invalid response format from server');
        }
    })
    .catch(err => {
        console.error('Error in loadZtechPayPayments:', err);
        showNotification('error', 'Failed to load payments: ' + err.message);
    })
    .finally(() => {
        loadingIndicator.style.display = 'none';
    });
}

function deleteZtechPay(paymentId) {
    if (confirm('Are you sure you want to delete this payment?')) {
        fetch(`/payments/delete-payment/${paymentId}/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCookie('csrftoken'),
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({})
        })
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(json => {
            if (json.success) {
                showNotification('success', 'Payment deleted successfully');
                loadZtechPayPayments();
            } else {
                showNotification('error', 'Failed to delete payment: ' + (json.error || 'Unknown error'));
            }
        })
        .catch(err => showNotification('error', 'Error: ' + err.message));
    }
}

function handleZtechPayFormSubmit(event, isEdit = false) {
    event.preventDefault();
    const form = event.target;
    const studentSelect = form.querySelector(isEdit ? '#ztechPayEditStudentSelect' : '#ztechPayStudentSelect');
    const amountInput = form.querySelector(isEdit ? '#ztechPayEditAmount' : '#ztechPayAmount');
    const methodSelect = form.querySelector(isEdit ? '#ztechPayEditMethod' : '#ztechPayMethod');
    const dateInput = form.querySelector(isEdit ? '#ztechPayEditDate' : '#ztechPayDate');

    if (!studentSelect.value) {
        showNotification('error', 'Please select a student.');
        return;
    }
    if (!amountInput.value || amountInput.value <= 0) {
        showNotification('error', 'Please enter a valid amount.');
        return;
    }
    if (!methodSelect.value) {
        showNotification('error', 'Please select a payment method.');
        return;
    }
    if (!dateInput.value) {
        showNotification('error', 'Please select a payment date.');
        return;
    }

    const formData = new FormData(form);
    const url = isEdit ? `/payments/edit-payment/${form.querySelector('#ztechPayEditId').value}/` : form.action;

    fetch(url, {
        method: 'POST',
        headers: {
            'X-CSRFToken': getCookie('csrftoken'),
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            showNotification('success', isEdit ? 'Payment updated successfully' : 'Payment added successfully');
            loadZtechPayPayments();
            closeZtechPayModal(isEdit ? 'ztechPayEditModal' : 'ztechPayAddModal');
        } else {
            showNotification('error', data.error || 'Unknown error occurred');
        }
    })
    .catch(err => {
        console.error('Form submission error:', err);
        showNotification('error', 'Failed to submit form: ' + err.message);
    });
}

document.addEventListener('DOMContentLoaded', () => {
    console.log('DOMContentLoaded, initializing payments page at', new Date().toLocaleString());
    closeAllZtechPayModals();
    loadZtechPayPayments();

    const addPaymentButton = document.getElementById('ztechPayAddButton');
    if (addPaymentButton) {
        addPaymentButton.addEventListener('click', () => {
            console.log('Add payment button clicked');
            showZtechPayAddModal();
        });
    } else {
        console.error('ztechPayAddButton not found in DOM');
        showNotification('error', 'Add payment button not found');
    }

    const addPaymentForm = document.getElementById('ztechPayAddForm');
    if (addPaymentForm) {
        addPaymentForm.addEventListener('submit', (e) => {
            console.log('Add payment form submitted');
            handleZtechPayFormSubmit(e, false);
        });
    } else {
        console.error('ztechPayAddForm not found in DOM');
    }

    const editPaymentForm = document.getElementById('ztechPayEditForm');
    if (editPaymentForm) {
        editPaymentForm.addEventListener('submit', (e) => {
            console.log('Edit payment form submitted');
            handleZtechPayFormSubmit(e, true);
        });
    } else {
        console.error('ztechPayEditForm not found in DOM');
    }

    const closeButtons = document.querySelectorAll('.ztechPay-modal-close');
    closeButtons.forEach(button => {
        button.addEventListener('click', () => {
            console.log(`Close button clicked for modal: ${button.dataset.modal}`);
            closeZtechPayModal(button.dataset.modal);
        });
    });

    document.querySelectorAll('.ztechPay-modal').forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                console.log(`Clicked outside modal: ${modal.id}`);
                closeZtechPayModal(modal.id);
            }
        });
    });
});


