from django.contrib import admin
from .models import Student

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('student_id', 'name', 'email', 'course', 'status', 'placed')  # Added placed
    list_filter = ('course', 'status', 'placed')  # Added placed
    search_fields = ('name', 'email', 'student_id')

    