from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse, HttpResponseForbidden
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
from accounts.decorators import role_required
from .models import Student
from courses.models import Course
from batches.models import Batch
from accounts.models import User
from notifications.notifications import send_email_notification
import json
from django.db import IntegrityError
import uuid
import logging

logger = logging.getLogger(__name__)

@role_required('admin', 'teacher', 'student')
def student_list(request):
    if request.user.role == 'admin':
        students = Student.objects.all()
        total_students = students.count()
        active_students = students.filter(status='active').count()
        graduated_students = students.filter(status='completed').count()
        placed_students = students.filter(placed=True).count()
    elif request.user.role == 'teacher':
        students = Student.objects.all()  # No teacher field in Batch
        total_students = students.count()
        active_students = students.filter(status='active').count()
        graduated_students = students.filter(status='completed').count()
        placed_students = students.filter(placed=True).count()
    else:  # student
        student = get_object_or_404(Student, user=request.user)
        students = Student.objects.filter(user=request.user)
        total_students = 1
        active_students = 1 if student.status == 'active' else 0
        graduated_students = 1 if student.status == 'completed' else 0
        placed_students = 1 if student.placed else 0

    for student in students:
        student.formatted_course = student.course.name
        student.formatted_batch = student.batch.name if student.batch else ''

    context = {
        'students': students,
        'total_students': total_students,
        'active_students': active_students,
        'graduated_students': graduated_students,
        'placed_students': placed_students,
        'courses': Course.objects.all() if request.user.role in ['admin', 'teacher'] else [],
        'batches': Batch.objects.all() if request.user.role in ['admin', 'teacher'] else [],
    }
    return render(request, 'students/students.html', context)

@require_POST
@csrf_exempt
@role_required('admin')
def add_student(request):
    try:
        logger.info("Received add_student request")
        data = json.loads(request.body)
        logger.debug(f"Request data: {data}")

        # Validate required fields
        required_fields = ['name', 'email', 'phone', 'course_id']
        missing_fields = [field for field in required_fields if not data.get(field)]
        if missing_fields:
            logger.error(f"Missing required fields: {missing_fields}")
            return JsonResponse({'status': 'error', 'message': f'Missing required fields: {", ".join(missing_fields)}'}, status=400)

        user_id = data.get('user_id')
        name = data.get('name')
        email = data.get('email')
        phone = data.get('phone')
        dob = data.get('dob') or None
        course_id = data.get('course_id')
        batch_id = data.get('batch_id', '')
        admission_date = data.get('admission_date') or None
        status = data.get('status', 'active')
        address = data.get('address', '')
        placed = data.get('placed', False) == True  # Ensure boolean

        # Validate course
        try:
            course = Course.objects.get(id=course_id)
        except Course.DoesNotExist:
            logger.error(f"Invalid course_id: {course_id}")
            return JsonResponse({'status': 'error', 'message': 'Invalid course ID.'}, status=400)

        # Validate batch
        batch = None
        if batch_id:
            try:
                batch = Batch.objects.get(id=batch_id)
            except Batch.DoesNotExist:
                logger.error(f"Invalid batch_id: {batch_id}")
                return JsonResponse({'status': 'error', 'message': 'Invalid batch ID.'}, status=400)

        # Handle user creation
        if user_id:
            try:
                user = User.objects.get(id=user_id, role='student')
            except User.DoesNotExist:
                logger.error(f"Invalid user_id: {user_id}")
                return JsonResponse({'status': 'error', 'message': 'Invalid user ID.'}, status=400)
        else:
            if User.objects.filter(email=email).exists():
                logger.error(f"Email already exists: {email}")
                return JsonResponse({'status': 'error', 'message': 'Email already exists.'}, status=400)
            random_password = str(uuid.uuid4())[:8]
            try:
                user = User.objects.create_user(
                    email=email,
                    username=email.split('@')[0],
                    phone=phone,
                    role='student',
                    first_name=name.split()[0] if name else '',
                    last_name=' '.join(name.split()[1:]) if len(name.split()) > 1 else '',
                    password=random_password
                )
                logger.info(f"Created user: {user.email}")
            except Exception as e:
                logger.error(f"Failed to create user: {str(e)}")
                return JsonResponse({'status': 'error', 'message': f'Failed to create user: {str(e)}'}, status=400)

            # Send email notification (non-blocking)
            try:
                send_email_notification(
                    subject="Your Zee-Tech Academy Account",
                    message=f"Dear {name},\nYour account has been created. Your password is: {random_password}\nPlease log in at {request.build_absolute_uri('/auth/login/')}",
                    recipient_list=[email]
                )
                logger.info(f"Email notification sent to {email}")
            except Exception as e:
                logger.warning(f"Email notification failed: {str(e)}")  # Continue despite email failure

        # Create student
        try:
            student = Student(
                user=user,
                name=name,
                email=email,
                phone=phone,
                dob=dob,
                course=course,
                batch=batch,
                admission_date=admission_date,
                status=status,
                address=address,
                placed=placed
            )
            student.save()
            logger.info(f"Student created: {student.student_id}")
        except Exception as e:
            logger.error(f"Failed to create student: {str(e)}")
            return JsonResponse({'status': 'error', 'message': f'Failed to create student: {str(e)}'}, status=400)

        return JsonResponse({
            'status': 'success',
            'student': {
                'id': student.id,
                'student_id': student.student_id,
                'name': student.name,
                'email': student.email,
                'phone': student.phone,
                'course': student.course.name,
                'course_id': student.course.id,
                'batch': student.batch.name if student.batch else '',
                'batch_id': student.batch.id if student.batch else '',
                'status': student.status,
                'address': student.address,
                'placed': student.placed,
                'formatted_course': student.course.name,
                'formatted_batch': student.batch.name if student.batch else ''
            }
        })
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON data: {str(e)}")
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON data.'}, status=400)
    except IntegrityError as e:
        logger.error(f"IntegrityError: {str(e)}")
        return JsonResponse({'status': 'error', 'message': 'Email or student ID already exists.'}, status=400)
    except Exception as e:
        logger.error(f"Unexpected error in add_student: {str(e)}")
        return JsonResponse({'status': 'error', 'message': f"An unexpected error occurred: {str(e)}"}, status=400)

@require_POST
@csrf_exempt
@role_required('admin')
def edit_student(request, student_id):
    try:
        logger.info(f"Received edit_student request for student_id: {student_id}")
        student = get_object_or_404(Student, id=student_id)
        data = json.loads(request.body)
        logger.debug(f"Request data: {data}")

        # Validate required fields
        required_fields = ['name', 'email', 'phone', 'course_id']
        missing_fields = [field for field in required_fields if not data.get(field)]
        if missing_fields:
            logger.error(f"Missing required fields: {missing_fields}")
            return JsonResponse({'status': 'error', 'message': f'Missing required fields: {", ".join(missing_fields)}'}, status=400)

        student.name = data.get('name')
        student.email = data.get('email')
        student.phone = data.get('phone')
        student.dob = data.get('dob') or None
        course_id = data.get('course_id')
        batch_id = data.get('batch_id', '')
        student.admission_date = data.get('admission_date') or None
        student.status = data.get('status', 'active')
        student.address = data.get('address', '')
        student.placed = data.get('placed', False) == True  # Ensure boolean

        # Validate course
        try:
            student.course = Course.objects.get(id=course_id)
        except Course.DoesNotExist:
            logger.error(f"Invalid course_id: {course_id}")
            return JsonResponse({'status': 'error', 'message': 'Invalid course ID.'}, status=400)

        # Validate batch
        if batch_id:
            try:
                student.batch = Batch.objects.get(id=batch_id)
            except Batch.DoesNotExist:
                logger.error(f"Invalid batch_id: {batch_id}")
                return JsonResponse({'status': 'error', 'message': 'Invalid batch ID.'}, status=400)
        else:
            student.batch = None

        # Update user
        user_id = data.get('user_id')
        if user_id:
            try:
                student.user = User.objects.get(id=user_id, role='student')
            except User.DoesNotExist:
                logger.error(f"Invalid user_id: {user_id}")
                return JsonResponse({'status': 'error', 'message': 'Invalid user ID.'}, status=400)

        student.save()
        logger.info(f"Student updated: {student.student_id}")

        return JsonResponse({
            'status': 'success',
            'student': {
                'id': student.id,
                'student_id': student.student_id,
                'name': student.name,
                'email': student.email,
                'phone': student.phone,
                'course': student.course.name,
                'course_id': student.course.id,
                'batch': student.batch.name if student.batch else '',
                'batch_id': student.batch.id if student.batch else '',
                'status': student.status,
                'address': student.address,
                'placed': student.placed,
                'formatted_course': student.course.name,
                'formatted_batch': student.batch.name if student.batch else ''
            }
        })
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON data: {str(e)}")
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON data.'}, status=400)
    except IntegrityError as e:
        logger.error(f"IntegrityError: {str(e)}")
        return JsonResponse({'status': 'error', 'message': 'Email or student ID already exists.'}, status=400)
    except Exception as e:
        logger.error(f"Unexpected error in edit_student: {str(e)}")
        return JsonResponse({'status': 'error', 'message': f"An unexpected error occurred: {str(e)}"}, status=400)

@require_POST
@csrf_exempt
@role_required('admin')
def delete_student(request, student_id):
    try:
        logger.info(f"Received delete_student request for student_id: {student_id}")
        student = get_object_or_404(Student, id=student_id)
        if student.batch:
            student.batch.students.remove(student.user)
        student.course.students.remove(student.user)
        student.delete()
        logger.info(f"Student deleted: {student_id}")
        return JsonResponse({'status': 'success'})
    except Exception as e:
        logger.error(f"Error deleting student: {str(e)}")
        return JsonResponse({'status': 'error', 'message': str(e)}, status=400)

@role_required('admin', 'teacher', 'student')
def view_student(request, id):
    try:
        student = get_object_or_404(Student, id=id)
        if request.user.role == 'student' and student.user != request.user:
            logger.warning(f"Unauthorized access attempt by user {request.user.email} to student {id}")
            return HttpResponseForbidden("You can only view your own profile.")
        return JsonResponse({
            'status': 'success',
            'id': student.id,
            'student_id': student.student_id,
            'name': student.name,
            'email': student.email,
            'phone': student.phone,
            'dob': student.dob.isoformat() if student.dob else '',
            'course': student.course.name,
            'course_id': student.course.id,
            'batch': student.batch.name if student.batch else '',
            'batch_id': student.batch.id if student.batch else '',
            'admission_date': student.admission_date.isoformat() if student.admission_date else '',
            'status': student.status,
            'address': student.address,
            'placed': student.placed,
        })
    except Exception as e:
        logger.error(f"Error viewing student {id}: {str(e)}")
        return JsonResponse({'status': 'error', 'message': str(e)}, status=400)
    

    
    