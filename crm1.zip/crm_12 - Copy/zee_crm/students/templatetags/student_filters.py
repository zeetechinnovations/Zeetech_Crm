from django import template

print("Loading student_filters.py")  # Add this for debugging

register = template.Library()

@register.filter
def replace_hyphen(value):
    return value.replace('-', ' ')

@register.filter
def batch_format(value):
    if value:
        return value.replace('batch-', 'Batch 2024-')
    return ''

@register.filter
def filter_status(students, status):
    return [student for student in students if student.status == status]

@register.filter
def filter_placed(students):
    return [student for student in students if student.placed]

