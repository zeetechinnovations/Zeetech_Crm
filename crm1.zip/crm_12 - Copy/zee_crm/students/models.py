from django.db import models
from accounts.models import User
from courses.models import Course
from batches.models import Batch

class Student(models.Model):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('completed', 'Completed'),
        ('dropped', 'Dropped'),
    ]

    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        null=True,
        limit_choices_to={'role': 'student'},
        related_name='student_profile'
    )
    student_id = models.CharField(max_length=10, unique=True, blank=True)
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=15)
    dob = models.DateField(null=True, blank=True)
    course = models.ForeignKey(
        Course,
        on_delete=models.CASCADE,
        related_name='students_enrolled'
    )
    batch = models.ForeignKey(
        Batch,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='students_enrolled'
    )
    admission_date = models.DateField(null=True, blank=True)
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='active'
    )
    address = models.TextField(blank=True)
    placed = models.BooleanField(default=False)

    def save(self, *args, **kwargs):
        if not self.student_id:
            last_student = Student.objects.order_by('-id').first()
            if last_student:
                last_id = int(last_student.student_id.replace('STU', ''))
                new_id = last_id + 1
            else:
                new_id = 1
            self.student_id = f'STU{str(new_id).zfill(3)}'
        super().save(*args, **kwargs)

        # Ensure student is added to course and batch relationships
        if self.user:
            self.course.students.add(self.user)
            if self.batch:
                self.batch.students.add(self.user)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Student"
        verbose_name_plural = "Students"

        