from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User
from django.contrib.auth.forms import PasswordResetForm
from django.contrib import messages

class CustomUserAdmin(UserAdmin):
    list_display = ('email', 'username', 'first_name', 'last_name', 'role', 'is_staff', 'is_superuser')
    search_fields = ('email', 'username', 'first_name', 'last_name')
    ordering = ('email',)
    
    fieldsets = (
        (None, {'fields': ('email', 'username', 'password', 'first_name', 'last_name', 'phone', 'role')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Important dates', {'fields': ('last_login',)}),
    )
    
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'username', 'first_name', 'last_name', 'phone', 'role', 'password1', 'password2'),
        }),
    )
    
    readonly_fields = ('last_login',)
    
    actions = ['send_password_reset_email']
    
    def send_password_reset_email(self, request, queryset):
        for user in queryset:
            form = PasswordResetForm({'email': user.email})
            if form.is_valid():
                form.save(
                    request=request,
                    use_https=request.is_secure(),
                    email_template_name='auth/password_reset_email.html',
                    subject_template_name='auth/password_reset_subject.txt'
                )
        self.message_user(request, "Password reset emails sent successfully.", messages.SUCCESS)
    send_password_reset_email.short_description = "Send password reset email to selected users"

admin.site.register(User, CustomUserAdmin)


