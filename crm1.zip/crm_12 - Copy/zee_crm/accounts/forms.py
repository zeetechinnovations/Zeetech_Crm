# accounts/forms.py
from django.contrib.auth.forms import SetPasswordForm
from .models import User

class CustomSetPasswordForm(SetPasswordForm):
    class Meta:
        model = User
        fields = ['new_password1', 'new_password2']

