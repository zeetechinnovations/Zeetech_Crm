from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .models import User
from django.urls import reverse_lazy
from django.contrib.auth.views import PasswordResetView
from django.conf import settings
from notifications.notifications import send_email_notification, send_sms_notification
from .decorators import role_required
from students.models import Student
from courses.models import Course
from batches.models import Batch

def login_view(request):
    if request.user.is_authenticated:
        if request.user.role == 'student':
            return redirect('students:student_list')
        return redirect('dashboard:kpi')
    
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            if user.role == 'student':
                return redirect('students:student_list')
            return redirect('dashboard:kpi')
        else:
            messages.error(request, 'Invalid credentials')

    return render(request, 'auth/login.html')

def signup_view(request):
    if request.user.is_authenticated:
        if request.user.role == 'student':
            return redirect('students:student_list')
        return redirect('dashboard:kpi')
    
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        email = request.POST['email']
        phone = request.POST['phone']
        role = request.POST['role']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        passcode = request.POST.get('passcode', '')
        course_id = request.POST.get('course_id')

        if request.user.is_authenticated:
            if request.user.role == 'student' and role in ['teacher', 'admin']:
                messages.error(request, 'Students cannot create teacher or admin accounts.')
                return render(request, 'auth/signup.html')
            if request.user.role == 'teacher' and role == 'admin':
                messages.error(request, 'Teachers cannot create admin accounts.')
                return render(request, 'auth/signup.html')

        if role == 'teacher' and passcode != settings.TEACHER_PASSCODE:
            messages.error(request, 'Invalid teacher passcode.')
            return render(request, 'auth/signup.html')
        if role == 'admin' and passcode != settings.ADMIN_PASSCODE:
            messages.error(request, 'Invalid admin passcode.')
            return render(request, 'auth/signup.html')

        if password1 != password2:
            messages.error(request, 'Passwords do not match')
        elif len(password1) < 8:
            messages.error(request, 'Password must be at least 8 characters')
        elif User.objects.filter(email=email).exists():
            messages.error(request, 'Email already exists')
        elif User.objects.filter(username=username).exists():
            messages.error(request, 'Username already exists')
        elif role == 'student' and not course_id:
            messages.error(request, 'Please select a course')
        else:
            user = User.objects.create_user(
                email=email,
                username=username,
                first_name=first_name,
                last_name=last_name,
                phone=phone,
                role=role,
                password=password1
            )

            if role == 'student':
                try:
                    course = Course.objects.get(id=course_id)
                    student = Student.objects.create(
                        user=user,
                        name=f"{first_name} {last_name}",
                        email=email,
                        phone=phone,
                        course=course,
                        status='active'
                    )
                    course.students.add(user)
                    send_email_notification(
                        subject="Welcome to Zee-Tech Academy",
                        message=f"Dear {first_name} {last_name},\nYour account has been created successfully. Please log in at {request.build_absolute_uri('/auth/login/')}",
                        recipient_list=[email]
                    )
                except Exception as e:
                    messages.error(request, f'Failed to create student profile: {str(e)}')
                    user.delete()
                    return render(request, 'auth/signup.html')

            messages.success(request, 'Account created successfully. Please log in.')
            return redirect('accounts:login')

    context = {'courses': Course.objects.all()}
    return render(request, 'auth/signup.html', context)

@role_required('admin', 'teacher', 'student')
def logout_view(request):
    logout(request)
    return redirect('accounts:login')

class CustomPasswordResetView(PasswordResetView):
    template_name = 'auth/password_reset_form.html'
    email_template_name = 'auth/password_reset_email.html'
    subject_template_name = 'auth/password_reset_subject.txt'
    success_url = reverse_lazy('accounts:password_reset_done')

    def form_valid(self, form):
        email = form.cleaned_data['email']
        if not User.objects.filter(email=email).exists():
            messages.error(self.request, 'No user found with this email address.')
            return self.form_invalid(form)
        return super().form_valid(form)
    
