from django.urls import path
from .views import dashboard, dashboard_data
from students.views import student_list

app_name = 'dashboard'

urlpatterns = [
    path('', dashboard, name='dashboard'),  # Added for redirect compatibility
    path('kpi/', dashboard, name='kpi'),
    path('data/', dashboard_data, name='dashboard-data'),
]



