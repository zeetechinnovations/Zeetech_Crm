from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from accounts.decorators import role_required
from students.models import Student
from courses.models import Course
from batches.models import Batch
from payments.models import Payment
from django.db.models import Sum
from datetime import datetime, timedelta
from django.utils import timezone
import json
import logging

logger = logging.getLogger(__name__)

@role_required('admin', 'teacher','student')
def dashboard(request):
    try:
        total_students = Student.objects.count()
        total_revenue = Payment.objects.filter(status='paid').aggregate(total=Sum('amount'))['total'] or 0
        pending_payments = Payment.objects.filter(status='pending').count()
        total_courses = Course.objects.count()
        active_batches = Batch.objects.filter(status__in=['ongoing', 'upcoming']).count()
    except Exception as e:
        logger.error(f"Dashboard view error: {str(e)}")
        total_students = total_revenue = pending_payments = total_courses = active_batches = 0

    context = {
        'total_students': total_students,
        'total_revenue': total_revenue,
        'pending_payments': pending_payments,
        'total_courses': total_courses,
        'active_batches': active_batches,
    }
    return render(request, 'dashboard/kpi_dashboard.html', context)

@csrf_exempt
@role_required('admin')
def dashboard_data(request):
    if request.method != 'POST':
        logger.error('Invalid request method for dashboard_data')
        return JsonResponse({'error': 'Invalid request method'}, status=405)

    try:
        data = json.loads(request.body or '{}')
        filter_type = data.get('filterType', 'all')
        start_date = data.get('startDate', '')
        end_date = data.get('endDate', '')

        students = Student.objects.all()
        payments = Payment.objects.all()
        courses = Course.objects.all()
        batches = Batch.objects.all()

        if filter_type == 'monthly':
            start = timezone.now() - timedelta(days=30)
            students = students.filter(admission_date__gte=start)
            payments = payments.filter(date__gte=start)
            batches = batches.filter(start_date__gte=start)
        elif filter_type == 'quarterly':
            start = timezone.now() - timedelta(days=90)
            students = students.filter(admission_date__gte=start)
            payments = payments.filter(date__gte=start)
            batches = batches.filter(start_date__gte=start)
        elif filter_type == 'yearly':
            start = timezone.now() - timedelta(days=365)
            students = students.filter(admission_date__gte=start)
            payments = payments.filter(date__gte=start)
            batches = batches.filter(start_date__gte=start)

        if start_date:
            try:
                start = datetime.strptime(start_date, '%Y-%m-%d').date()
                students = students.filter(admission_date__gte=start)
                payments = payments.filter(date__gte=start)
                batches = batches.filter(start_date__gte=start)
            except ValueError as e:
                logger.error(f"Invalid start_date: {start_date}")
                return JsonResponse({'error': 'Invalid start date format'}, status=400)

        if end_date:
            try:
                end = datetime.strptime(end_date, '%Y-%m-%d').date()
                students = students.filter(admission_date__lte=end)
                payments = payments.filter(date__lte=end)
                batches = batches.filter(end_date__lte=end)
            except ValueError as e:
                logger.error(f"Invalid end_date: {end_date}")
                return JsonResponse({'error': 'Invalid end date format'}, status=400)

        total_students = students.count()
        total_revenue = payments.filter(status='paid').aggregate(total=Sum('amount'))['total'] or 0
        pending_payments = payments.filter(status='pending').count()
        total_courses = courses.count()
        active_batches = batches.filter(status__in=['ongoing', 'upcoming']).count()

        revenue_labels = []
        revenue_data = []
        try:
            for i in range(6, -1, -1):
                month_start = (timezone.now().date() - timedelta(days=30 * i)).replace(day=1)
                month_end = (month_start + timedelta(days=31)).replace(day=1)
                month_payments = payments.filter(date__gte=month_start, date__lt=month_end, status='paid')
                revenue_labels.append(month_start.strftime('%b %Y'))
                revenue_data.append(float(month_payments.aggregate(total=Sum('amount'))['total'] or 0))
        except Exception as e:
            logger.error(f"Revenue chart error: {str(e)}")
            revenue_labels = ['No Data']
            revenue_data = [0]

        enrollment_labels = []
        enrollment_data = []
        try:
            for course in courses:
                enrollment_labels.append(course.name)
                enrollment_data.append(students.filter(course=course).count())
        except Exception as e:
            logger.error(f"Enrollment chart error: {str(e)}")
            enrollment_labels = ['No Data']
            enrollment_data = [0]

        response_data = {
            'total_students': total_students,
            'total_revenue': float(total_revenue),
            'pending_payments': pending_payments,
            'total_courses': total_courses,
            'active_batches': active_batches,
            'revenue_labels': revenue_labels,
            'revenue_data': revenue_data,
            'enrollment_labels': enrollment_labels,
            'enrollment_data': enrollment_data,
        }
        logger.debug(f"Dashboard data response: {response_data}")
        return JsonResponse(response_data)
    except Exception as e:
        logger.error(f"Dashboard data error: {str(e)}")
        return JsonResponse({'error': str(e)}, status=400)
    
    