from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Placement
from django.db.models import Count, Avg, Max
import json
from decimal import Decimal
from datetime import datetime
from django.db import models
from accounts.decorators import role_required

def placement_dashboard(request):
    return render(request, 'placements/placements.html')  # Updated to point directly to placements.html
@role_required('admin')
@csrf_exempt
def placement_list(request):
    if request.method == 'GET':
        placements = Placement.objects.all()
        search_query = request.GET.get('search', '')
        status_filter = request.GET.get('status', '')
        course_filter = request.GET.get('course', '')

        if search_query:
            placements = placements.filter(
                models.Q(student_name__icontains=search_query) |
                models.Q(company_name__icontains=search_query) |
                models.Q(job_position__icontains=search_query) |
                models.Q(course__icontains=search_query)
            )
        if status_filter:
            placements = placements.filter(status=status_filter)
        if course_filter:
            placements = placements.filter(course=course_filter)

        data = [
            {
                'id': p.id,
                'student_name': p.student_name,
                'company_name': p.company_name,
                'job_position': p.job_position,
                'course': p.get_course_display(),
                'salary': str(p.salary),
                'placement_date': p.placement_date.strftime('%Y-%m-%d') if p.placement_date else '',
                'status': p.status,
                'location': p.location,
                'notes': p.notes
            } for p in placements
        ]
        return JsonResponse({'placements': data})

@role_required('admin')
@csrf_exempt
def placement_create_update(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        placement_id = data.get('placement_id')

        try:
            if placement_id:
                placement = Placement.objects.get(id=placement_id)
            else:
                placement = Placement()

            placement.student_name = data.get('student_name')
            placement.company_name = data.get('company_name')
            placement.job_position = data.get('job_position')
            placement.course = data.get('course')
            placement.salary = Decimal(data.get('salary'))
            placement_date = data.get('placement_date')
            placement.placement_date = datetime.strptime(placement_date, '%Y-%m-%d').date() if placement_date else None
            placement.status = data.get('status')
            placement.location = data.get('location')
            placement.notes = data.get('notes')
            placement.save()

            return JsonResponse({'status': 'success', 'message': 'Placement saved successfully'})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=400)

@role_required('admin')
@csrf_exempt
def placement_delete(request, id):
    if request.method == 'DELETE':
        try:
            placement = Placement.objects.get(id=id)
            placement.delete()
            return JsonResponse({'status': 'success', 'message': 'Placement deleted successfully'})
        except Placement.DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'Placement not found'}, status=404)

@role_required('admin')
@csrf_exempt
def placement_metrics(request):
    if request.method == 'GET':
        total_placements = Placement.objects.count()
        avg_package = Placement.objects.aggregate(Avg('salary'))['salary__avg'] or 0
        max_package = Placement.objects.aggregate(Max('salary'))['salary__max'] or 0
        total_students = Placement.objects.count()  # Adjust if you have a separate Student model
        placement_rate = (total_placements / total_students * 100) if total_students > 0 else 0

        return JsonResponse({
            'totalPlacements': total_placements,
            'avgPackage': f'₹{round(avg_package, 1)}L',
            'maxPackage': f'₹{round(max_package, 1)}L',
            'placementRate': f'{round(placement_rate, 1)}%'
        })
    


 