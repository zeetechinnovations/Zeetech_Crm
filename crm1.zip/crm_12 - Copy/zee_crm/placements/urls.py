from django.urls import path
from . import views

app_name = 'placements'

urlpatterns = [
    path('', views.placement_dashboard, name='placement_dashboard'),
    path('api/placements/', views.placement_list, name='placement_list'),
    path('api/placements/create/', views.placement_create_update, name='placement_create_update'),
    path('api/placements/delete/<int:id>/', views.placement_delete, name='placement_delete'),
    path('api/placements/metrics/', views.placement_metrics, name='placement_metrics'),
]


