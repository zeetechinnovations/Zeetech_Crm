from django.db import models
from courses.models import Course

class Placement(models.Model):
    STATUS_CHOICES = [
        ('placed', 'Placed'),
        ('interview', 'Interview Scheduled'),
        ('selected', 'Selected'),
        ('rejected', 'Rejected'),
    ]

    COURSE_CHOICES = [
        ('full-stack', 'Full Stack Development'),
        ('data-science', 'Data Science'),
        ('web-dev', 'Web Development'),
        ('mobile-dev', 'Mobile Development'),
    ]

    student_name = models.CharField(max_length=100)
    company_name = models.CharField(max_length=100)
    job_position = models.CharField(max_length=100)
    course = models.CharField(max_length=50, choices=COURSE_CHOICES)
    salary = models.DecimalField(max_digits=10, decimal_places=2)
    placement_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='placed')
    location = models.CharField(max_length=100, null=True, blank=True)
    notes = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.student_name} - {self.company_name}"

    class Meta:
        ordering = ['-placement_date']