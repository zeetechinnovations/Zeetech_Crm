from django.contrib import admin
from .models import Placement

@admin.register(Placement)
class PlacementAdmin(admin.ModelAdmin):
    list_display = ('student_name', 'company_name', 'job_position', 'course', 'salary', 'placement_date', 'status')
    list_filter = ('status', 'course', 'placement_date')
    search_fields = ('student_name', 'company_name', 'job_position')
    list_per_page = 20
    