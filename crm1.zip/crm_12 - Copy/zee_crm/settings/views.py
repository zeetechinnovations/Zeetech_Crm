import csv
from io import StringIO
import zipfile
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponse
from django.contrib.auth import authenticate, update_session_auth_hash
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.conf import settings
from .models import SystemSettings, Academy, Student, Payment, Lead
from django.core import serializers
import json
from datetime import datetime

@login_required
def settings_view(request):
    settings, created = SystemSettings.objects.get_or_create(user=request.user)
    academy, created = Academy.objects.get_or_create()
    return render(request, 'settings/settings.html', {
        'user': request.user,
        'settings': settings,
        'academy': academy,
    })

@login_required
def update_profile(request):
    if request.method == 'POST':
        try:
            user = request.user
            user.first_name = request.POST.get('first_name', user.first_name)
            user.last_name = request.POST.get('last_name', user.last_name)
            user.email = request.POST.get('email', user.email)
            user.phone = request.POST.get('phone', user.phone)
            user.save()
            return JsonResponse({'success': True})
        except Exception as e:
            print(f"Profile update error: {str(e)}")  # Debugging
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=405)

@login_required
def change_password(request):
    if request.method == 'POST':
        try:
            current_password = request.POST.get('current_password')
            new_password = request.POST.get('new_password')
            confirm_password = request.POST.get('confirm_password')
            # Log form data for debugging
            print(f"Form data: current_password={current_password}, new_password={new_password}, confirm_password={confirm_password}")

            # Authenticate user (adjust for USERNAME_FIELD if not 'email')
            user = authenticate(username=request.user.email, password=current_password)
            if not user:
                return JsonResponse({'error': 'Current password is incorrect'}, status=400)

            # Validate new password match
            if new_password != confirm_password:
                return JsonResponse({'error': 'New passwords do not match'}, status=400)

            # Validate password strength
            try:
                validate_password(new_password, user=request.user)
            except ValidationError as e:
                return JsonResponse({'error': '; '.join(e.messages)}, status=400)

            # Update password and session
            request.user.set_password(new_password)
            request.user.save()
            update_session_auth_hash(request, request.user)  # Keep user logged in
            return JsonResponse({'success': True})
        except ValidationError as e:
            print(f"Password validation error: {str(e)}")  # Debugging
            return JsonResponse({'error': str(e)}, status=400)
        except Exception as e:
            print(f"Unexpected password change error: {str(e)}")  # Debugging
            return JsonResponse({'error': 'An unexpected error occurred'}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=405)

@login_required
def update_system_settings(request):
    if request.method == 'POST':
        try:
            settings, created = SystemSettings.objects.get_or_create(user=request.user)
            settings.timezone = request.POST.get('timezone')
            settings.currency = request.POST.get('currency')
            settings.email_notifications = request.POST.get('email_notifications') == 'on'
            settings.sms_notifications = request.POST.get('sms_notifications') == 'on'
            settings.save()
            return JsonResponse({'success': True})
        except Exception as e:
            print(f"System settings update error: {str(e)}")  # Debugging
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=405)

@login_required
def update_academy_info(request):
    if request.method == 'POST':
        try:
            academy, created = Academy.objects.get_or_create()
            academy.name = request.POST.get('academy_name')
            academy.email = request.POST.get('academy_email')
            academy.phone = request.POST.get('academy_phone')
            academy.website = request.POST.get('academy_website')
            academy.address = request.POST.get('academy_address')
            academy.save()
            return JsonResponse({'success': True})
        except Exception as e:
            print(f"Academy info update error: {str(e)}")  # Debugging
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=405)

@login_required
def export_data(request, data_type):
    if request.method == 'POST':
        try:
            response = HttpResponse(content_type='text/csv')
            response['Content-Disposition'] = f'attachment; filename="{data_type}_export_{datetime.now().strftime("%Y-%m-%d")}.csv"'
            writer = csv.writer(response)
            
            if data_type == 'students':
                writer.writerow(['Student ID', 'Name', 'Email', 'Phone', 'Course', 'Status'])
                for student in Student.objects.all():
                    writer.writerow([student.student_id, student.name, student.email, student.phone, student.course, student.status])
            
            elif data_type == 'payments':
                writer.writerow(['Payment ID', 'Student Name', 'Amount', 'Date', 'Status'])
                for payment in Payment.objects.all():
                    writer.writerow([payment.payment_id, payment.student.name, payment.amount, payment.date, payment.status])
            
            elif data_type == 'marketing':
                writer.writerow(['Lead ID', 'Name', 'Email', 'Phone', 'Status'])
                for lead in Lead.objects.all():
                    writer.writerow([lead.lead_id, lead.name, lead.email, lead.phone, lead.status])
            
            else:
                return JsonResponse({'error': 'Invalid data type'}, status=400)
            
            return response
        except Exception as e:
            print(f"Export data error: {str(e)}")  # Debugging
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=405)

@login_required
def create_backup(request):
    if request.method == 'POST':
        try:
            buffer = StringIO()
            with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                zip_file.writestr('students.json', serializers.serialize('json', Student.objects.all()))
                zip_file.writestr('payments.json', serializers.serialize('json', Payment.objects.all()))
                zip_file.writestr('leads.json', serializers.serialize('json', Lead.objects.all()))
                zip_file.writestr('academy.json', serializers.serialize('json', [Academy.objects.first()]))
                zip_file.writestr('settings.json', serializers.serialize('json', SystemSettings.objects.all()))
            
            response = HttpResponse(content_type='application/zip')
            response['Content-Disposition'] = f'attachment; filename=backup_{datetime.now().strftime("%Y-%m-%d")}.zip'
            buffer.seek(0)
            response.write(buffer.getvalue())
            return response
        except Exception as e:
            print(f"Create backup error: {str(e)}")  # Debugging
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=405)

@login_required
def restore_backup(request):
    if request.method == 'POST':
        try:
            backup_file = request.FILES.get('backup_file')
            if not backup_file:
                return JsonResponse({'error': 'No backup file provided'}, status=400)
            
            with zipfile.ZipFile(backup_file, 'r') as zip_file:
                if 'students.json' in zip_file.namelist():
                    Student.objects.all().delete()
                    data = json.loads(zip_file.read('students.json').decode('utf-8'))
                    for obj in serializers.deserialize('json', json.dumps(data)):
                        obj.save()
                
                if 'payments.json' in zip_file.namelist():
                    Payment.objects.all().delete()
                    data = json.loads(zip_file.read('payments.json').decode('utf-8'))
                    for obj in serializers.deserialize('json', json.dumps(data)):
                        obj.save()
                
                if 'leads.json' in zip_file.namelist():
                    Lead.objects.all().delete()
                    data = json.loads(zip_file.read('leads.json').decode('utf-8'))
                    for obj in serializers.deserialize('json', json.dumps(data)):
                        obj.save()
                
                if 'academy.json' in zip_file.namelist():
                    Academy.objects.all().delete()
                    data = json.loads(zip_file.read('academy.json').decode('utf-8'))
                    for obj in serializers.deserialize('json', json.dumps(data)):
                        obj.save()
                
                if 'settings.json' in zip_file.namelist():
                    SystemSettings.objects.all().delete()
                    data = json.loads(zip_file.read('settings.json').decode('utf-8'))
                    for obj in serializers.deserialize('json', json.dumps(data)):
                        obj.save()
            
            return JsonResponse({'success': True})
        except Exception as e:
            print(f"Restore backup error: {str(e)}")  # Debugging
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=405)