from django.urls import path
from . import views

app_name = 'settings'

urlpatterns = [
    path('', views.settings_view, name='settings'),
    path('update_profile/', views.update_profile, name='update_profile'),
    path('change_password/', views.change_password, name='change_password'),
    path('update_system_settings/', views.update_system_settings, name='update_system_settings'),
    path('update_academy_info/', views.update_academy_info, name='update_academy_info'),
    path('export/<str:data_type>/', views.export_data, name='export_data'),
    path('backup/', views.create_backup, name='create_backup'),
    path('restore/', views.restore_backup, name='restore_backup'),
]