from django.db import models
from django.conf import settings

class SystemSettings(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    timezone = models.CharField(max_length=50, default='Asia/Kolkata')
    currency = models.CharField(max_length=3, default='INR')
    email_notifications = models.BooleanField(default=True)
    sms_notifications = models.BooleanField(default=False)

    def __str__(self):
        return f"Settings for {self.user.username}"

class Academy(models.Model):
    name = models.CharField(max_length=100, default='Zee-Tech Academy')
    email = models.EmailField(default='info@zeetechacademy.com')
    phone = models.CharField(max_length=10, default='9876543210')
    website = models.URLField(default='https://zeetechacademy.com')
    address = models.TextField(default='123 Tech Street, Innovation City, TC 12345')

    def __str__(self):
        return self.name

class Student(models.Model):
    student_id = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=10)
    course = models.CharField(max_length=100)
    status = models.CharField(max_length=20, default='Active')

    def __str__(self):
        return self.name

class Payment(models.Model):
    payment_id = models.CharField(max_length=10, unique=True)
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    date = models.DateField()
    status = models.CharField(max_length=20, default='Pending')

    def __str__(self):
        return f"Payment {self.payment_id}"

class Lead(models.Model):
    lead_id = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=10)
    status = models.CharField(max_length=20, default='Enquiry')

    def __str__(self):
        return self.name
    
    